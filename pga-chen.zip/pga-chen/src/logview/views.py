#coding:utf-8
from django.shortcuts import render
from cmdb.utils.clusterutils import get_tags_by_clusterid, get_cluster_by_id,\
    get_logs_by_softid
from cmdb.utils.unitutils import get_servers_by_unitid
from django.http.response import HttpResponse
from pga.settings import LOGSHELL_TMP_DIR
from pga.utils.fileutils import create_dir, write_file_from_content, create_link

# Create your views here.
def log_view(request,template_name,nav):
    
    tree_mode = request.GET.get("tree_mode")
    nodekey = request.GET.get("nodekey")
    if not nodekey or nodekey =='':
        nodekey = 'top'
    if nodekey == 'top':
        notsupport_msg = u"只有openstack cluster类型节点支持这个功能"
        return render(request, template_name, locals())
    nodekeys = nodekey.split('-')
    if len(nodekeys) != 2:
        notsupport_msg = u"只有openstack cluster类型节点支持这个功能"
        return render(request, template_name, locals())
    product_id = nodekeys[0]
    cluster_id = nodekeys[1]
    cluster = get_cluster_by_id(product_id,cluster_id)
    env,service,softs,idc = get_tags_by_clusterid(cluster_id)
    
    server_logs = []
    
    for unit in cluster['units']:
        soft_id = unit.soft_id
        logs = get_logs_by_softid(soft_id)
        servers = get_servers_by_unitid(unit.id)
        for server in servers:
            for log in logs:
                server_logs.append({"eth0":server.eth0,"log":log})
    return render(request, template_name, locals())

def ajax_create_tty_log(request):
    
    eth0 = request.POST.get('eth0')
    name = request.POST.get('name')
    path = request.POST.get('path')
    if not eth0 or not name or not path:
        return HttpResponse('bad parameters')
    
    dst = LOGSHELL_TMP_DIR + 'run/'
    src = LOGSHELL_TMP_DIR + eth0 + name + '/'
    
    create_dir(src)
    ip_file_path = src + 'ip'
    log_file_path = src + 'log'
    
    write_file_from_content(ip_file_path,eth0)
    write_file_from_content(log_file_path,path)
    
    create_link(src,dst)
    
    return HttpResponse('1')



