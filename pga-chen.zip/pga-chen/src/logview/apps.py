from django.apps import AppConfig


class LogviewConfig(AppConfig):
    name = 'logview'
