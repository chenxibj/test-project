from django.core.management.base import BaseCommand
from cmdb.models import ServerInUnit
from pga.utils.zbxapiutils import createHost,zbxapi_get_token_byname,getHostGroupId_by_groupname,getTemplateId_by_templatename

class Command(BaseCommand):
    def add_arguments(self,parser):
        parser.add_argument('groupName', type=str)
        parser.add_argument('templateName', type=str)

    def handle(self,*args,**options):
        try:
            groupName = options['groupName']
            snmpType,env,idc,app,service = groupName.split('_')
            templateName = options['templateName']
        except Exception as e:
            print e
        HostObjects = ServerInUnit.objects.select_related().all().filter(unit__env__name=env,unit__idc__name=idc,unit__service__name=app,unit__soft__name=service)
        
        if snmpType == 'snmp':
            agentType = 2
            port = 161
        else:
            agentType = 1
        
        token = zbxapi_get_token_byname('zabbix.%s' % idc)
        groupID = getHostGroupId_by_groupname(token,groupName)['result'][0]['groupid']
        templateID = getTemplateId_by_templatename(token,templateName)['result'][0]['templateid']

        for eachitem in HostObjects:
            result = createHost(token,groupID,templateID,eachitem,agentType,port)
            print result