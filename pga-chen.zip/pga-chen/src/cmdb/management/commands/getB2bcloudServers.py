from django.core.management.base import BaseCommand, CommandError  
from tmp.trush.openstackutils import get_all_servers_in_tenant
import re
from pga.utils.fileutils import create_dir, write_file_from_content
from pga.settings import TMP_DIR

class Command(BaseCommand):
    def handle(self, *args, **options):
        server_list = []
        
        servers = get_all_servers_in_tenant('nv_gzold_b2b')
        
        for server in servers:
            tmp = {}
            if not server.name:
                continue
            tmp['server_name'] = server.name
            flag = 0
            for tag in server.addresses:
                for subnet in server.addresses[tag]:
                    if re.match(r'^172\.31\.',subnet['addr']) or re.match(r'^192\.168\.',subnet['addr']):
                        tmp['addr'] = subnet['addr']
                        flag = 1
                        break
                else:
                    continue
                break
            if flag == 1:
                server_list.append(tmp)
        
        content = ''
        for server in server_list:
            content += server['server_name'] +" "+ server['addr'] + "\n"
        content = content.strip()
        b2b_dir = TMP_DIR + 'b2bitems'
        create_dir(b2b_dir)  
        filepath = b2b_dir + '/server.list'
        write_file_from_content(filepath,content)
        
            
                        
                    