from django.core.management.base import BaseCommand
from pga.settings import BASE_DIR
from cmdb.models import Server
from cmdb.utils.serverUtils import eth02eth1NEWSDN

class Command(BaseCommand):
    def handle(self, *args, **options):
        print eth02eth1NEWSDN('172.19.31.1', 'bj02')
                        
                    