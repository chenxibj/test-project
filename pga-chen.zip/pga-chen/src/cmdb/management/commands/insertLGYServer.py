from django.core.management.base import BaseCommand
from pga.settings import BASE_DIR
from cmdb.utils.serverUtils import insertNewSingleServer
from os.path import isfile
from pga.utils.logUtils import createLogger
from cmdb.utils.dnsUtils import setDomain
from cmdb.models import Idc

class Command(BaseCommand):
    
    def add_arguments(self, parser):
        parser.add_argument('file_name', type=str)
        
    def handle(self, *args, **options):
        
        lger = createLogger()
        
        file_name = options['file_name']
        ipList = BASE_DIR + '/resources/lists/' + file_name
        
        if not isfile(ipList):
            print ipList, ' file not exists'
            return
        
        with open(ipList,'r') as f:
            
            while True:
                ips = f.readline().strip('\n')
                if not ips:
                    break  
                ips = ips.strip().split(',')    
                eth0 = ips[0].strip()
                hostname = ips[1].strip()
                idc = ips[2].strip()
                if idc != 'bj100':
                    print 'idc %s is not bj100, pass' % idc
                    continue
                server = insertNewSingleServer(eth0, hostname, idc, 2, lger)
                if not server:
                    continue                
                setDomain(server.domain, server.eth0, lger)
             
                #break
                