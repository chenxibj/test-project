from django.core.management.base import BaseCommand, CommandError  
from pga.settings import TMP_DIR
from pga.utils.fileutils import get_content_from_file
from cmdb.models import Server, Product

class Command(BaseCommand):
    def handle(self, *args, **options):
       
        b2b_dir = TMP_DIR + 'b2bitems' 
        filepath = b2b_dir + '/server.list'
        json_data = get_content_from_file(filepath)
        
        if json_data["code"] != "0" :
            print json_data['data']
            return
        content = json_data['data']
        querysetlist = []
        product = Product.objects.get(id = 3)
        for server in content.split('\n'):
            #print server
            try:
                items = server.split(" ")
                name = items[0]
                ip = items[1]
            except:
                pass
            if name and ip:
                if not Server.objects.filter(eth0 = ip):
                    querysetlist.append(Server(ilo=ip,eth0=ip,inuse=0,product=product,hostname=name))  

        Server.objects.bulk_create(querysetlist)
        
        
        
        