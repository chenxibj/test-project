from django.core.management.base import BaseCommand
from cmdb.models import Server
from cmdb.utils.serverUtils import eth02eth1, getEth1Gateway
from pga.utils.logUtils import createLogger, toUMP
from pga.settings import BASE_DIR
from os.path import isfile

class Command(BaseCommand):

    def add_arguments(self, parser):
        parser.add_argument('file_name', type=str)
                
    def handle(self, *args, **options):
                
        #logger = createLogger()        
        #servers = Server.objects.select_related().all()
        
        file_name = options['file_name']
        ipList = BASE_DIR + '/resources/lists/' + file_name

        if not isfile(ipList):
            print ipList, ' file not exists'
            return
        
        with open(ipList,'r') as f:
            while True:
                l = f.readline().strip('\n')
                if not l:
                    break
                ip = l.strip().strip('\n')
                
                server = Server.objects.get(eth0=ip)
                server.hostname = server.domain
                server.domain_status = 'relevant'
                server.save()
            
            #break
        