from django.core.management.base import BaseCommand
from cmdb.models import Server
from cmdb.utils.serverUtils import hostname2Domain
from cmdb.utils.dnsUtils import setDomain
from pga.utils.logUtils import createLogger, toUMP

class Command(BaseCommand):
        
    def handle(self, *args, **options):
                
        logger = createLogger()        
        servers = Server.objects.select_related().all()
        
        for server in servers:
            eth0 = server.eth0
            hostname = server.hostname
            idc = server.idc.name
            
            domain = hostname2Domain(hostname, idc)
            
            print eth0, hostname, idc, domain
            
            server.domain = domain
            try:
                server.save()
                msg = 'update server successfully: ' + eth0 + ' ' + domain
                logger.debug(msg)
            except:
                detail = 'save server failed: ' + eth0 + ' ' + domain
                key = 'PGA.server.update'
                toUMP(detail, key)
            finally:            
                setDomain(domain, eth0, logger)
            
            #break
        