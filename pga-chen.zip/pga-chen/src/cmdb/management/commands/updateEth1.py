from django.core.management.base import BaseCommand
from cmdb.models import Server
from cmdb.utils.serverUtils import eth02eth1, getEth1Gateway
from pga.utils.logUtils import createLogger, toUMP

class Command(BaseCommand):
        
    def handle(self, *args, **options):
                
        logger = createLogger()        
        servers = Server.objects.select_related().all()
        
        for server in servers:
            eth0 = server.eth0
            eth1 = eth02eth1(eth0)
            eth1gateway = getEth1Gateway(eth0)
            
            print eth0, eth1, eth1gateway
            
            server.eth1 = eth1
            server.eth1gateway = eth1gateway
            try:
                server.save()
                msg = 'update server successfully: ' + eth0 + ' ' + eth1
                logger.debug(msg)
            except:
                detail = 'save server failed: ' + eth0 + ' ' + eth1
                key = 'PGA.server.update'
                toUMP(detail, key)
            
            #break
        