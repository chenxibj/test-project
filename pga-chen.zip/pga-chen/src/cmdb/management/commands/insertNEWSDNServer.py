from django.core.management.base import BaseCommand
from pga.settings import BASE_DIR
from cmdb.utils.serverUtils import insertNewSingleServer,\
    insertNEWSDNSingleServer
from os.path import isfile
from pga.utils.logUtils import createLogger
from cmdb.utils.dnsUtils import setDomain
from cmdb.utils.ansibleUtils import ansibleWrapper
class Command(BaseCommand):
    
    def add_arguments(self, parser):
        parser.add_argument('file_name', type=str)
        
    def handle(self, *args, **options):
        
        lger = createLogger()
        
        file_name = options['file_name']
        ipList = BASE_DIR + '/resources/lists/' + file_name
        
        if not isfile(ipList):
            print ipList, ' file not exists'
            return
        
        with open(ipList,'r') as f:
            
            while True:
                ips = f.readline().strip('\n')
                if not ips:
                    break  
                ips = ips.strip().split(',')    
                eth0 = ips[0].strip()
                hostname = ips[1].strip()
                idc = ips[2].strip()
                rack = ips[3].strip()
                serverModule = ips[4].strip() if len(ips) == 5 else 'NoModule'
                if idc not in ["bj02","gz02","sq02","bj01","gz01","sq01"] :
                    print 'idc %s will not use this script, try other script ' % idc
                    continue
#                ResultContent = ansibleWrapper('%s,' % eth0, 'all', BASE_DIR + '/cmdb/utils/init.sh')
                server = insertNEWSDNSingleServer(eth0, hostname, idc, rack, serverModule, 2, lger)
#                 if not server:
#                     continue
                
                setDomain(server.domain, server.eth0, "prod",lger)
             
                #break
                