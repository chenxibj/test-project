from django.core.management.base import BaseCommand
from pga.settings import BASE_DIR
from cmdb.models import Server

class Command(BaseCommand):
    def handle(self, *args, **options):
        ipList = BASE_DIR + '/resources/lists/ipChangeList.mirror.gu'
        
        with open(ipList,'r') as f:
            
            while True:
                ips = f.readline().strip('\n')
                if not ips:
                    break  
                ips = ips.strip().split('\t')    
                oIlo = ips[0]
                nIlo = ips[1]
                oEth0 = ips[2]
                nEth0 = ips[3]
                hostName = ips[4]
                
                #print oIlo,nIlo,oEth0,nEth0
                try:
                    p = Server.objects.get(ilo = oIlo)
                    p.ilo = nIlo
                    p.save()
                except:
                    pass
                p = Server.objects.get(ilo = nIlo)
                p.eth0 = nEth0
                p.hostname = hostName
                p.save()
            
                        
                    