from chefapi.utils.vdrUtils import getGatewayIP, eth02VDR, getVDRips
from cmdb.config import NEW_SDN_VDR
from netaddr import IPNetwork, IPAddress


eth0 = '172.19.2.98'
idc = 'bj02'
env = 'prod'

r = getVDRips(eth0,idc,env)
print r

