#coding:utf-8
from cmdb.models import Service, Unit,Env, Idc, Soft

''' 过期了
def get_serversincluster_json_by_clusterid(cluster_id):
    
    #return cluster_servers = [
    #    {"component_id":0,"component_name":"unused","servers" :  [server1.eth0,server2.eth0 ...]},
    #    {"component_id":xx,"component_name":"xx","servers" :  [server1.eth0,server2.eth0 ...]},
    #    {"component_id":xxx,"component_name":"xxx","servers" :  [server1.eth0,server2.eth0 ...]},
    #        ...
    #]
    
  
    cluster = Service.objects.select_related().get(id = cluster_id)
    components = Soft.objects.filter(product_name = cluster.name)
    servers_incluster = ServerInCluster.objects.select_related().filter(cluster_id = cluster_id)
    servers_incomponent = ServerInComponent.objects.select_related().filter(server_id__in = servers_incluster.values_list('server_id', flat=True))
    
    cluster_servers = []
    for component in components:
        servers_component = []
        for server_incomponent in servers_incomponent:
            if component.id == server_incomponent.component_id:
                servers_component.append(server_incomponent.server)
        cluster_servers.append({"component_id":component.id,"component_name":component.name,"servers":servers_component})     
    
    servers_unused = []
    for server_incluster in servers_incluster:
        flag = 0
        for server_incomponent in servers_incomponent:
            if server_incomponent.server_id == server_incluster.server_id:
                flag = 1
        if flag == 0:
            servers_unused.append(server_incluster.server)
    cluster_servers.append({"component_id":0,"component_name":"unused","servers":servers_unused})   
    
    return servers_incluster, cluster, components, cluster_servers
'''
import json

def get_clusters_by_productid(product_id=2):
    '''返回  按照 env,service,idc界定后的   所有 serviceunit集合'''
    
    services = Service.objects.filter(product_id = product_id)
    unit_objs = Unit.objects.select_related().filter(service_id__in = services.values_list('id', flat=True))
    for unit_obj in unit_objs:
        servers = []
        server_objs = unit_obj.serverinunit_set.all()
        for server_obj in server_objs:
            servers.append(server_obj.server)
        unit_obj.servers = servers

    envs = Env.objects.all()
    idcs = Idc.objects.all()    
        
    clusters = []
    empty_clusters = []
    for env in envs:
        for idc in idcs:
            for service in services:
                units = []
                for unit_obj in unit_objs:
                    if unit_obj.idc_id == idc.id and unit_obj.env_id == env.id and unit_obj.service_id == service.id:
                        units.append(unit_obj)
                cluster_name = env.name + '.' + service.name + '.'+ idc.name
                cluster_id = str(env.id)+'.'+str(service.id)+'.'+str(idc.id)
                if units != []:
                    clusters.append({"idc":idc,"env":env,"service":service,"name":cluster_name,"id":cluster_id,'units':units})
                else:
                    empty_clusters.append({"idc":idc,"env":env,"service":service,"name":cluster_name,"id":cluster_id,'units':units})
            
    return (clusters,empty_clusters)

def get_cluster_tree_by_productid(product_id=2):
    services = Service.objects.filter(product_id = product_id)
    unit_objs = Unit.objects.select_related().filter(service_id__in = services.values_list('id', flat=True))

    envs = Env.objects.all()
    idcs = Idc.objects.all()    
        
    clusters = []
    empty_clusters = []
    for env in envs:
        for idc in idcs:
            for service in services:
                units = []
                for unit_obj in unit_objs:
                    if unit_obj.idc_id == idc.id and unit_obj.env_id == env.id and unit_obj.service_id == service.id:
                        units.append(unit_obj)
                cluster_name = env.name + '.' + service.name + '.'+ idc.name
                cluster_id = str(env.id)+'.'+str(service.id)+'.'+str(idc.id)
                if units != []:
                    clusters.append({"idc":idc,"env":env,"service":service,"name":cluster_name,"id":cluster_id,'units':units})
                else:
                    empty_clusters.append({"idc":idc,"env":env,"service":service,"name":cluster_name,"id":cluster_id,'units':units})
            
    return clusters

def get_cluster_by_service(service):
    envs = Env.objects.all()
    idcs = Idc.objects.all()
    clusters = []
    for env in envs:    
        for idc in idcs:
            unit_obj = Unit.objects.filter(service = service, env= env, idc=idc)
            if len(unit_obj) > 0:
                cluster_name = env.name + '.' + service.name + '.'+ idc.name
                cluster_id = str(env.id)+'.'+str(service.id)+'.'+str(idc.id)
                clusters.append(dict(cluster_name=cluster_name,cluster_id=cluster_id))
    return clusters           
    
def get_cluster_by_id(product_id,cluster_id):
    '返回一个指定 cluster_id 的cluster'
    clusters,empty_clusters = get_clusters_by_productid(product_id)
    for cluster in clusters:
        if cluster['id'] == cluster_id:
            return cluster
    for cluster in empty_clusters:
        if cluster['id'] == cluster_id:
            return cluster
    return []
    
def get_tags_by_clusterid(cluster_id):
    '''cluster_id = str(env.id)+'.'+str(service.id)+'.'+str(idc.id)'''
    items = cluster_id.split('.')
    env_id = items[0]
    service_id = items[1]
    idc_id = items[2]
    
    env = Env.objects.get(id=env_id)
    service = Service.objects.select_related().get(id=service_id)
    idc = Idc.objects.get(id=idc_id)
    soft_objs = service.softinservice_set.all()
    softs = []
    for soft_obj in soft_objs:
        softs.append(soft_obj.soft)
    
    return (env,service,softs,idc)
    
    
def get_logs_by_softid(soft_id):
    
    soft = Soft.objects.get(id=soft_id)
    if not soft:
        return []
    
    process_vars = soft.process_vars
    try:
        processes = json.loads(process_vars) 
        logs = []
        for process in processes:
            for log in process["logs"]:
                logs.append({"path":log,"name":process["name"]})
        return logs
    except:
        return []

def getEnvIdcDict():
    
    envs = Env.objects.all()
    idcs = Idc.objects.all()
    
    d = {}
    for env in envs:
        d[env.name] = {}
        for idc in idcs:
            d[env.name][idc.name] = None
    return d

def getProcessvarsFromSoft():
    
    r = {}
    services = Service.objects.select_related().all()
    for service in services:
        r[service.name] = {}
        siss = service.softinservice_set.select_related().all()
        for sis in siss:
            processvars = sis.soft.process_vars
            try:
                p = json.loads(processvars)
            except:
                p = {} 
            r[service.name][sis.soft.name] = dict(processvars = p)
    return r
    
    