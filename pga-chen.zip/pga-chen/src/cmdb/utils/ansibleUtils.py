#encoding=utf-8
from collections import namedtuple
from ansible.parsing.dataloader import DataLoader
from ansible.vars import VariableManager
from ansible.inventory import Inventory
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
'''
Created on 2016年6月19日

@author: jd.com
'''

class ansibleWrapper(object):
    '''
    classdocs
    '''
    def __init__(self, inventory_path, hostGroupName, script_path, forks = 25):
        '''
        e.g.
        inventory_path: inventory/iaas_huangcun
        hostGroupName: os-compute (group name of the inventory)
        script_path: scripts/monitor_process_cpu_util.sh (can be with parameters)
        '''
        self.hostGroupName = hostGroupName
        Options = namedtuple('Options', ['connection', 'forks', 'module_path', 'become', 'become_method', 'become_user', 'check'])
        # initialize needed objects
        variable_manager = VariableManager()
        loader = DataLoader()
        options = Options(connection='ssh', module_path=None, forks=forks, become=None, become_method=None, become_user=None, check=False)
        #passwords = {}
        passwords = {'conn_pass':'1qaz@WSX'}
        
        # create inventory and pass to var manager
        inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=inventory_path)
        variable_manager.set_inventory(inventory)
        
        # create play with tasks
        play_source =  dict(
                name = "Monitor " +hostGroupName + " process",
                hosts = hostGroupName,
                gather_facts = 'no',
                tasks = [
                    dict(action=dict(module='script', args=script_path), register='shell_out'),
                    dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
                 ]
            )
        play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
           
        # actually run it
        self.tqm = None
        try:
            self.tqm = TaskQueueManager(
                      inventory=inventory,
                      variable_manager=variable_manager,
                      loader=loader,
                      options=options,
                      passwords=passwords,
                      stdout_callback='default',
                  )
            self.tqm.run(play)
            
            self.failed_hosts = self.tqm._failed_hosts.keys()
            self.unreachable_hosts = self.tqm._unreachable_hosts.keys()
            self.hosts = self.tqm.hostvars._inventory._pattern_cache[hostGroupName]
            l = []
            for host in self.hosts:
                if str(host) not in self.failed_hosts and str(host) not in self.unreachable_hosts:
                    l.append(str(host))
            self.succeed_hosts = l
#            print self.failed_hosts
#            print self.unreachable_hosts
#            print self.succeed_hosts
#            for node in compute_nodes:
#                print(tqm.hostvars[str(node)]['shell_out']['stdout'])
        finally:
            if self.tqm is not None:
                self.tqm.cleanup()
    
    def getEffectedHosts(self):
        
        return self.hosts
       
    def getFailedHosts(self):
        
        return self.failed_hosts
        
    def getUnreachableHosts(self):
        
        return self.unreachable_hosts
    
    def getSucceedHosts(self):
        
        return self.succeed_hosts

    def getOutput(self):
        
        d = []
        for host in self.succeed_hosts:
            #print self.tqm.hostvars[str(host)]['shell_out']
            outputs = self.tqm.hostvars[str(host)]['shell_out']['stdout'].split('###')
            runner_status = outputs[0].strip()
            try:
                runner_msg = outputs[1].strip()
            except:
                runner_msg = "no out put"
        
            d.append(dict(host=host,runner_status=runner_status,runner_msg=runner_msg))
        
        self.output = d
        # Start Add by wanghaichao at 2016/09/07
        return self.output
        # Add End
    
    def printDebug(self):
        
        print "hostgroup name:", self.hostGroupName
        print "Effect hosts:"
        print self.hosts
        print "unreachable_hosts:"
        print self.unreachable_hosts
        print "failed hosts:"
        print self.failed_hosts
        
        print "run result:"
        for result in self.output:
            print result['host'],result['runner_status'],result['runner_msg'] 
