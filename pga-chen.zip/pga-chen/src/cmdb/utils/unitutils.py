#coding:utf-8
from cmdb.models import ServerInUnit
import json

def get_servers_by_unitid(unit_id):
    
    servers = []
    
    servers_in_unit = ServerInUnit.objects.select_related().filter(unit_id = unit_id)
    for server_obj in servers_in_unit:
        server = server_obj.server
        servers.append(server)
    
    return servers  

def apiGetServerIPsByUnits(units):
    
    data = {}
    for unit in units:
        data[unit.soft.name] = []
        for server_obj in unit.serverinunit_set.all():
            data[unit.soft.name].append(server_obj.server.eth0)
    return data
    
def apiGetServersByUnits(units, details=False):

    data = {}
    for unit in units:
        data[unit.soft.name] = {}
        serverList= []
        for server_obj in unit.serverinunit_set.all():
            
            serverDict = getServerDict(server_obj)
            serverDict['idc'] = unit.idc.name
            serverDict['env'] = unit.env.name
            
#            print server_obj.vars
            try:
                server_obj_vars = json.loads(server_obj.vars)
#                print server_obj_vars
#                print server_obj_vars["mirror"]
                if server_obj_vars.has_key("mirror") and server_obj_vars["mirror"]:
#                    print server_obj_vars["mirror"]
                    data[unit.soft.name]["mirror"] = serverDict
            except:
                pass
                    
            serverList.append(serverDict)
        data[unit.soft.name]["servers"] = serverList
    return data

def getServerDict(so):
    
    return dict(ip=so.server.eth0, hostname=so.server.hostname,alarmon=so.enabled)

def getServerVars(siu):
    
    try:
        server_vars = json.loads(siu.vars)
        return server_vars
    except:
        return {}

def getAllServerVars(unit):
    
    try:
        unit_vars = json.loads(unit.vars)
    except:
        unit_vars = {}
    sius = unit.serverinunit_set.all()
    for siu in sius:
        server_vars = getServerVars(siu)
        for k,v in unit_vars.items():
            if not server_vars.has_key(k):
                server_vars[k] = v
        siu.server_vars = server_vars
    return sius
    