#encoding=utf-8
import re
from cmdb.models import Idc, Server, Product
from pga.utils.logUtils import createLogger
from cmdb.config import NEW_SDN_ETH1
from netaddr import IPNetwork, IPAddress

def eth02Ilo(eth0):
    
    isIP(eth0)
    if not eth0.startswith('172'):
        raise ValueError('eth0: %s is not start with 172' % eth0)
    
    ilo = re.sub(r'^172','10',eth0)
    return ilo

def eth02IloSqgov(eth0):
    
    isIP(eth0)
    if not eth0.startswith('10.239.'):
        raise ValueError('eth0: %s is not start with 10.239.' % eth0)
    
    ilo = re.sub(r'^10.239.252','10.239.251',eth0)
    return ilo

def eth02eth1(eth0):
    
    isIP(eth0)
    ss = eth0.split('.')
    eth1 = ('10.0.%s.%s' % (ss[2],ss[3]))
    return eth1

def eth02eth1hk(eth0):
    
    isIP(eth0)
    ss = eth0.split('.')
    eth1 = ('10.239.0.%s' % ss[3])
    return eth1    

def eth02eth1LGY(eth0):
    
    isIP(eth0)
    ss = eth0.split('.')
    eth1 = ('10.239.1.%s' % ss[3])
    return eth1     

def eth02eth1NEWSDN(eth0, idc):
    
    isIP(eth0)
    cidr, eth1_cidr = getNEWSDNcidr(eth0, idc)
    eth0_start = IPNetwork(cidr)[0]
    eth1_start = IPNetwork(eth1_cidr)[0]
    
    eth1_int = IP2Int(eth0) - eth0_start.value + eth1_start.value
    eth1 = int2IP(eth1_int)
    
    return eth1

def IP2Int(ip):
    isIP(ip)
    f = lambda x:sum([256**j*int(i) for j,i in enumerate(x.split('.')[::-1])])
    return f(ip)

def int2IP(i):
    f =  lambda x: '.'.join([str(x/(256**i)%256) for i in range(3,-1,-1)])
    return f(i)
   
def hostname2Domain(hostname, idc):
    
    if not hostname.endswith('.JD.LOCAL'):
        raise ValueError('hostname: %s is not end with .JD.LOCAL' % hostname)
    idc = idcConverter(idc).upper()
    domain = re.sub(r'\.JD\.LOCAL$', '.' + idc + '.JCLOUD.COM',hostname)
    return domain

def hostname2DomainSqgov(hostname, idc):
    
    if not hostname.endswith('.JD.LOCAL'):
        raise ValueError('hostname: %s is not end with .JD.LOCAL' % hostname)
    idc = idcConverter(idc).upper()
    domain = re.sub(r'\.JD\.LOCAL$', '.' + idc + '.SQGOV.LOCAL',hostname)
    return domain

def splitLine(line):
    
    return re.split(r'[;,\s]\s*', line)

def idcConverter(idc):
    
    convs = {
        "gz01":["gz","gz01"],
        "bj01":["hb","bj01"],
        "sq01":["sq","hd","sq01"],
        "hk01":["hk01"],
        "bj100": ["bj100"],
        "bj02":["bj02"],
        "gz02":["gz02"],
        "sq02":["sq02"],
    }
    for toIdc, conv in convs.items():
        if idc in conv:
            return toIdc
        
    raise ValueError('idc: %s is not in supportted idc list' % idc)
    

def isIP(s):
    p = r'^([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])$'
    if not re.match(p, s):
        raise ValueError('string: %s is not an ipaddress ' % s)

def getNEWSDNcidr(s,idc):
    if not NEW_SDN_ETH1['prod'].has_key(idc):
        raise ValueError('idc: %s is not an NEWSDN idc ' % idc)
    for cidr in NEW_SDN_ETH1['prod'][idc]:       
        if IPAddress(s) in IPNetwork(cidr):
            return cidr, NEW_SDN_ETH1['prod'][idc][cidr]
#     print ips[0],ips[1]
#     print type(ips)
#     print type(ips[0])
#     print type(s)
    raise ValueError('string: %s is not an NEWSDN ipaddress ' % s)

def getEth1Gateway(eth1):
    isIP(eth1)
    ss = eth1.split('.')
    return ('%s.%s.%s.254' % (ss[0],ss[1],ss[2]))

def insertSingleServer(eth0, hostname, idc, product_id = 2, lger = None):
    
    if not lger:
        lger = createLogger()
    
    isIP(eth0)    
    ilo = eth02Ilo(eth0)
    idc = idcConverter(idc)
    idcObj = Idc.objects.get(name=idc)
    domain = hostname2Domain(hostname, idc)
    eth1 = eth02eth1(eth0)
    eth1gateway = getEth1Gateway(eth1)
    productObj = Product.objects.get(id=product_id)
    
    server = Server(ilo=ilo,hostname=hostname,product=productObj,idc=idcObj,eth0=eth0,eth1=eth1,eth1gateway=eth1gateway,domain=domain)
    try:
        server.save()
        msg = 'create server successfully ' + eth0 + ' ' + hostname +' ' +  domain
        print msg
        lger.debug(msg)
        return server
    except Exception as e:
        print 'save server ', eth0, ' failed, reason: ', str(e)
        msg = 'create server failed ' + eth0 + ' ' + hostname + ' ' + domain +  ' cause of ' + str(e)
        lger.error(msg)
        return False

def insertNewSingleServer(eth0, hostname, idc, product_id = 2, lger = None):
    '''
    唯一的区别是要将hostname设置为domain，将domain_status设置为relevant
    '''
    
    if not lger:
        lger = createLogger()
    
    isIP(eth0)    
    ilo = eth02Ilo(eth0)
    print idc
    idc = idcConverter(idc)
    idcObj = Idc.objects.get(name=idc)
    domain = hostname2Domain(hostname, idc)
    if idc == 'hk01':
        eth1 = eth02eth1hk(eth0)
    elif idc == 'bj100':
        eth1 = eth02eth1LGY(eth0)
            
    else:
        eth1 = eth02eth1(eth0)
    eth1gateway = getEth1Gateway(eth1)
    productObj = Product.objects.get(id=product_id)
    
    print ilo,domain,productObj.name, idcObj.name
    server = Server(ilo=ilo,hostname=domain,product=productObj,idc=idcObj,eth0=eth0,eth1=eth1,eth1gateway=eth1gateway,domain=domain,domain_status='relevant')
    try:
        server.save()
        msg = ('save server %s,%s relevant successfully' % (eth0,hostname))
        print msg
        lger.debug(msg)
        return server
    except Exception as e:
        msg = ('save server %s,%s relevant failed, reason: %s ' % (eth0,hostname, e))
        print msg
        lger.error(msg)
        return False

def insertNEWSDNSingleServer(eth0, hostname, idc, rack, serverModule,product_id = 2, lger = None):
    '''
    区别是要将hostname设置为domain，将domain_status设置为relevant
    还要配置个性化的eth1
    '''
    
    if not lger:
        lger = createLogger()
    
    isIP(eth0)    
    ilo = eth02Ilo(eth0)
    idc = idcConverter(idc)
    idcObj = Idc.objects.get(name=idc)
    domain = hostname2Domain(hostname, idc)
#    eth1 = eth02eth1NEWSDN(eth0, idc)
    
#    eth1gateway = getEth1Gateway(eth1)
    productObj = Product.objects.get(id=product_id)
    
    print ilo,domain,productObj.name, idcObj.name
    server = Server(ilo=ilo,hostname=domain,product=productObj,idc=idcObj,eth0=eth0,domain=domain,domain_status='relevant',rack=rack,serverModule=serverModule)
    try:
        server.save()
        msg = ('save server %s,%s relevant successfully' % (eth0,hostname))
        print msg
        lger.debug(msg)
        return server
    except Exception as e:
        msg = ('save server %s,%s relevant failed, reason: %s ' % (eth0,hostname, e))
        print msg
        lger.error(msg)
        server = Server.objects.get(eth0=eth0)
        return server

def insertSqgovSingleServer(eth0, hostname, idc, rack, serverModule, product_id = 2, lger = None):
    '''
    区别是要将hostname设置为domain，将domain_status设置为relevant
    还要配置个性化的eth1
    '''
    
    if not lger:
        lger = createLogger()
    
    isIP(eth0)    
    ilo = eth02IloSqgov(eth0)
    idc = idcConverter(idc)
    idcObj = Idc.objects.get(name=idc)
    domain = hostname2DomainSqgov(hostname, idc)
#    eth1 = eth02eth1NEWSDN(eth0, idc)
    
#    eth1gateway = getEth1Gateway(eth1)
    productObj = Product.objects.get(id=product_id)
    
    print ilo,domain,productObj.name, idcObj.name
    server = Server(ilo=ilo,hostname=domain,product=productObj,idc=idcObj,eth0=eth0,domain=domain,domain_status='relevant',rack=rack,serverModule=serverModule)
    try:
        server.save()
        msg = ('save server %s,%s relevant successfully' % (eth0,hostname))
        print msg
        lger.debug(msg)
        return server
    except Exception as e:
        msg = ('save server %s,%s relevant failed, reason: %s ' % (eth0,hostname, e))
        print msg
        lger.error(msg)
        server = Server.objects.get(eth0=eth0)
        return server
