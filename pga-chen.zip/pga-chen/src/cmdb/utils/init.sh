#!/usr/bin/env bash
#
#
#

test ! -d /root/.ssh && mkdir /root/.ssh
cd /root/.ssh
touch authorized_keys
chmod 600 authorized_keys
chown root.root authorized_keys

echo 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDBHJbvR8JyEla+5uQ4aS0yz4XXQTJnD7gSVmRRlLkZ7XyjXOIiNILYXMCd8Sf7vhI85fGrSe1QJn+lg4xfKeW+kgY68Zq0H6hryKoIRrEaPu1gJYMxQhzzGBsNW8/pX9s/ryWWPCDkS7EiouhlqLNGq9lTkEtnl1r9wSNsI39w0/mOGfmh54fa8ZZc5sgL2ezcq8y1hnjLtK0aFFbHwOmxpZ4VD0abZFRu3ZkccnnXXnDp0bY38Did01ji+yxtnnI1fzw2dZavpUl+IBR307aXD+EFZQZgBGz5m2wiT/Q5uh8h8JO2DIOFfZCeL4GrrnP6+S4OmRGTkF/dNgLxZbXf root@iaas_base.jcloud.com' >> authorized_keys

sed -i 's/^root:[^:]*/root:$1$y8Dh2DFV$dJEdIE\/gd1OjOMlv90LCl1/g' /etc/shadow
