import requests
import json
from pga.utils.logUtils import toUMP, createLogger
from pga.utils.alarmUtils import callSendmail



def getDomain(ip):
    
    url_getdomain = 'http://dnsapi.jcloud.com/dns/pub/getdomain'
    
    data = {
        "ip":[
              ip
        ]
    }
    
    r = requests.post(url_getdomain, json = data).json()
    print r


def setDomain(domain, ip , env="prod", logger=None):

#    url_update = 'http://dnsapi.jcloud.com/dns/pub/update'
    
    dnsapi_url = "http://172.27.33.31:9080/dnsapi/setdns/{}/{}/{}/".format(ip,domain,env)
    try:
        r = requests.get(dnsapi_url)
    
        print r.content
    except Exception as e:
        print 'set DNS failed: ', ip ,' to ' , domain , ' cause of ' , e
    
    
#     if not logger:
#         logger = createLogger()  
#     
#     data = [
#         {
#             "domain": domain +".", 
#             "records":[
#                 ip
#             ],
#     #         "view":[
#     #             "view-internals"
#     #         ],
#     #         "type":"A"
#         }
#     ]
#     try:
#         r = requests.post(url_update, json = data).json()
#     except Exception as e:
#         detail = 'set DNS failed: ' + ip + ' to ' + domain + ' cause of ' + e
#         key = 'PGA.dnsapi.create'
#         toUMP(detail, key)
#         return
#        
#     if r['status']:
#         msg = 'set DNS successfully ' + ip + ' to ' + domain
#         #callSendmail(msg, 'PGA issue')
#         logger.debug(msg)
#     else:
#         detail = 'set DNS failed: ' + ip + ' to ' + domain + ' cause of ' + json.dumps(r)
#         callSendmail(detail, 'PGA issue')
#         key = 'PGA.dnsapi.create'
#         toUMP(detail, key)
    
    
    
    