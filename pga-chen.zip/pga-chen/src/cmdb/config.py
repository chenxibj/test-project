#encoding=utf8

serverMassUpdateColumns = ["serverModule"]

#offline @20170203 by madongdong1@jd.com

NEW_SDN_ETH1 = {
                "prod": {
                    "bj02": {
                             "172.19.0.0/19": "10.255.0.0/19",
                             
                    },
                }
}

NEW_SDN_VDR = {
               "prod":{
                   "bj02": {
                            "172.19.2.0/24": {
                                    "netmask": "255.255.255.224",
                                    "dv": {
                                           "cidr": "10.254.2.0/24",
                                           "netmask": "255.255.255.0"
                                           },
                                    "vv": {
                                           "cidr": "10.254.3.0/24",
                                           "netmask": "255.255.255.224"
                                           },
                                    "ds": {
                                           "cidr": "10.254.1.0/24",
                                           "netmask": "255.255.255.224"
                                           },
                                    "dbgp":{
                                           "cidr": "10.254.0.0/24",
                                           "netmask": "255.255.255.224"
                                           },
                   
                            }
                    }
                }
    }

NEW_SDN_AS = {
    "prod": {
        "bj02": {
            "2B-B-19": (65401,65501),
            "2B-C-17": (65402,65501),
            "2C-C-01": (65403,65501),
            "2C-D-01": (65404,65501)         
        }                   
    }   
}