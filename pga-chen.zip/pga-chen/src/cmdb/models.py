#coding:utf-8
from __future__ import unicode_literals

from django.db import models
from django.forms.models import ModelForm
import datetime
from django.contrib.auth.models import User

# Create your models here.
'''
基本表：
    0 基本单元： server
    1 独立实体： idc, env, service, Soft
    2 逻辑实体表：platform, product    platform->product->service
    3 组合表： unit: 树最小单元，由 idc, env, service, soft共同定义
    4 多对多关联表： softinservice: service - Soft ,用于二级联动
    5 多对多关联表： serverinunit: server - unit, 用于将服务器分配给服务单元

    0 外键        server.product, 用于将服务器分配给一个产品线
           server。inuse, 用于冗余存储一个服务器是否被分配至
           unit.idc unit.env unit.service unit.Soft 用于定义unit
           service.product  product.platform 用于向上寻找组织
'''
class Server(models.Model):
    ''' 服务器信息  隶属于server'''
    ilo = models.CharField(unique=True, max_length=15)
    hostname = models.CharField(blank=True, null=True, max_length=50)
    domain = models.CharField(blank=True, null=True, max_length=50)
    domain_status = models.CharField(default='irrelevant', max_length=10)
    product = models.ForeignKey('Product',default=1)
    idc = models.ForeignKey('Idc',default=9999)
    inuse = models.BooleanField(default=0)
    eth0 = models.CharField(unique=True, max_length=15)
    eth1 = models.CharField(blank=True, null=True, max_length=15)
    eth1gateway = models.CharField(blank=True, null=True, max_length=15)
    cpu = models.CharField(max_length=20,blank=True, null=True)
    ccpu = models.IntegerField(blank=True, null=True)
    mem = models.IntegerField(blank=True, null=True)
    cmem = models.IntegerField(blank=True, null=True)
    disk = models.IntegerField(blank=True, null=True)
    rdisk = models.IntegerField(blank=True, null=True)
    cdisk = models.IntegerField(blank=True, null=True)
    zbx_hostid = models.IntegerField(default=0)
    rack = models.CharField(max_length=100,blank=True, null=True)
    serverModule = models.CharField(max_length=100, default='NoModule')
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)
    remark1 = models.CharField(max_length=100,blank=True, null=True)
    remark2 = models.CharField(max_length=100,blank=True, null=True)
    remark3 = models.CharField(max_length=100,blank=True, null=True) 
    
    def __unicode__(self):
        return self.eth0

class Idc(models.Model):
    ''' 机房信息   '''
    name = models.CharField(unique=True, max_length=50)
    description = models.CharField(max_length=50, null=True)
    
    protected = models.BooleanField(default=0)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)
    
    def __unicode__(self):
        return self.name

class IdcForm(ModelForm):
    ''' 来个product的表单  '''
    class Meta:
        model = Idc
        fields = ('name','description')
    
class Env(models.Model):
    ''' 环境信息  online mirror test dev '''
    name = models.CharField(unique=True, max_length=15)
    description = models.CharField(max_length=50, null=True)
    protected = models.BooleanField(default=0)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)
    
    def __unicode__(self):
        return self.name

class EnvForm(ModelForm):
    ''' 来个product的表单  '''
    class Meta:
        model = Env
        fields = ('name','description')
    
class Service(models.Model):
    ''' 服务器集群信息 '''
    name = models.CharField(unique=True, max_length=50)
    description = models.CharField(max_length=50, null=True)
    product = models.ForeignKey('Product')
    protected = models.BooleanField(default=0)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)
    
    def __unicode__(self):
        return self.name
    
class Soft(models.Model):
    ''' 项目各组件  nginx mysql keystone ... '''
    name = models.CharField(max_length=50)
    description = models.CharField(max_length=50, blank=True, null=True)
    protected = models.BooleanField(default=0)
    process_vars = models.CharField(max_length=1500, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)    
    def __unicode__(self):
        return self.name

class SoftForm(ModelForm):
    ''' 来个product的表单  '''
    class Meta:
        model = Soft
        fields = ('name','description','process_vars')

class Platform(models.Model):
    ''' 业务平台  : cloud'''
    name = models.CharField(unique=True, max_length=15)
    
    def __unicode__(self):
        return self.name

class Product(models.Model):
    ''' 项目   IaaS SaaS'''
    name = models.CharField(unique=True, max_length=15)
    # 项目来源： openstack源生 kilo Lxx 。。 或二次开发 re-developement 或自研扩展 extension
    description = models.CharField(max_length=50, null=True)
    # 项目与openstak子项目关联
    platform = models.ForeignKey(Platform)
    this_pga = models.BooleanField(default=0)
    protected = models.BooleanField(default=0)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)
    
    def __unicode__(self):
        return self.name

class ProductForm(ModelForm):
    ''' 来个product的表单  '''
    class Meta:
        model = Product
        fields = ('name','description','platform','this_pga')

class ServiceForm(ModelForm):
    ''' 来个product的表单  '''
    class Meta:
        model = Service
        fields = ('name','description','product')
        
class Unit(models.Model):
    ''' 服务单元 ，树的最小节点 '''
    name = models.CharField(unique=True, max_length=50)
    idc = models.ForeignKey(Idc)
    env = models.ForeignKey(Env)
    service = models.ForeignKey(Service)
    soft = models.ForeignKey(Soft)
    vars = models.CharField(max_length=150, blank=True)
    comment = models.CharField(max_length=150, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)
    
    def __unicode__(self):
        return self.name
    
class UnitForm(ModelForm):
    class Meta:
        model = Unit
        fields = ('vars','comment')
            
class SoftInService(models.Model):   
    soft = models.ForeignKey(Soft)
    service = models.ForeignKey(Service) 
    comment = models.CharField(max_length=150, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)

class ServerInUnit(models.Model):
    server = models.ForeignKey(Server)
    unit = models.ForeignKey(Unit)
    vars = models.CharField(max_length=550, blank=True)
    enabled = models.BooleanField(default=0)
    comment = models.CharField(max_length=150, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)
class ServerInUnitForm(ModelForm):
    class Meta:
        model = ServerInUnit
        fields = ('vars','comment','enabled')

class Toogles(models.Model):
    name = models.CharField(max_length=150, unique=True)
    comment = models.CharField(max_length=150, blank=True, null=True)
    toogle = models.BooleanField(default=0)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)    
    

class RequestLog(models.Model):
    when = models.DateTimeField(default=datetime.datetime.now, db_index=True)
    ip = models.GenericIPAddressField()
    session_key = models.CharField(max_length=32, blank=True, null=True, default=None)
    user = models.ForeignKey(User, null=True, blank=True, default=None)
    user_repr = models.CharField(max_length=255)
    method = models.CharField(max_length=16)
    host = models.CharField(max_length=255)
    path = models.CharField(max_length=4000)  # IE8 limit is ~2048, mssql limit is 4000
    query = models.CharField(max_length=4000)
    post = models.TextField()
    files = models.TextField()
    cookies = models.TextField()
    request_headers = models.TextField()
    response_headers = models.TextField()
    response_status_code = models.IntegerField()
    response_body = models.TextField(blank=True, null=True, default=None)
    total_time = models.FloatField()

    class Meta:
        permissions = (
            ('show_dev_dev_show_project','show_dev_dev_show_project'),
            ('show_cmdb_QuickQuery','show_cmdb_QuickQuery'),
            ('show_cmdb_QuickQuery_show_project','show_cmdb_QuickQuery_show_project'),
            ('show_cmdb_servers','show_cmdb_servers'),
            ('show_cmdb_servers_show_project','show_cmdb_servers_show_project'),
            ('show_cmdb_service_add_project','show_cmdb_service_add_project'),
            ('show_cmdb_service','show_cmdb_service'),
            ('show_cmdb_service_show_project','show_cmdb_service_show_project'),
            ('show_cmdb','show_cmdb'),
            ('show_deploy_cluster','show_deploy_cluster'),
            ('show_deploy_cluster_show_project','show_deploy_cluster_show_project'),
            ('show_deploy_common','show_deploy_common'),
            ('show_deploy_common_show_project','show_deploy_common_show_project'),
            ('show_deploy','show_deploy'),
            ('show_dev_dev','show_dev_dev'),
            ('show_dev','show_dev'),
            ("menu_show_index","menu_show_index"),
            ("menu_show_serverlist","menu_show_serverlist"),
            ("menu_show_tree_modify","menu_show_tree_modify"),
            ("menu_show_log_view","menu_show_log_view"),
            ("menu_show_monitor_config","menu_show_monitor_config"),
            ("show_testobject","show_testobject"),
            ("change_testobject","change_testobject"),
            ("delete_testobject","delete_testobject"),
            ("add_testobject","add_testobject"),
            ("show_serverconfiguration","show_serverconfiguration"),
            ("change_serverconfiguration","change_serverconfiguration"),
            ("delete_serverconfiguration","delete_serverconfiguration"),
            ("add_projectpermissions","add_projectpermissions"),
        )