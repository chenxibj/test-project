'''
Created on 2015年12月10日

@author: madongdong1
'''

class BaseEntity(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        
