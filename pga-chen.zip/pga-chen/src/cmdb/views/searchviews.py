#coding:utf-8
from django.shortcuts import render
from django.http.response import HttpResponse
from cmdb.models import Server
import json

def ajax_search_servers(request):
    
    mimetype = 'application/json'

    if not request.is_ajax():
        return HttpResponse('failed',mimetype)
    
    product_id = request.GET.get('product_id')
    term = request.GET.get('term')
    
    servers = Server.objects.filter(product_id = product_id, eth0__icontains = term)[:20]
    data =[]
    for server in servers:
        data_json = {}
        data_json['id'] = server.id
        data_json['label'] = server.eth0
        data_json['value'] = server.eth0
        data.append(data_json)
        

    return HttpResponse(json.dumps(data),mimetype)