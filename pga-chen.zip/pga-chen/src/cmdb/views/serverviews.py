#coding:utf-8
from django.shortcuts import render
from cmdb.models import Server, Product, Soft, Service, Idc, Env, Unit, ServerInUnit
from django.views.generic.base import View
from django.http.response import HttpResponse
import json

from cmdb.utils.clusterutils import get_clusters_by_productid, get_cluster_by_id
from random import randint
from cmdb.utils.unitutils import get_servers_by_unitid
from django.contrib.auth.decorators import login_required, permission_required
from cmdb.utils.serverUtils import isIP
from cmdb.views.api import getServerInfoByEth0
import requests
from pga.utils.alarmUtils import callSendmail
from cmdb.config import serverMassUpdateColumns
from time import time

# Create your views here.

def server_listallservers(request,template_name,nav):
    print("server_listallservers")
    print(time())
    tree_mode = request.GET.get("tree_mode")
    if not tree_mode or tree_mode =='':
        tree_mode = 'bycluster'
    nodekey = request.GET.get("nodekey")        
        
    if not nodekey or nodekey =='':
        nodekey = 'top'
    nodetype = 'platform'
    if tree_mode == 'bycluster':
        if nodekey == 'top':
            nodetype = 'platform'
            if request.GET.get("nullPoll"):
#                 servers = []
#                 allServers = Server.objects.select_related().all()
#                 for server in allServers:
#                     if not server.serverinunit_set.all():
#                         servers.append(server)
                server_ids = ServerInUnit.objects.all().values("server_id")
                servers = Server.objects.exclude(id__in=server_ids)
                return render(request,template_name,locals())
            servers = Server.objects.select_related().all()
            listname = "<平台>JCLOUD"               
            
        else:
            nodekeys = nodekey.split('-')
            if len(nodekeys) == 1:
                nodetype = 'product'
                product_id = nodekey
                servers = Server.objects.select_related().filter(product_id = product_id)
                listname = u'<产品线>' + Product.objects.get(id = product_id).name 
            elif len(nodekeys) == 2:
                nodetype = 'cluster'
                product_id = nodekeys[0]
                cluster_id = nodekeys[1]
                cluster = get_cluster_by_id(product_id,cluster_id)
                servers = []
                for unit in cluster['units']:
                    servers.extend(get_servers_by_unitid(unit.id))
                servers = list(set(servers))
                listname = u"<集群>" + cluster_id  
            elif len(nodekeys) == 3:
                nodetype = 'unit'
                unit_id = nodekeys[2]
                unit = Unit.objects.select_related().get(id = unit_id)
                smucs = serverMassUpdateColumns
                servers = get_servers_by_unitid(unit_id)
                listname = u"<服务单元>" + unit_id           
            else:
                return HttpResponse(u"非法请求，后退重来")
        if not nodekey == 'top' and len(nodekeys) > 2:
            '''
            platform level or product level servers not traversed
            '''
            for server in servers:
                unitList = []
                sius = server.serverinunit_set.select_related().all()
                for siu in sius:
                    unitList.append(siu.unit.name)
                server.unitList = unitList
        amount = len(servers)
        print("return")
        print(time())
        return render(request,template_name,locals())
        
    return HttpResponse(u"非法请求，后退重来")



'''过期了
def server_cluster(request,template_name):
    
    cluster_id = request.GET.get('cluster_id')
    if not cluster_id:
        return render(request,'errparam.html',{"msg":"empty cluster_id!"})
    if not Service.objects.filter(id = cluster_id):
        return render(request,'errparam.html',{"msg":"cluster_id " + cluster_id + " not exist"})

    servers_incluster, cluster, components, cluster_servers = get_serversincluster_json_by_clusterid(cluster_id)
    
    return render(request,template_name,locals())    
'''
'''
def server_product_add_server(request,template_name):
    
    cluster_id = request.GET.get('cluster_id')
    if not cluster_id:
        return render(request,'errparam.html',{"msg":"empty cluster_id!"})
    if not Service.objects.filter(id = cluster_id):
        return render(request,'errparam.html',{"msg":"cluster_id " + cluster_id + " not exist"})
    
    cluster = Service.objects.get(id = cluster_id)
    product_name = cluster.name
    cluster_name = cluster.name
    
    servers_free = Server.objects.exclude(id__in = ServerInCluster.objects.values_list('server_id', flat=True))   
    servers_inuse = [] 
    for row in ServerInCluster.objects.select_related('server').all():
        servers_inuse.append(row.server)
    servers_incluster = []
    for row in ServerInCluster.objects.select_related('server').filter(cluster_id = cluster_id):
        servers_incluster.append(row.server)
    return render(request,template_name,locals())
'''
'''
def ajax_server_product_add_server(request):
    server_ids = request.POST.get('server_ids')
    cluster_id = request.POST.get('cluster_id')
    
    response_data = {}
    if Service.objects.filter(id = cluster_id):
        serverids = server_ids.split("##")
        serverid_insert_succeed = []
        serverid_insert_failed = []
        for serverid in serverids:
            if Server.objects.filter(id = serverid):
                if ServerInCluster.objects.filter(server_id = serverid):
                    serverid_insert_failed.append(serverid)
                else:
                    sic = ServerInCluster(server_id = serverid,cluster_id = cluster_id)
                    sic.save()
                    serverid_insert_succeed.append(serverid)
            else:
                serverid_insert_failed.append(serverid)
        response_data['status'] = 'succeed'
        response_data['serverid_insert_succeed'] = serverid_insert_succeed
        response_data['serverid_insert_failed'] = serverid_insert_failed
    else:
        response_data['status'] = 'failed'
        response_data['msg'] = 'cluster_id not exist'
        
    return HttpResponse(json.dumps(response_data),content_type="application/json")
'''
'''
def ajax_server_component_add_server(request):
    server_id = request.POST.get('server_id')
    component_id = request.POST.get('component_id')
    
    response_data = {}
    
    if not server_id or not Server.objects.filter(id = server_id):
        response_data['status'] = 'failed'
        response_data['msg'] = 'server_id ' + server_id + ' empty or not exist'
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    if not component_id or not Soft.objects.filter(id = component_id):
        response_data['status'] = 'failed'
        response_data['msg'] = 'component_id ' + component_id + ' empty or not exist'
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    if ServerInComponent.objects.filter(server_id = server_id, component_id = component_id):
        response_data['status'] = 'failed'
        response_data['msg'] = 'component_id ' + component_id + ' already has server ' + server_id + 'in it'
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    sip = ServerInComponent(server_id = server_id, component_id = component_id)
    sip.save()
    response_data['status'] = 'succeed'
    response_data['msg'] = 'component_id ' + component_id + ' successfully adds server ' + server_id + 'in it'
    return HttpResponse(json.dumps(response_data),content_type="application/json")
'''
'''
def ajax_server_component_del_server(request):
    
    component_id = request.POST.get('component_id')
    server_id = request.POST.get('server_id')
    
    response_data = {}
    if not server_id or not component_id:
        response_data['status'] = 'failed'
        response_data['msg'] = 'server_id(' + server_id + ') empty or component_id(' + component_id + ') empty'
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    if not ServerInComponent.objects.filter(component_id = component_id, server_id = server_id):
        response_data['status'] = 'failed'
        response_data['msg'] = 'component_id(' + component_id + ') and server_id(' + server_id+ ') have no relationship'
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    ServerInComponent.objects.filter(component_id = component_id, server_id = server_id).delete()
    response_data['status'] = 'succeed'
    return HttpResponse(json.dumps(response_data),content_type="application/json")
'''
'''
def ajax_server_cluster_del_server(request):
    
    cluster_id = request.POST.get('cluster_id')
    server_id = request.POST.get('server_id')
    
    response_data = {}
    if not server_id or not cluster_id:
        response_data['status'] = 'failed'
        response_data['msg'] = 'server_id empty or cluster_id empty'
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    if not ServerInCluster.objects.filter(cluster_id = cluster_id, server_id = server_id):
        response_data['status'] = 'failed'
        response_data['msg'] = 'cluster_id(' + cluster_id + ') and server_id(' + server_id+ ') have no relationship'
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    ServerInCluster.objects.filter(cluster_id = cluster_id, server_id = server_id).delete()
    response_data['status'] = 'succeed'
    return HttpResponse(json.dumps(response_data),content_type="application/json")
'''
def service_listProductServices(request,template_name):
    
    product_id = request.GET.get('product_id')
    if not product_id or not Product.objects.filter(id = product_id):
        product_id = 2
    
    product = Product.objects.get(id = product_id)
    
    servers_unused = Server.objects.filter(product_id = product_id, inuse = 0).exclude(id__in = ServerInUnit.objects.values_list('server_id', flat=True))
    servers_unused_num = len(servers_unused)
    
    servers_inproduct = Server.objects.filter(product_id = product_id)
    servers_inproduct_num = len(servers_inproduct)

    services = Service.objects.select_related().filter(product_id = product_id)
    for service in services:
        softs = []
        soft_objs = service.softinservice_set.all()
        for soft_obj in soft_objs:
            softs.append(soft_obj.soft)
        service.softs = softs
    
        units = []
        unit_objs = service.unit_set.select_related().all()
        for unit_obj in unit_objs:
            servers = []
            server_objs= unit_obj.serverinunit_set.all()
            for server_obj in server_objs:
                servers.append(server_obj.server) 
            unit_obj.servers = servers
            
            r = randint(1,3)
            if r == 1:
                stat = 'green-light'
            if r == 2:
                stat = 'yellow-light'
            if r == 3:
                stat = 'red-light'
            unit_obj.stat = stat
            units.append(unit_obj)
        service.units = units
    
    envs = Env.objects.all()
    idcs = Idc.objects.all()

    return render(request,template_name,locals())

def service_listSofts(request,template_name):
    
    services = Service.objects.select_related().all()
    
    for service in services:
        softs = []
        soft_objs = service.softinservice_set.all()
        for soft_obj in soft_objs:
            softs.append(soft_obj.soft)
        service.softs = softs
    
    return render(request,template_name,locals())



def ajax_service_addUnits(request):
    
    response_data = {}
    service_id = request.POST.get('service_id')
    soft_id = request.POST.get('soft_id')
    env_id = request.POST.get('env_id')
    idc_id = request.POST.get('idc_id')
    
    env_name = Env.objects.get(id = env_id).name
    soft_name = Soft.objects.get(id = soft_id).name
    service_name = Service.objects.get(id = service_id).name
    idc_name = Idc.objects.get(id = idc_id).name
    
    
    unit_name = env_name + '.' + soft_name + '.' + service_name + '.' + idc_name
    
    if Unit.objects.filter(env_id = env_id, soft_id = soft_id, service_id = service_id, idc_id = idc_id):
        response_data['code'] = '1'
        response_data['data'] = unit_name + ' already exist'
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    unit = Unit(name = unit_name, env_id = env_id, soft_id = soft_id, service_id = service_id, idc_id = idc_id )
    unit.save()
    response_data['code'] = '0'
    response_data['data'] = unit_name + ' created'
    return HttpResponse(json.dumps(response_data),content_type="application/json")

'''cluster:'''

def service_listClusterUnits(request,template_name):
    
    service_id = int(request.GET.get('service_id'))
    product_id = int(request.GET.get('product_id'))
    servers_inproduct = Server.objects.filter(product_id = product_id)
    
    if not Service.objects.filter(id = service_id, product_id = product_id):
        service_name = '没有这个集群'
        return render(request,template_name,locals())
    
    service_name = Service.objects.get(id = service_id).name
    clusters,empty_clusters = get_clusters_by_productid(product_id = product_id)   
    
    return render(request,template_name,locals())
 
def ajax_service_unitAddServers(request):
    
    response_data = {}
    unit_id = int(request.POST.get('unit_id'))
    server_id = int(request.POST.get('server_id'))
    
    if not Server.objects.filter(id = server_id) or not Unit.objects.filter(id = unit_id):
        response_data['code'] = 2
        response_data['data'] = 'server_id ' + str(server_id) + ' or unit_id ' + str(unit_id) + ' not in database'
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    if ServerInUnit.objects.filter(server_id = server_id, unit_id = unit_id) :
        response_data['code'] = 3
        response_data['data'] = 'server_id ' + str(server_id) + ' is already in unit_id ' + str(unit_id)
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    ServerInUnit.objects.create(server_id = server_id, unit_id = unit_id)
    response_data['code'] = 0
    response_data['data'] = "insert sucessfully"     
    
    return HttpResponse(json.dumps(response_data),content_type="application/json")

def ajaxMulitOperateUnitServers(request):
    
    unit_id = int(request.POST.get('unit_id'))
    operation = (request.POST.get('operation'))
    server_ips = request.POST.get('server_ips').strip().split('\n')
    try:
        unit = Unit.objects.get(id=unit_id)
    except:
        return HttpResponse('error unit id '+ unit_id )
    if operation == "migrate":
        tounit_id = int(request.POST.get('tounit_id'))
        try:
            tounit = Unit.objects.get(id=tounit_id)
        except:
            return HttpResponse('error tounit id '+ tounit_id )
    op_succeed = []
    exclude_server = []
    illegal_server = []
    for server_ip in server_ips:
        server_ip = server_ip.strip()
        if not server_ip:
            continue
        if Server.objects.filter(eth0=server_ip):
            server = Server.objects.get(eth0=server_ip)
            if operation == "add":
                if not ServerInUnit.objects.filter(server=server,unit=unit):
                    siu = ServerInUnit(server=server,unit=unit)
                    siu.save()
                    op_succeed.append(server_ip)
                else:
                    exclude_server.append(server_ip)
                
            elif operation == "del":
                if ServerInUnit.objects.filter(server=server,unit=unit):
                    ServerInUnit.objects.filter(server=server,unit=unit).delete()
                    op_succeed.append(server_ip)
                else:
                    exclude_server.append(server_ip)
                    
            elif operation == "enable":
                if ServerInUnit.objects.filter(server=server,unit=unit,enabled=0):
                    ServerInUnit.objects.filter(server=server,unit=unit).update(enabled=1)
                    op_succeed.append(server_ip)
                else:
                    exclude_server.append(server_ip)
            elif operation == "disable":
                if ServerInUnit.objects.filter(server=server,unit=unit,enabled=1):
                    ServerInUnit.objects.filter(server=server,unit=unit).update(enabled=0)
                    op_succeed.append(server_ip)
                else:
                    exclude_server.append(server_ip)
            elif operation == "migrate":            
                if ServerInUnit.objects.filter(server=server,unit=tounit):
                    exclude_server.append(server_ip)
                else:
                    siu = ServerInUnit(server=server,unit=tounit)
                    siu.save()
                    op_succeed.append(server_ip)
                try:
                    ServerInUnit.objects.filter(server=server,unit=unit).delete()
                except:
                    print "can't delete server from unit"
        else:
            illegal_server.append(server_ip)
    
    response_data = dict(op_succeed=op_succeed,exclude_server=exclude_server,illegal_server=illegal_server)
    return HttpResponse(json.dumps(response_data),
                        #content_type="application/json"
                        )

def mGetServerInfo(request, template_name, nav):
    
    server_ips = request.POST.get('server_ips')
        
    if not server_ips:
        return render(request,template_name,locals())
    
    r = []
    for server_ip in server_ips.strip().split('\n'):
        server_ip = server_ip.strip()
        try:
            isIP(server_ip)
        except:
            continue
        
        c = requests.get('http://pga.iaas.jcloud.com/cmdb/api/getServerInfoByEth0/?ip=%s' % server_ip).content
        d = json.loads(c)
        if d["code"] == 0:
            r.append(d['data'])
        else:
            r.append(dict(eth0=server_ip, domain='not found'))
    
    print r
    return render(request,template_name,locals())
  
def ajaxMassUpdateServers(request):
    
    server_ips = request.POST.get('server_ips').strip().split('\n')
    k = request.POST.get('k').strip()
    v = request.POST.get('v').strip()
    unit_name =request.POST.get("unit_name").strip()
    f = {}
    f[k] = v
    op_succeed = []
    exclude_server = []
    illegal_server = []
    for server_ip in server_ips:
        server_ip = server_ip.strip()
        if not server_ip:
            continue
        if Server.objects.filter(eth0=server_ip):
            server = Server.objects.get(eth0=server_ip)
            try:
                getattr(server,k)
            except:
                print 'server has no attr %s' % k
                illegal_server.append(server_ip)
                continue
            try:
                setattr(server,k, v)
                server.save()
                op_succeed.append(server_ip)
            except Exception as e:
                print 'failed to update server: %s' % e
                illegal_server.append(server_ip)
        else:
            print '% ip not found' % server_ip
            illegal_server.append(server_ip)
    if op_succeed:
        msg = u'%s 中 %s 设备以下字段被修改   %s = %s' % (unit_name, op_succeed, k, v)
        callSendmail(msg, 'PGA issue')
    response_data = dict(op_succeed=op_succeed,exclude_server=exclude_server,illegal_server=illegal_server)    
    return HttpResponse(json.dumps(response_data))
    
class MyView(View):
 
    def get(self, request, *args, **kwargs):
        return HttpResponse('Hello, World!')
    


