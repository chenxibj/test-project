#coding:utf-8
from cmdb.models import Product, Env, Idc, Service, Soft, Server, ServerInUnit,\
    Unit, SoftInService
from cmdb.models import ProductForm, EnvForm, IdcForm, ServiceForm, SoftForm, \
    ServerInUnitForm, UnitForm
from django.shortcuts import render
from cmdb.utils.clusterutils import get_clusters_by_productid, get_cluster_by_id,\
    get_tags_by_clusterid, get_cluster_tree_by_productid
from django.http.response import HttpResponse
import json
from chefapi.utils.vdrUtils import getVDRips
from time import time

def tree_modify(request,nav):
    
    tree_mode = request.GET.get("tree_mode")
    if not tree_mode or tree_mode =='':
        tree_mode = 'bycluster'
    nodekey = request.GET.get("nodekey")
    if not nodekey or nodekey =='':
        nodekey = 'top'
    # nodekey = top & tree_mode = byclust
    if tree_mode == 'bycluster':
        if nodekey == 'top':
            modify_type = u"<平台>"
            platform_name = "JCLOUD"
            platform_id = 1
            platform_comment = u"平台说明：公有云平台"
            products = Product.objects.select_related().filter(platform_id = platform_id)
            product_amount = len(products)
            print("start get data 1")
            envs = Env.objects.all()
            idcs = Idc.objects.all()
            services = Service.objects.all() 
            softs = Soft.objects.select_related().all()
            print("start get data 2")
            for soft in softs:
                siss = soft.softinservice_set.select_related().all()
                servicenames = ''
                for sis in siss:
                    servicenames += sis.service.name + ','
                soft.servicenames = servicenames
                units = soft.unit_set.all()
                soft.units = units

            print("return data")
            return render(request,'cmdb/tree_modify/platform.html',locals())
        nodekeys = nodekey.split('-')
        if len(nodekeys) == 1: 
            modify_type = u"<产品线>"
            product_id = nodekey
            product = Product.objects.select_related().get(id=product_id)
            
            servers_unused = Server.objects.filter(product_id = product_id, inuse = 0).exclude(id__in = ServerInUnit.objects.values_list('server_id', flat=True))
            servers_unused_num = len(servers_unused)            
            servers_inproduct = Server.objects.filter(product_id = product_id)
            servers_inproduct_num = len(servers_inproduct)
            
            clusters,empty_clusters = get_clusters_by_productid(product_id = product.id)  
                    
            return render(request,'cmdb/tree_modify/product.html',locals())
        if len(nodekeys) == 2:
            modify_type = u"<虚拟集群>"
            product_id = nodekeys[0]
            cluster_id = nodekeys[1]
            cluster_comment = u'这是一个虚拟节点，是由同一个机房内、同一个运行环境、同一个服务下的所有服务单元组成'
            cluster = get_cluster_by_id(product_id,cluster_id)
            env,service,softs,idc = get_tags_by_clusterid(cluster_id)
            return render(request,'cmdb/tree_modify/cluster.html',locals())
        if len(nodekeys) == 3:
            product_id = nodekeys[0]
            modify_type = u"<服务单元>"
            unit_id = nodekeys[2]
            unit = Unit.objects.select_related().get(id = unit_id)
            soft_name = unit.soft.name
            cluster_units = Unit.objects.filter(idc=unit.idc,env=unit.env,service=unit.service)
            servers_in_unit = ServerInUnit.objects.select_related().filter(unit_id = unit_id)
            for server in servers_in_unit:
                unitList = []
                sius = server.server.serverinunit_set.select_related().all()
                for siu in sius:
                    unitList.append(siu.unit.name)
                server.server.unitList = unitList  
            servers_inproduct = Server.objects.filter(product_id = product_id) 
            return render(request,'cmdb/tree_modify/unit.html',locals())
        
    return HttpResponse(u"此页面建设中，请后退重来")

'''ajax_get_treenode 用于动态生成服务树'''
def ajax_get_treenode(request):
    print("ajax_get_treenode")
    print(time())
    response_data = {}
    node_data = []
    key = request.GET.get('key')
    tree_mode = request.GET.get('tree_mode')
    if not tree_mode or tree_mode == '':
        tree_mode = "bycluster"
    platform_id = 1
    
    if tree_mode == 'bycluster' and not key:
        
        data = {}
        data['title'] = "JCLOUD"
        data['isFolder'] = True
        data['key'] = 'top'
        data['tree_mode'] = tree_mode
        children = []
        products = Product.objects.filter(platform_id = platform_id)
        print("get data from DB")
        for product in products:
            pdata = {}
            pdata['title'] = product.name
            pdata['isFolder'] = True
            pdata['key'] = product.id
            pdata['expand'] = False
            pdata['tree_mode'] = tree_mode
            pchildren = []
            clusters = get_cluster_tree_by_productid(product_id = product.id)
            #clusters,empty_clusters = get_clusters_by_productid(product_id = product.id)
            for cluster in clusters:
                cdata = {}
                cdata['title'] = cluster['name']
                cdata['isFolder'] = True
                cdata['key'] = str(product.id) + '-' + cluster['id']
                cdata['tree_mode'] = tree_mode
                cchildren = []
                for unit in cluster['units']:
                    udata = {}
                    udata['title'] = unit.name
                    udata['isFolder'] = False
                    udata['key'] = str(product.id) + '-' + cluster['id'] + '-' + str(unit.id)  
                    udata['tree_mode'] = tree_mode
                    cchildren.append(udata)
                cdata['children'] = cchildren
                pchildren.append(cdata)
            pdata['children'] = pchildren
            
            children.append(pdata)
        data['children'] = children
        
        node_data.append(data)
        print(time())
        print("get data done, return now")
        return HttpResponse(json.dumps(node_data),content_type="application/json")
    
    return HttpResponse(json.dumps(response_data),content_type="application/json")   
    
def ajax_platform_add(request):
    form_type = request.GET.get('form_type')
    if request.method == "POST" and request.is_ajax:
        if form_type == 'product':
            form = ProductForm(request.POST)        
        elif form_type == 'env':
            form = EnvForm(request.POST)
        elif form_type == 'idc':
            form = IdcForm(request.POST)
        elif form_type == 'service':
            form = ServiceForm(request.POST)
        elif form_type == 'soft':
            form = SoftForm(request.POST)
        else:
            return HttpResponse('noduang')
        if form.is_valid():
            form.save()
            return HttpResponse('duang')
    else:
        if form_type == 'product':
            form = ProductForm()        
        elif form_type == 'env':
            form = EnvForm()
        elif form_type == 'idc':
            form = IdcForm()
        elif form_type == 'service':
            form = ServiceForm()
        elif form_type == 'soft':
            form = SoftForm()
        else:
            return HttpResponse('noduang')
    
    return render(request,'cmdb/tree_modify/ajax_platform_add.html',{'form':form,'form_type':form_type})

def ajax_platform_edit(request):
    form_type = request.GET.get('form_type')
    tr_id = request.GET.get('tr_id')
    if request.method == "POST" and request.is_ajax:
        if form_type == 'product':
            form = ProductForm(request.POST,instance = Product.objects.get(id=tr_id))        
        elif form_type == 'env':
            form = EnvForm(request.POST,instance = Env.objects.get(id=tr_id))
        elif form_type == 'idc':
            form = IdcForm(request.POST,instance = Idc.objects.get(id=tr_id))
        elif form_type == 'service':
            form = ServiceForm(request.POST,instance = Service.objects.get(id=tr_id))
        elif form_type == 'soft':
            form = SoftForm(request.POST,instance = Soft.objects.get(id=tr_id))
        elif form_type == 'unit':
            form = UnitForm(request.POST,instance = Unit.objects.get(id=tr_id))
        elif form_type == 'server_in_unit':
            form = ServerInUnitForm(request.POST,instance = ServerInUnit.objects.get(id=tr_id))
        else:
            return HttpResponse('noduang')
        if form.is_valid():
            form.save()
            return HttpResponse('duang')
    else:
        if form_type == 'product':
            form = ProductForm(instance = Product.objects.get(id=tr_id))        
        elif form_type == 'env':
            form = EnvForm(instance = Env.objects.get(id=tr_id))
        elif form_type == 'idc':
            form = IdcForm(instance = Idc.objects.get(id=tr_id))
        elif form_type == 'service':
            form = ServiceForm(instance = Service.objects.get(id=tr_id))
        elif form_type == 'soft':
            form = SoftForm(instance = Soft.objects.get(id=tr_id))
        elif form_type == 'unit':
            form = UnitForm(instance = Unit.objects.get(id=tr_id))
        elif form_type == 'server_in_unit':
            form = ServerInUnitForm(instance = ServerInUnit.objects.get(id=tr_id))
        else:
            return HttpResponse('noduang')
    
    return render(request,'cmdb/tree_modify/ajax_platform_edit.html',{'form':form,'form_type':form_type,'tr_id':tr_id})    

def ajax_platform_del(request):
    form_type = request.POST.get('form_type')
    tr_id = request.POST.get('tr_id')    
    if form_type == 'product':
        if Service.objects.filter(product_id = tr_id):
            return HttpResponse(u'删不了，这个产品线下还有服务关联着')
        product = Product.objects.get(id = tr_id, protected = False)
        if product:
            product.delete()
            return HttpResponse(u'succeed')
        else:
            return HttpResponse(form_type + u' id: '+tr_id+u' 不存在或只读')
    elif form_type == 'env':
        if Unit.objects.filter(env_id = tr_id):
            return HttpResponse(u'删不了，这个环境下还有服务单元关联着')
        env = Env.objects.get(id = tr_id, protected = False)
        if env:
            env.delete()
            return HttpResponse(u'succeed')
        else:
            return HttpResponse(form_type + u'id: '+tr_id+u' 不存在或只读')            
    elif form_type == 'idc':
        if Unit.objects.filter(idc_id = tr_id):
            return HttpResponse(u'删不了，这个机房下还有服务单元关联着')
        idc = Idc.objects.get(id = tr_id, protected = False)
        if idc:
            idc.delete()
            return HttpResponse(u'succeed')
        else:
            return HttpResponse(form_type + u'id: '+tr_id+u' 不存在或只读')
    elif form_type == 'service':
        if Unit.objects.filter(service_id = tr_id):
            return HttpResponse(u'删不了，这个服务下还有服务单元关联着')
        if SoftInService.objects.filter(service_id = tr_id):
            return HttpResponse(u'删不了，这个服务下还有组件关联着,先解除关联关系')
        service = Service.objects.get(id = tr_id, protected = False)
        if service:
            service.delete()
            return HttpResponse(u'succeed')
        else:
            return HttpResponse(form_type + u'id: '+tr_id+u' 不存在或只读')
    elif form_type == 'soft':
        if Unit.objects.filter(soft_id = tr_id):
            return HttpResponse(u'删不了，这个组件下还有服务单元关联着')
        if SoftInService.objects.filter(soft_id = tr_id):
            return HttpResponse(u'删不了，这个组件还和服务关联着，先解除关联关系')
        soft = Soft.objects.get(id = tr_id, protected = False)
        if soft:
            soft.delete()
            return HttpResponse(u'succeed')
    elif form_type == 'unit':
        if ServerInUnit.objects.filter(unit_id = tr_id):
            return HttpResponse(u'删不了，这个服务单元下还有服务器挂着呢')
        unit = Unit.objects.get(id = tr_id)
        if unit:
            unit.delete()
            return HttpResponse(u'succeed')
        else:
            return HttpResponse(form_type + u'id: '+tr_id+u' 不存在或只读')    
    elif form_type == 'server_in_unit':
        siu = ServerInUnit.objects.get(id = tr_id)
        if siu:
            siu.delete()
            return HttpResponse(u'succeed')
        else:
            return HttpResponse(form_type + u'id: '+tr_id+u' 不存在或只读')   
    return HttpResponse(form_type+'del'+tr_id+': 未知情况，请截图给管理员')

def ajax_update_vdr(request):
    
    unit_id = request.POST.get('unit_id')
    soft = request.POST.get('soft')
    r = {"unit_id": unit_id}
    unit = Unit.objects.select_related().get(id = unit_id)
    idc = unit.idc.name
    env = unit.env.name
    sius = ServerInUnit.objects.select_related().filter(unit_id = unit_id)
    for siu in sius:
        server = siu.server
        eth0 = server.eth0
        rack = server.rack
        r1 = getVDRips(eth0,rack,idc, env)
        if soft == 'vr':
            r2 = dict(eth0_gateway=r1['eth0_gateway'], dv=r1['dv'],dv_gateway=r1['dv_gateway'],vv=r1['vv'],vv_gateway=r1['vv_gateway'])
        elif soft == 'dr':
            r2 = dict(eth0_gateway=r1['eth0_gateway'], dv=r1['dv'],dv_gateway=r1['dv_gateway'],ds=r1['ds'],ds_gateway=r1['ds_gateway'],dbgp=r1['dbgp'],dbgp_gateway=r1['dbgp_gateway'],peer_as=r1['peer_as'],dr_as=r1['dr_as'])
                
        r1str = json.dumps(r2)
        siu.vars = r1str
        siu.save()
    
    return HttpResponse(json.dumps(r),content_type="application/json")

