#coding:utf-8
from django.shortcuts import render
from cmdb.models import Server, Product, Soft, Service, Idc, Env, Unit, ServerInUnit,\
    SoftInService
from django.views.generic.base import View
from django.http.response import HttpResponse
import json

from cmdb.utils.clusterutils import get_clusters_by_productid, get_cluster_by_id,\
    getProcessvarsFromSoft, get_cluster_by_service
from random import randint
from cmdb.utils.unitutils import get_servers_by_unitid, apiGetServerIPsByUnits,\
    apiGetServersByUnits, getAllServerVars
from django.forms.models import model_to_dict
from deploy.config import default_internal_vars

# Create your views here.

def listServices(request):
    response_data = []
    services = Service.objects.all()
    
    for service in services:
        response_data.append(dict(service_id=service.id, service_name=service.name))
    return HttpResponse(json.dumps(response_data, indent=4, sort_keys=True),content_type="application/json")

def listSoftsByService(request):
    
    service_id = request.GET.get('service')
    try:
        service = Service.objects.select_related().get(id = service_id)
    except:
        try:
            service = Service.objects.select_related().get(name = service_id)
        except:
            return HttpResponse(json.dumps(dict(code=1,msg='error service')),content_type="application/json")
    
    siss = service.softinservice_set.select_related().all()
    response_data = []
    for sis in siss:
        response_data.append(dict(soft_id=sis.soft.id, soft_name=sis.soft.name))
    
    return HttpResponse(json.dumps(response_data, indent=4, sort_keys=True),content_type="application/json")

def listClusters(request):
    
    response_data = []
    product_id = request.GET.get('product_id')
    if not product_id:
        product_id = 2
    clusters,empty_clusters = get_clusters_by_productid(product_id=product_id)
    for cluster in clusters:
        response_data.append(dict(cluster_id=cluster['id'],cluster_name=cluster['name']))
    
    return HttpResponse(json.dumps(response_data, indent=4, sort_keys=True),content_type="application/json")

def listSofts(request):
    
    response_data = []
    service_id = request.GET.get('service_id')
    if not service_id:
        service_id = 1
    try:
        service = Service.objects.get(id=service_id)
        siss = SoftInService.objects.select_related().filter(service=service)
        for sis in siss:
            response_data.append(dict(soft_id=sis.soft.id,soft_name=sis.soft.name))
    except:
        pass  
    
    return HttpResponse(json.dumps(response_data, indent=4, sort_keys=True),content_type="application/json")

def listIdcs(request):
    
    response_data = []
    idcs = Idc.objects.exclude(id=9999)
    for idc in idcs:
        response_data.append(dict(idc_id=idc.id,idc_name=idc.name,idc_desc=idc.description))
    return HttpResponse(json.dumps(response_data, indent=4, sort_keys=True),content_type="application/json")

def getClusterByService(request):
    service_id = request.GET.get('service')
    try:
        service = Service.objects.select_related().get(id = service_id)
    except:
        try:
            service = Service.objects.select_related().get(name = service_id)
        except:
            return HttpResponse(json.dumps(dict(code=1,msg='error service')),content_type="application/json")
    
    r = get_cluster_by_service(service)
    return HttpResponse(json.dumps(r, indent=4, sort_keys=True),content_type="application/json")
        

def getClusterServers(request):
    
    response_data = {}
    cluster_id = request.GET.get('cluster_id')
    try:
        foralarm = request.GET.get('foralarm')
    except:
        pass
    
    if not cluster_id:
        
        cluster_name = request.GET.get('cluster_name')
        if not cluster_name:        
            response_data['code'] = '1'
            response_data['data'] = 'cluster_id is empty ' 
            return HttpResponse(json.dumps(response_data, indent=4, sort_keys=True),content_type="application/json")

        tmp = cluster_name.split('.')
        env_name = tmp[0]
        service_name = tmp[1]
        idc_name = tmp[2]
        
        if not Env.objects.filter(name = env_name) or not Service.objects.filter(name=service_name) or not Idc.objects.filter(name=idc_name):
            response_data['code'] = '2'
            response_data['data'] = 'invalid env_name ' + env_name + " or service_name " + service_name + " or idc_name " + idc_name
            return HttpResponse(json.dumps(response_data, indent=4, sort_keys=True),content_type="application/json")
        
        env_id = Env.objects.get(name=env_name).id
        service_id = Service.objects.get(name=service_name).id
        idc_id = Idc.objects.get(name=idc_name).id
        
    else:
        tmp = cluster_id.split('.')
        env_id = int(tmp[0])
        service_id = int(tmp[1])
        idc_id = int(tmp[2])
        
        if not Env.objects.filter(id = env_id) or not Service.objects.filter(id=service_id) or not Idc.objects.filter(id=idc_id):
            response_data['code'] = '2'
            response_data['data'] = 'invalid env_id ' + env_id + " or service_id " + service_id + " or idc_id " + idc_id
            return HttpResponse(json.dumps(response_data, indent=4, sort_keys=True),content_type="application/json")
    
    units = Unit.objects.select_related().filter(env_id = env_id,service_id = service_id,idc_id = idc_id)
        
    if foralarm:
        data = apiGetServersByUnits(units)
    else:
        data = apiGetServerIPsByUnits(units)
    
    response_data = dict(code=0,data=data)
    
    return HttpResponse(json.dumps(response_data, indent=4, sort_keys=True),content_type="application/json")

def GetAllEnableIP(request):
    data = ServerInUnit.objects.select_related().all().filter(enabled=1)
    #data = ServerInUnit.objects.select_related().all()
    if request.method == 'GET':
        if request.GET.get('search'):
            searchType = request.GET.get('search')
            if searchType == 'all':
                iplist = []
                for eachitem in data:
                    iplist.append('%s' % eachitem.server)
                return HttpResponse(json.dumps(iplist, indent=4, sort_keys=True))
        elif request.GET.get('deep'):
            deep = request.GET.get('deep')
            env = request.GET.get('env')
            idc = request.GET.get('idc')
            app = request.GET.get('app')
            service = request.GET.get('service')
            viewType = request.GET.get('viewType')

            if env:
                env = r'%s' % '|'.join(['^%s$' % i for i in env.split(',')])
            else:
                env = r'.*'

            if idc:
                idc = r'%s' % '|'.join(['^%s$' % i for i in idc.split(',')])
            else:
                idc = r'.*'

            if app:
                app = r'%s' % '|'.join(['^%s$' % i for i in app.split(',')])
            else:
                app = r'.*'

            if service:
                service = r'%s' % '|'.join(['^%s$' % i for i in service.split(',')])
            else:
                service = r'.*'

            #data = ServerInUnit.objects.select_related().all().filter(enabled=1,unit__env__name__iregex=env,unit__idc__name__iregex=idc,unit__service__name__iregex=app,unit__soft__name__iregex=service)
            data = ServerInUnit.objects.select_related().all().filter(unit__env__name__iregex=env,unit__idc__name__iregex=idc,unit__service__name__iregex=app,unit__soft__name__iregex=service)
            ResponseData = {}
            for eachitem in data:
                enabled = eachitem.enabled
                env = '%s' % eachitem.unit.env
                idc = '%s' % eachitem.unit.idc
                app = '%s' % eachitem.unit.service
                service = '%s' % eachitem.unit.soft
                hostname = '%s' % eachitem.server.hostname
                eth0 = '%s' % eachitem.server
                eth1 = '%s' % eachitem.server.eth1
                serverModule = '%s' % eachitem.server.serverModule
                rack = '%s' % eachitem.server.rack
                domain_status = '%s' % eachitem.server.domain_status
                domain = '%s' % eachitem.server.domain
                eth1gateway = '%s' % eachitem.server.eth1gateway
                
                Tmp_Dict = {'enabled':enabled,'env':env,'idc':idc,'app':app,'service':service,'eth0':eth0,'eth1':eth1,'eth1gateway':eth1gateway,'domain':domain,'domain_status':domain_status,'hostname':hostname,'rack':rack,'serverModule':serverModule}
                if viewType == '1':
                    if deep == 'env':
                        key = env
                    elif deep == 'idc':
                        key = '%s.%s' % (env,idc)
                    elif deep == 'app':
                        key = '%s.%s.%s' % (env,idc,app)
                    elif deep == 'service':
                        key = '%s.%s.%s.%s' % (env,idc,app,service)
                        
                    if not ResponseData.has_key(key):
                        ResponseData[key] = {}
                    ResponseData[key][eth0] = Tmp_Dict
                elif viewType == '2':
                    if not ResponseData.has_key(env):
                        ResponseData[env] = {}

                    if deep == 'env':
                        ResponseData[env][eth0] = Tmp_Dict
                    elif deep == 'idc':
                        if not ResponseData[env].has_key(idc):
                            ResponseData[env][idc] = {}
                        ResponseData[env][idc][eth0] = Tmp_Dict
                    elif deep == 'app':
                        if not ResponseData[env].has_key(idc):
                            ResponseData[env][idc] = {}
                        if not ResponseData[env][idc].has_key(app):
                            ResponseData[env][idc][app] = {}
                        ResponseData[env][idc][app][eth0] = Tmp_Dict
                    elif deep == 'service':
                        if not ResponseData[env].has_key(idc):
                            ResponseData[env][idc] = {}
                        if not ResponseData[env][idc].has_key(app):
                            ResponseData[env][idc][app] = {}
                        if not ResponseData[env][idc][app].has_key(service):
                            ResponseData[env][idc][app][service] = {}
                        ResponseData[env][idc][app][service][eth0] = Tmp_Dict

            return HttpResponse(json.dumps(ResponseData,indent=4, sort_keys=True),content_type="application/json")
    elif request.method == 'POST':
        return HttpResponse('post')

def getServerInfoByEth0(request):
    
    eth0 = request.GET.get('ip')
    try:
        server = Server.objects.select_related().get(eth0=eth0)
        sius = server.serverinunit_set.select_related().all()
        units = []
        for siu in sius:
            units.append(siu.unit.name)
        server = model_to_dict(server, fields=['eth0','hostname','domain','id'])
        server["units"] = units
        code = 0
        return HttpResponse(json.dumps(dict(code=code, data=server), indent=4, sort_keys=True),content_type="application/json")
    except Exception as e:
        code = 1
        msg = ('ip %s is empty or not found: %s' % (eth0,e))
        return HttpResponse(json.dumps(dict(code=code, msg=msg), indent=4, sort_keys=True),content_type="application/json")

def getRackInfoByEth0(request):
    eth0 = request.GET.get('ip')
    try:
        server = Server.objects.select_related().get(eth0=eth0)
        server = model_to_dict(server, fields=['eth0','rack'])
        code = 0
        return HttpResponse(json.dumps(dict(code=code, data=server), indent=4, sort_keys=True),content_type="application/json")
    except Exception as e:
        code = 1
        msg = ('ip %s is empty or not found: %s' % (eth0,e))
        return HttpResponse(json.dumps(dict(code=code, msg=msg), indent=4, sort_keys=True),content_type="application/json")        

def getAllUnitServers(request):
    
    if request.GET.get("nounit"):
        server_ids = ServerInUnit.objects.all().values("server_id")
        servers = list(Server.objects.exclude(id__in=server_ids).values_list("eth0",flat=True))
        return HttpResponse(json.dumps(servers, indent=4, sort_keys=True),content_type="application/json")
    
    r = {}
    sius = ServerInUnit.objects.select_related().all()
    for siu in sius:
        
        unit = siu.unit.name
        server = siu.server.eth0
        print unit, server
        
        if not r.has_key(unit):
            r[unit] = []
        r[unit].append(server)
    return HttpResponse(json.dumps(r, indent=4, sort_keys=True),content_type="application/json")

def getAllUnits(request):
    l = []
    units = Unit.objects.all()
    for unit in units:
        l.append(unit.name)
    return HttpResponse(json.dumps(l, indent=4, sort_keys=True),content_type="application/json")

def getAllSofts(request):
    l = []
    softs = Soft.objects.all()
    for soft in softs:
        l.append(soft.name)
    return HttpResponse(json.dumps(l, indent=4, sort_keys=True),content_type="application/json")

def getServerDictByServiceSoft(request):
    service_name = request.GET.get("service")
    soft_name = request.GET.get("soft")
    
    service = Service.objects.get(name = service_name)
    soft = Soft.objects.get(name = soft_name)
    
    units = Unit.objects.select_related().filter(service = service, soft = soft)
    r = {}
    for unit in units:
        if not r.has_key(unit.env.name):
            r[unit.env.name] = {}
        if not r[unit.env.name].has_key(unit.idc.name):
            r[unit.env.name][unit.idc.name] = []
        sius = getAllServerVars(unit)

        for siu in sius:
            server = model_to_dict(siu.server, fields = default_internal_vars)
            for k,v in server.items():
                if not siu.server_vars.has_key(k):
                    siu.server_vars[k] = v
            siu.server_vars["service"] = service_name
            siu.server_vars["soft"] = soft_name
            r[unit.env.name][unit.idc.name].append(siu.server_vars)
    
    return HttpResponse(json.dumps(r, indent=4, sort_keys=True),content_type="application/json")
            
def getProcessvars(request):
    r = getProcessvarsFromSoft()
    
    return HttpResponse(json.dumps(r, indent=4, sort_keys=True),content_type="application/json")
    
    
    
    