from django.contrib import admin
from cmdb.models import Server, Env, Platform, Product, Soft, Idc, Unit, Service, SoftInService, ServerInUnit,\
    Toogles,RequestLog

# Register your models here.
class ServerAdmin(admin.ModelAdmin):
    list_display = ('id','ilo','hostname','product','idc','inuse','eth0','eth1','eth1gateway','rack','serverModule','domain','domain_status','cpu','ccpu','mem','cmem','disk','rdisk','cdisk','zbx_hostid','created_at','updated_at')
    search_fields = ('hostname','eth0')
    
admin.site.register(Server, ServerAdmin)

class IdcAdmin(admin.ModelAdmin):
    list_display = ('id','name','description','protected')
    
admin.site.register(Idc, IdcAdmin)

class EnvAdmin(admin.ModelAdmin):
    list_display = ('name','description','protected')
    
admin.site.register(Env, EnvAdmin)

class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name','description','product','protected')
    
admin.site.register(Service, ServiceAdmin)

class UnitAdmin(admin.ModelAdmin):
    list_display = ('id','name','service','idc','env','soft','vars')
    
admin.site.register(Unit, UnitAdmin)

class PlatformAdmin(admin.ModelAdmin):
    list_display = ('name',)
    
admin.site.register(Platform, PlatformAdmin)

class ProductAdmin(admin.ModelAdmin):
    list_display = ('name','description','platform','protected','this_pga')

admin.site.register(Product, ProductAdmin)

class SoftAdmin(admin.ModelAdmin):
    list_display = ('name','description','protected','process_vars')

admin.site.register(Soft, SoftAdmin)

class SoftInServiceAdmin(admin.ModelAdmin):
    list_display = ('id','soft','service','comment')

admin.site.register(SoftInService, SoftInServiceAdmin)

class ServerInUnitAdmin(admin.ModelAdmin):
    list_display = ('id','server_id','unit_id','vars','comment','enabled','created_at','updated_at')

admin.site.register(ServerInUnit, ServerInUnitAdmin)

class TooglesAdmin(admin.ModelAdmin):
    list_display = ('id','name','comment','toogle','created_at','updated_at')

admin.site.register(Toogles, TooglesAdmin)

class RequestLogAdmin(admin.ModelAdmin):
    list_display = ["when","ip",'session_key','user','user_repr','method','host','path','query','post','files','cookies','request_headers','response_headers','response_status_code','response_body','total_time']
admin.site.register(RequestLog, RequestLogAdmin)