/*--------------------------------------------
 * Desc:   UMP页面合法性检查 JS对象;
 * Author: luojinsong@360buy.com; 
 * Date:   2011/12/19;
 ---------------------------------------------*/
var iCheck = iCheck || {
    ctypeFunc : {
        // 是否为空;
        empty : "checkEmpty",
        // 是否为整数字及范围;
        num   : "checkNum",
        // 是否为数字包括小数;
        floatNum : "checkFloatNum",
        // 判断小数位数;
        decimalen   : "checkDecimalen",
        // 是否为金额;
        money : "checkMoney",
        // 是否为手机号码;
        mobile: "checkMobile",
        // 是否为邮箱地址;
        email : "checkEmail",
        // 是否为日期;
        date  : "checkData",
        // 是否为身份证;
        idcard: "checkIDcard",
        // 长度最大15;
        maxlen: "checkMaxlen",
        // 长度最大（包含中文等字符）15;
        max2len: "checkMax2len",
        // 长度不低于5;
        minlen: "checkMinlen",
        //长度最小（包含中文等字符）
        min2len : "checkMin2len",
        // 长度==10;
        len   : "checkLen",
        // 是否为ip地址;
        ip    : "checkIp",
        // 是否验证非法字符;
        inVal : "checkInVal",
        // 是否为英文字母;
        Abc : "checkABC",
        // 验证key;
        key : "checkKey",
        //验证Url返回码只能为正整数和英文逗号
        returnCode : "checkReturnCode",
        //验证是否是网址不带http：//
        url : "checkUrl",
        //端口存活验证端口地址
        portAddress : "checkPortAddress",
        //url存活通过erp方式跳转的密码
        passWord : "checkPassWord",
        //验证是否包含中文字符
        isContainChinese : "checkChinese"
    },
    // 非法字符字典;
    inValData : {
        "\"" : 1,
        "\'" : 1,
        "<"  : 1,
        ">"  : 1,
        "\\" : 1,
        "?"  : 1,
        "%"  : 1,
        "#"  : 1,
        "&"  : 1,
        "$"  : 1,
        "@"  : 1,
        ";"  : 1,
        ","  : 1,
        "\"" : 1,
        "^"  : 1
    },
    /*
    * Desc: 通过容器id,检查此容器内需检查项;
    * Args: contentId ->待检查项的容器id;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkValues : (function(contentId)
    {
        if(!$(contentId))
        {
            //iPage.showMsg(2, "检查条件错误，当前页面未找到容器:"+contentId);
            return false;
        }
        // 获取contentId对应容器内的所有input对象;
        var inputArr = $t("input", contentId);
        // 临时变量,获取各组件校验类型;
        var ctypes = "";
        // 遍历容器内每一个input对象;
        for(var i=0, l=inputArr.length; i<l; i++)
        {
            ctypes = inputArr[i].getAttribute("ctypes");
            //判断是否需检查合法性;
            if(ctypes && (!inputArr[i].disabled || inputArr[i].cforce))
            {
                if(!iCheck.checkItem(inputArr[i], ctypes))
                {
                    return false;
                }
            }
        }
        // 获取contentId对应容器内的所有textarea对象;
        var textAareaArr =  $t("textarea", contentId);
        // 遍历容器内每一个textarea对象;
        for(var i=0, l=textAareaArr.length; i<l; i++)
        {
            ctypes = textAareaArr[i].getAttribute("ctypes");
            //判断是否需检查合法性;
            if(ctypes && (!textAareaArr[i].disabled || textAareaArr[i].cforce))
            {
                if(!iCheck.checkItem(textAareaArr[i], ctypes))
                {
                    return false;
                }
            }
        }
        return true;
    }),
    
    /*
    * Desc: 通过容器id,检查此容器内需检查项;
    * Args: contentId ->待检查项的容器id;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkItem : (function(cObj, ctypes)
    {
        // 对检查类型进行区分;
        ctypes = ctypes.split(";");
        var ctypeArr = "";
        var cResult  = null;
        var ctype    = "";
        //var cV       = (cObj.value).trim();
        var cV       = cObj.value;
        // 清除两端空格;
        cV = cV.trim();
        if(cObj.className == "textDesc")
        {
	        if(cV.charAt(0) == "^" && cV.charAt(cV.length-1) == "^")
	        {
	        	cV = "";
	        }
        }
        for(var i=0, l=ctypes.length; i<l; i++)
        {
            ctypeArr = ctypes[i].split(":");
            ctype = ctypeArr[0].trim();
            if(!ctype)
            {
                continue;
            }
            cResult = iCheck[iCheck.ctypeFunc[ctype]];
            // 判断是否找到对应的查检方法;
            if(!cResult)
            {
                iJS.showGuid(cObj, "检查条件错误，未找到【"+ctype+"】的检查类型");
                return false;
            }
            iCheck.errorMsg = "";
            if(!cV)
            {
                var j;
                for(j=0; j<ctypes.length; j++)
                {
                    if(ctypes[i].split(":")[0] == "empty")
                    {
                        break;
                    }
                }
                if(j == ctypes.length)
                {
                    return true;
                }
            }
            cResult = cResult(cV, ctypeArr[1]);
            if(!cResult)
            {
                /*var cdesc = cObj.getAttribute("cdesc");
                cdesc = cdesc || iJS.getPreSibling(cObj.parentElement).innerHTML;
                iJS.showGuid(cObj, "〖"+cdesc.trim()+"〗有误，" + iCheck.errorMsg);*/
            	iJS.showGuid(cObj, iCheck.errorMsg);
                return false;
            }
        }
        return true;
    }),
    /*
    * Desc: 字符串判空;
    * Args: cV ->待检查值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkEmpty : (function(cV)
    {
        iCheck.errorMsg = "内容不能为空";
        return !!cV.trim();
    }),
    
    /*
    * Desc: 判断是否为数字;
    * Args: cV ->待检查值;
    * 		
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkNum : (function(cV, range)
    {
        iCheck.errorMsg = "正确格式为数字";
        if(!iCheck.checkByRegexp(cV.trim(), /^\d+$/))
        {
        	return false;
        }
        if(!range)
        {
        	return true;
        }
        if(range.indexOf("[")==0 && range.indexOf("]")==range.length-1)
        {
        	range = range.replace("[", "");
        	range = range.replace("]", "");
        	var rangeArr = range.split("-");
        	cV = parseInt(cV, 10);
        	if(cV >= parseInt(rangeArr[0], 10) && cV <= parseInt(rangeArr[1], 10))
            {
        		return true;
            }
            iCheck.errorMsg = "必须>="+rangeArr[0]+"并且<="+rangeArr[1];
            return false;
        }
        iCheck.errorMsg = range + "格式不合法";
        return false;
    }),
    /*
    * Desc: 判断是否为整数或小数;
    * Args: cV ->待检查值;
    * 		range ->范围[]
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkFloatNum : (function(cV, range)
    {
    	iCheck.errorMsg = "正确格式为整数或小数";
    	if(isNaN(cV))
    	{
    		return false;
    	}
    	if(!range)
        {
        	return true;
        }
        if(range.indexOf("[")==0 && range.indexOf("]")==range.length-1)
        {
        	range = range.replace("[", "");
        	range = range.replace("]", "");
        	var flag = "";
        	if(range.charAt(0) == "-")
        	{
        		range = range.replace("-", "");
        		flag = "-";
        	}
        	var rangeArr = range.split("-");
        	cV = parseFloat(cV, 10);
        	if(cV >= parseFloat(flag + rangeArr[0], 10) && cV <= parseFloat(rangeArr[1], 10))
            {
        		return true;
            }
            iCheck.errorMsg = "必须>="+flag+rangeArr[0]+"并且<="+rangeArr[1];
            return false;
        }
        iCheck.errorMsg = range + "格式不合法";
        return false;
    }),
    
    /*
    * Desc: 判断小数位数;
    * Args: cV ->待检查值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkDecimalen : (function(cV, len)
    {
        iCheck.errorMsg = "正确格式不超过"+len+"位数字";
        cV = cV.split(".")[1];
        if(cV)
        {
            if(cV.length > len)
            {
                return false;
            }
            return true;
        }
        return true;
    }),
    
    /*
    * Desc: 判断是否为金额;
    * Args: cV ->待检查值;
    *       type ->检查子类型:0+必须为正数,0-必须为负数,
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkMoney : (function(cV, type)
    {
        iCheck.errorMsg = "正确格式为金额";
        if(isNaN(cV))
        {
            return false;
            //return iCheck.checkByRegexp(cV, /^([+-]?)((\d{1,3}(,\d{3})*)|(\d+))(\.\d{1,2})?$/ );
        }
        if(!type)
        {
            return true;
            //return iCheck.checkByRegexp(cV, /^([+-]?)((\d{1,3}(,\d{3})*)|(\d+))(\.\d{1,2})?$/ );
        }
        if(type == "0+")
        {
            if(parseFloat(cV) >= 0)
            {
                return true;
            }
            iCheck.errorMsg = "金额必须≥0";
            return false;
        }
        if(type == "(0+")
        {
            if(parseFloat(cV) > 0)
            {
                return true;
            }
            iCheck.errorMsg = "金额必须>0";
            return false;
        }
        if(type == "0-")
        {
            if(parseFloat(cV) <= 0)
            {
                return true;
            }
            iCheck.errorMsg = "金额必须≤0";
            return false;
        }
        if(type == "(0-")
        {
            if(parseFloat(cV) < 0)
            {
                return true;
            }
            iCheck.errorMsg = "金额必须<0";
            return false;
        }
    }),
    
    /*
    * Desc: 判断是否为手机号码;
    * Args: cV ->待检查值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkMobile : (function(cV)
    {
        iCheck.errorMsg = "正确格式为11位手机号码";
//        return iCheck.checkByRegexp(cV, /^(?:0?13\d|15\d|18\d)-?\d{5}(\d{3}|\*{3})$/);
        return iCheck.checkByRegexp(cV, /^(?:0?\d{11})$/);
    }),
    
    /*
    * Desc: 判断是否为电子邮箱地址;
    * Args: cV ->待检查值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkEmail : (function(cV)
    {
        iCheck.errorMsg = "正确格式为电子邮箱地址";
        return iCheck.checkByRegexp(cV, /^(?:\w+\.?)*\w+@(?:\w+\.)+\w+$/);
    }),
    
    /*
    * Desc: 判断是否为日期;
    * Args: cV ->待检查值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkData : (function(cV)
    {
        iCheck.errorMsg = "正确格式如：2012-06-06";
        if(cV.length>7 && cV.split("-").length==3 && !isNaN(cV.replaceAll("-")))
        {
            return true;
        }
        return false;
    }),
    
    /*
    * Desc: 判断是否为身份证号码;
    * Args: cV ->待检查值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkIDcard : (function(cV)
    {
        if(iCheck.checkLen(cV, "18") || iCheck.checkLen(cV, "15"))
        {
            return true;
        }
        return !(iCheck.errorMsg = "正确格式为15|18位身份证号码");
    }),
    
    /*
    * Desc: 判断是否超过最大数量值;
    * Args: cV  ->待检查值;
    *       len ->对比长度的数量值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkMaxlen : (function(cV, len)
    {
        iCheck.errorMsg = "长度不能大于" + len;
        return cV.length <= len;
    }),
    
    /*
    * Desc: 判断是否超过最大数量值(英文字符算一个，其它算两个);
    * Args: cV  ->待检查值;
    *       len ->对比长度的数量值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkMax2len : (function(cV, len)
    {
        iCheck.errorMsg = "长度不能大于" + len;
        if(cV.length > len)
        {
        	return false;
        }
        var sum = 0;
        for(var i=0, l=cV.length; i<l; i++)
        {
            if(cV.charCodeAt(i) > 256)
            {
                sum += 2;
                continue;
            }
            sum ++;
        }
        return sum <= len;
    }),
    
    /*
    * Desc: 判断是否少于最小数量值;
    * Args: cV  ->待检查值;
    *       len ->对比长度的数量值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkMinlen : (function(cV, len)
    {
        iCheck.errorMsg = "长度不能小于" + len;
        return cV.length >= len;
    }),
    
    
    /*
     * Desc:判断是否少于最小数量值(英文字符算一个，其它算两个);
     * Args: cV  ->待检查值;
     *       len ->对比长度的数量值;
     * Ret : true|false(检查合格|检查不合格);
     * ------------------------------------------------- */
     checkMin2len : (function(cV, len)
     {
         iCheck.errorMsg = "长度不能小于" + len;
         if(cV.length < len)
         {
         	return false;
         }
         var sum = 0;
         for(var i=0, l=cV.length; i<l; i++)
         {
             if(cV.charCodeAt(i) > 256)
             {
                 sum += 2;
                 continue;
             }
             sum ++;
         }
         return sum >= len;
     }),
    
    /*
    * Desc: 判断是否等于固定数量值;
    * Args: cV  ->待检查值;
    *       len ->对比长度的数量值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkLen : (function(cV, len)
    {
        iCheck.errorMsg = "长度应等于" + len;
        var lenArr = len.split(",");
        for(var i=0, l=lenArr.length; i<l; i++)
        {
            if(cV.length == lenArr[i])
            {
                return true;
            }
        }
        return false;
    }),
    
    /*
    * Desc: 判断是否为ip地址;
    * Args: cV  ->待检查值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkIp : (function(cV)
    {
        iCheck.errorMsg = "正确格式如：192.168.1.12";
        return iCheck.checkByRegexp(cV, /^(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$/);
    }),
    
    /*
    * Desc: 判断是否含有非法字符;
    * Args: cV  ->待检查值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkInVal : (function(cV, _charts)
    {
    	if (_charts) {
    		iCheck.inValData = _charts;
    	}
        iCheck.errorMsg = "不能包含非法字符:\", \', <, >, \, ?, %, #, &, $, @, ;, ,, ^,";
        for(var i=0, l=cV.length; i<l; i++)
        {
            if(iCheck.inValData[cV.charAt(i)])
            {
                return false;
            }
        }
        return true;
    }),
    
    /*
    * Desc: 判断是否为英文字母;
    * Args: cV  ->待检查值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
    checkABC : (function(cV)
    {
        iCheck.errorMsg = "正确格式如英文字母";
        return iCheck.checkByRegexp(cV, /^[A-Za-z]+$/);
    }),
    
    /*
	* Desc: 判断是否为合法的监控key;
	* Args: cV  ->待检查值;
	* Ret : true|false(检查合格|检查不合格);
	* ------------------------------------------------- */
	checkKey : (function(cV)
    {
		cV = cV.trim();
		iCheck.errorMsg = "正确格式不能以.开始";
		if(cV.indexOf(".") == 0)
		{
			return false;
		}
		// 备份一下cV用于后台验证;
		var _cV = cV;
    	while(cV.indexOf(".") != -1)
		{
    		cV = cV.replace(".", "");
		}
        iCheck.errorMsg = "正确格式如字母、数字和点的组合";
        // 验证是否包含中文;
        var reg =/[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/gi; 
        if(reg.test(cV))
        {
        	return false;
        }
        if(!iCheck.checkInVal(cV))
        {
        	return false;
        }
        iCheck.errorMsg = "此key已经存在,请重新输入";
        var remoteRet = false;
        $.ajax({
    		url : umpsetting.funcrootpath + "/util/validateKey.action?_charset_=utf-8&times="+new Date().getTime(),
    		dataType : "json",
    		type : "post",
    		async : false,
    		data : {
    			"key" : _cV
    		},
    		success:function(data){
    			remoteRet = data;
    		}
    	});
        return remoteRet;
    }),
    
    /* 
    * Desc: 检查字符串的格式
    * Args: s      string      待检测字符串, 传入字符串为null, 返回true
    *       _type  string      不传入, 表示判空;待检测类型,除以下类型外,可传入自定义js正则表达式
    *                          0: 判空
    *                          1: 数字,
    *                          2: 金额, 仅能存在两位小数
    *                          3: 手机,
    *                          4: 邮箱,
    *                          5: 卡号/账号
    *                          6: 日期
    *                          7：判断字符串长度是否大于指定长度, 大于返回false
    *                          8: 身份证(不为空且长度小于24)
    *                          9: 封锁码  true  ： 合法
    *                                   false : 不合法
    *                          10: 最大值(按字节占位)
    *       _len   int         判断的字符最大长度
    * Ret:  boolean    符合格式返回true, 否则返回false
    * Date: 2012-02-07
    * -------------------------------------------------------------------*/
    checkString : (function(s, _type, _len)
    {
        if(_type == null)
        {
            return s == null ? true : s.length == 0;
        }
        if(_len != null && s != null && iCheck.checkStrLen(s,_len))
        {
            return false;
        }
        switch(_type)
        {
            // 判空
            case 0: return s == null ? true : s.length == 0;
            // 数字
            case 1: return iCheck.checkByRegexp(s, /^\d+$/);
            // 金额
            case 2: return iCheck.checkByRegexp(s, /^([+-]?)((\d{1,3}(,\d{3})*)|(\d+))(\.\d{1,2})?$/ );
            // 手机
            case 3: return iCheck.checkByRegexp(s, /^(?:0?\d{11})$/);
            // 邮箱
            case 4: return iCheck.checkByRegexp(s, /[A-Za-z0-9_-]+[@](\S*)(net|com|cn|org|cc|tv|[0-9]{1,3})(\S*)/g);
            // 卡号/账号
            case 5: return iCheck.checkByRegexp(s, /^\d{16}$/);
            case 6: return iCheck.jgeDate(s) || false;
            //判断字符串长度是否大于指定长度
            case 7: return !iCheck.checkStrLen(s,_len);
            // 身份证(不为空且长度小于24)
            case 8: return (!arguments.callee(s)) && arguments.callee(s, 7, 24);
            // 封锁码(1位的大写字母)
            case 9: return iCheck.checkByRegexp(s, /^[\sA-Z]{1}$/);
            // 判断最大值;
            case 10: return iCheck.checkMax2len(s, _len);
            default: return iCheck.checkByRegexp(s, _type);
        }
    }),
    /*
    * Desc: 通过正则表达式检查字符串
    * Args: s      string  待检查字符串
    *       regexp string  正则表达式
    * Rets: boolean  检查通过返回true,否则返回false
    * ------------------------------------------------- */
    checkByRegexp : (function(s, regexp)
    {
        if (regexp.test(s))
        {
            return true;
        }
        return false;
    }),
    /* 
    * Desc: 判断对象是否为空,如果为空则错误提示;
    * Args: objId:          ->待判空对象的页面id;  
    *       _type           ->0:字符串,1:数字,2:账号,3:手机,4:身份证,5:金额,6:邮箱,7:日期,8:字符串最长;
    *       _errorMsg       ->错误提示信息;
    *       _len            ->长度;
    *       _isNotEmpety    ->是否判空标志；默认判空，如果为true则不判空
    * Ret:  错误返回:false 正常返回:对象去空格后的值;
    * Date: 2011/11/23
    * -------------------------------------------------------------------*/
    checkValue : (function(objId, _type, _errorMsg, _len, _isNotEmpety)
    {
        try
        {
            var t_value = $v(objId).trim();
            // 判断是否为空;
            if(!t_value && !_isNotEmpety)
            {       
                // 如调用者传递了错误提示，则显示;
                if(_errorMsg)
                {
                    iPage.showMsg(4, _errorMsg);
                }
                return false;
            }
            // 判断是否还需其它判定;
            if(_type && t_value)
            {          
                switch(_type)
                {
                    case 0 : return iCheck.jgeStr(t_value, _errorMsg, _len) || false;
                    case 1 : return iCheck.jgeNum(t_value, _errorMsg, _len) || false;
                    case 2 : return iCheck.jgeAcctNo(t_value, _errorMsg, _len) || false;
                    case 3 : return iCheck.jgePhoneNum(t_value, _errorMsg) || false;
                    case 4 : return iCheck.jgeCertNo(t_value, _errorMsg) || false;
                    case 5 : return iCheck.isCurrency(t_value, _errorMsg) || false;
                    case 6 : return iCheck.jgeEmail(t_value, _errorMsg) || false;
                    case 7 : return iCheck.jgeDate(t_value, _errorMsg) || false;
                    case 8 : return iCheck.jgeStrMaxLength(t_value, _errorMsg, _len) || false;
                    default: return iCheck.jgeStr(t_value, _errorMsg, _len) || false;
                }
            }
            // 只判断空，直接返回;          
            return t_value || true;
        }
        catch(e)
        {
            iPage.showMsg(4, "<font color='red'>开发人员</font>:请检查id是否存在,或者类型是否具有value属性");
            return false;
        }
    }),
    
    /*
    * Desc: 判断字符串;
    * Args: va ->待判断的值
    *       _errorMsg ->错误提示信息;
    *        _len ->字符串长度;
    * Ret : true/false;
    * -------------------------------------------------------------------*/
    jgeStr : (function(va, _errorMsg, _len)
    {
        if(_len && va.length!=_len)
        {
            if(_errorMsg)
            {
                iPage.showMsg(4, _errorMsg);
            }
            return false;
        }
        return true; 
    }),

    /*
    * Desc: 判断字符串;
    * Args: va ->待判断的值
    *       _errorMsg ->错误提示信息;
    *       _len ->字符串最大长度;
    * Ret : true/false;
    * -------------------------------------------------------------------*/
    jgeStrMaxLength : (function(va, _errorMsg, _len)
    {
        var length = 0;
        for (var i=0, l=va.length; i<l; i++)
        {
            if (va.charCodeAt(i)>255)
            {
                length += 2;
            }
            else
            {
                length++;
            }
        }
        if(_len && length>_len)
        {
            if(_errorMsg)
            {
                iPage.showMsg(4, _errorMsg);
            }
            return false;
        }
        return true; 
    }),

    /*
    * Desc: 判断是否为数字;
    * Args: va ->待判断的值
    *        _errorMsg ->错误提示信息;
    * Ret : true/false;
    * -------------------------------------------------------------------*/
    jgeNum : (function(va, _errorMsg, _len)
    {
        //var patrn=/^[0-9]{1,20}$/; 
        var patrn = /^[0-9]*[0-9]*$/;
        if (!patrn.test(va))
        { 
            if(_errorMsg)
            {
                iPage.showMsg(4, _errorMsg);
            }
            return false;
        }
        if(_len && va.length!=_len)
        {
            if(_errorMsg)
            {
                iPage.showMsg(4, _errorMsg);
            }
            return false;
        }
        return true; 
    }),
    
    /*
    * Desc: 判断是否为金额;
    * Args: va       ->待判断的值
    *        _errorMsg ->错误提示信息;
    * Ret : true/false;
    * Date: 2011/10/12
    * -------------------------------------------------------------------*/
    isCurrency : (function(va, _errorMsg)
    {
        var pattern=/^(\d)+(\.(\d){1,2})?$/;
        if (va&&pattern.test(va))
        {
            return true;
        }
        else
        {
            if(_errorMsg)
            {
                iPage.showMsg(4, _errorMsg);
            }
            return false;
        }
    }),
    
    /*
    * Desc: 判断是否为身份证号码15位,或18位;
    * Args: va ->待判断的值
    *        _errorMsg ->错误提示信息;
    * Ret : true/false;
    * Date: 2011/10/12
    * -------------------------------------------------------------------*/
    jgeCertNo : (function(va, _errorMsg)
    {
        if(va.length==15 || va.length==18)
        { 
            return true;
        }
        else
        {
            if(_errorMsg)
            {
                iPage.showMsg(4, _errorMsg);
            }
            return false; 
        }
    }),
    
    /*
    * Desc: 判断账号;
    * Args: va ->待判断的值
    *        _errorMsg ->错误提示信息;
    * Ret : true/false;
    * Date: 2011/10/12
    * -------------------------------------------------------------------*/
    jgeAcctNo : (function(va, _errorMsg, _len)
    {
        var patrn=/^[0-9]{1,20}$/; 
        if (!patrn.exec(va))
        { 
            if(_errorMsg)
            {
                iPage.showMsg(4, _errorMsg);
            }
            return false;
        }
        if(_len && va.length!=_len)
        {
            if(_errorMsg)
            {
                iPage.showMsg(4, _errorMsg);
            }
            return false;
        }
        return true; 
    }),
    
    /*
    * Desc: 判断手机号;
    * Args: va ->待判断的值
    *        _errorMsg ->错误提示信息;
    * Ret : true/false;
    * Date: 2011/10/12
    * -------------------------------------------------------------------*/
    jgePhoneNum : (function(va, _errorMsg)
    {
        var patrn=/^[0-9]{1,20}$/; 
        if (!patrn.exec(va))
        { 
            if(_errorMsg)
            {
                iPage.showMsg(4, _errorMsg);
            }
            return false;
        }
        if(va.length == 11){ 
            return true;
        }
        if(_errorMsg)
        {
            iPage.showMsg(4, _errorMsg);
        }
        return false;
    }),
    
    /*
    * Desc: 判断是否为邮箱;
    * Args: va ->待判断的值
    *        _errorMsg ->错误提示信息;
    * Ret : true/false;
    * -------------------------------------------------------------------*/
    jgeEmail : (function(va, _errorMsg)
    {
        var patrn = /^\w+((-\w+)|(.\w+))*@[A-Za-z0-9]+((.|-)[A-Za-z0-9]+)*.[A-Za-z0-9]+$/;
        if (!patrn.test(va))
        { 
            if(_errorMsg)
            {
                iPage.showMsg(4, _errorMsg);
            }
            return false;
        }
        return true; 
    }),

    /*
    * Desc: 判断是否为日期;
    * Args: va ->待判断的值
    *        _errorMsg ->错误提示信息;
    * Ret : true/false;
    * -------------------------------------------------------------------*/
    jgeDate : (function(va, _errorMsg)
    {
        var patrn = /^\d{4}(\-|\/|\.)/;
        if (!patrn.test(va))
        { 
            if(_errorMsg)
            {
                iPage.showMsg(4, _errorMsg);
            }
            return false;
        }
        return true; 
    }),
     /*
    * Desc: 判断字符串是否大于指定长度;
    * Args: s ->待判断的值
    *        len ->字符串长度;
    * Ret : true/false;
    * -------------------------------------------------------------------*/
    checkStrLen : (function(s,len)
    {
        var str = s.trim();
        var a = 0;
        //循环计数
        for(var i=0, l=str.length; i<l; i++)
        {
            if (str.charCodeAt(i)>255)
            {
                //按照预期计数增加2
                a+=2;
            }
            else
            {
                a++;
            }            
        }
        if(a>len)
        {
            return true;
        }
        else
        {
            return false;
        }
    }),
    /*
    * Desc: 判断Url返回码格式是否正确;
    * Args: cV ->待检查值;
    * Ret : true|false(检查合格|检查不合格);
    * ------------------------------------------------- */
     checkReturnCode : (function(cV)
     {
         iCheck.errorMsg = "返回码必须为正整数，多个以英文逗号隔开";
         return iCheck.checkByRegexp(cV, /^([1-9]\d*,)+[1-9]\d*$|^([1-9]\d*)$/);
     }),
     
     /*
     * Desc: 判断字符串是否是url地址,不包含http://;
     * Args: url ->待检查值;
     * Ret : true|false(检查合格|检查不合格);
     * ------------------------------------------------- */
     checkUrl : (function(url)
     {
    	 //在JavaScript中，正则表达式只能使用"/"开头和结束，不能使用双引号
    	 //判断URL地址的正则表达式为:http(s)?://([\w-]+\.)+[\w-]+(/[\w- ./?%&=]*)?
    	 //下面的代码中应用了转义字符"\"输出一个字符"/"
    	 if($.trim(url).indexOf("http://")==0 || $.trim(url).indexOf("https://")==0 || $.trim(url).indexOf("<") != -1 ||$.trim(url).indexOf(">") != -1){
    		 iCheck.errorMsg = "监控地址不能以http(s)://开头且不包含<、>等特殊字符";
    		 return;
    	 }
    	 return true;
    	}),
    	
    	/*
        * Desc: 判断端口存活监控地址是否是ip加端口号的格式;
        * Args: portAddress ->待检查值;
        * Ret : true|false(检查合格|检查不合格);
        * ------------------------------------------------- */
        checkPortAddress : (function(portAddress)
        {
	       	 iCheck.errorMsg = "非法的监控地址";
	       	 var ipAddrArr = portAddress.split("\:");
	       	 var objExp = new RegExp(/^(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9]):(\d{1,5})$/);
	       	 return (ipAddrArr[1] >= 0 && ipAddrArr[1] <= 65535 && objExp.test($.trim(portAddress)));
       	}),
       	
       	
       	/*
        * Desc: 判断url存活通过erp方式跳转的密码格式是否正确;
        * Args: passWord ->待检查值;
        * Ret : true|false(检查合格|检查不合格);
        * ------------------------------------------------- */
        checkPassWord : (function(passWord)
        {
	       	iCheck.errorMsg = "密码不能包含&、%、+和=等特殊字符";
	       	if($.trim(passWord).indexOf("=")!=-1||$.trim(passWord).indexOf("&")!=-1||$.trim(passWord).indexOf("%")!=-1||$.trim(passWord).indexOf("+")!=-1){
	       		return false;
	       	}
	       	 return true;
       	}),
       	
       	
         /* Desc: 判断是否包含中文字符;
         * Args: value ->待检查值;
         * Ret : true|false(包含|不包含);
         * ------------------------------------------------- */
         checkChinese : (function(value)
         {
        	 var p = /[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/gi;
 	       	 return p.test(value);
          }),
          
          /*
      	* Desc: 判断批量url是否;
      	* Args: cV  ->待检查值;
      	* Ret : true|false(检查合格|检查不合格);
      	* ------------------------------------------------- */
      	checkBatchUrl : (function(cV)
          {
      		cV = cV.trim();
      		iCheck.errorMsg = "正确格式不能以.开始";
      		if(cV.indexOf(".") == 0)
      		{
      			return false;
      		}
      		// 备份一下cV用于后台验证;
      		var _cV = cV;
          	while(cV.indexOf(".") != -1)
      		{
          		cV = cV.replace(".", "");
      		}
              iCheck.errorMsg = "正确格式如字母、数字和点的组合";
              // 验证是否包含中文;
              var reg =/[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/gi; 
              if(reg.test(cV))
              {
              	return false;
              }
              
              var checkChart = {
            		  "#" : 1,
                      "$" : 1
              };
              if(!iCheck.checkInVal(cV, checkChart))
              {
              	return false;
              }
              return true;
          })
     
};
