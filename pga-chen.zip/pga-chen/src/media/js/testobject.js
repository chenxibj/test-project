/*******************
 演示项目中操作testobject对象的JS代码，项目中可删除。
 by：zhangc
 *******************/

function deleteTestobject(testobjectId) {
	if(!confirm("确认删除测试对象：id=" + testobjectId)){
		return;
	}
	$.get("/testobject/delete/", {id:testobjectId}, function (isSuccess, status){
		//status请求状态：success，error等等。
		if (status != "success"){
			alert('处理失败！');
			return;
		}
		if (isSuccess){
			alert('删除成功！');
			trId = "tr_" + testobjectId;
			$("#" + trId).hide();
		} else {
			alert('删除失败！');
		}
	});
}

/* 
 * options:{
 * 		url: url // override for form's 'action' attribute
 * 		dataType: null // 'xml', 'script', or 'json' (expected server response type)
 * 		clearForm: true // clear all form fields after successful submit
 * 		resetForm: true // reset the form after successful submit
 * 		timeout: 3000
 * }
 */
$(document).ready(function() {
	var options = {
		beforeSubmit : preSubmit, // pre-submit callback
		success : showResponse, // post-submit callback
		type : 'post' // 'get' or 'post', override for form's 'method' attribute
	};

	$('#edit_form').ajaxForm(options);
});

function preSubmit(){
	return true;
}

function showResponse(responseText, statusText, xhr, $form){
	if (statusText != 'success'){
		alert("编辑失败！")
		return false;
	}
	
	if(responseText != "True"){
		alert("编辑失败！")
		return false;
	}
	
	alert("编辑成功！");
	window.location.href = "/testobject/list/";
}
