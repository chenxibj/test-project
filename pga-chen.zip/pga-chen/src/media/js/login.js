/*******************
 * login.html
 * by:zhangc
 * 
 * FUNCTION：
 * 1.Slider-in icons
 *******************/
$(document).ready(function() {
	/*******************
	 登陆页面中输入用户名和密码时的弹出效果
	 *******************/
	$(".username").focus(function() {$(".user-icon").css("left","-48px");});
	$(".username").blur(function() {$(".user-icon").css("left","0px");});
	
	$(".password").focus(function() {$(".pass-icon").css("left","-48px");});
	$(".password").blur(function() {$(".pass-icon").css("left","0px");});
});