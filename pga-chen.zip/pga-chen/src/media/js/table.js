/*******************
 TABLE控制相关JS
 by: zhangc
 *******************/

$(document).ready(function(){
	/*******************
	 TABLE排序相关JS，使用此JS需引入/js/jquery.tablesorter.js。
	 如不需使用排序功能，可将此段JS删除。
	 *******************/
	$("table").css("class", "tablesorter");
	$("table").tablesorter();
	
	/*******************
	 TABLE行变色：单击表格行，使其变色，再次单击，则恢复。
	 *******************/
	$('tr').click(function(){
		if ($(this).find("td").hasClass("select_tr")){
			$(this).find("td").removeClass("select_tr");
		} else {
			$(".select_tr").removeClass("select_tr");
			$(this).find("td").addClass("select_tr");
		}
	});
	
	/*******************
	 TABLE行变色：鼠标移动，使表格行变色。
	 *******************/
	$("tr").mouseover(function() {
		// 如果鼠标移到表格的tr上时，执行函数
		$(this).children("td").addClass("over");
	}).mouseout(function() {
		// 如果鼠标移出表格的tr时，执行函数
		$(this).children("td").removeClass("over")
	})
	
	/*******************
	 TABLE工具栏：可隐藏table中的指定列。
	 *******************/
	var ths = $("th");
	html = "";
	for (i=0; i<ths.length; i++){
		html += "<input type=\"checkbox\" onclick=\"hideTd(" + i 
				+ ")\" id=\"" + ths.eq(i).text()
				+ "\" value=\"" + ths.eq(i) + "\">" + ths.eq(i).text();
	}
	$("#hidetddiv").html(html);
});

/*******************
 隐藏table中的指定ID的列。
 *******************/
function hideTd(tdId){
	if ($("th:eq("+tdId+")",$("tr")).is(":hidden")) {
		$("th:eq("+tdId+")",$("tr")).show();
		$("td:eq("+tdId+")",$("tr")).show();
	} else {
		$("th:eq("+tdId+")",$("tr")).hide();
		$("td:eq("+tdId+")",$("tr")).hide();
	}
}

/*******************
 “展开/隐藏”TABLE工具栏
 *******************/
function showFilter(){
	if ($("#filter").is(":hidden")){
		$("#filter").slideDown();
	} else {
		$("#filter").slideUp();
	}
}