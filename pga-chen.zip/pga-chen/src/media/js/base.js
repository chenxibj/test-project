/*******************
 全局基础JS
 by: zhangc
 
 注：此JS必须引入到网页中
 *******************/

$(document).ready(function(){
	/*******************
	 网页导航工具栏
	 *******************/
	$("#map_button").bind("mouseover", function() {
		if ($("#header_map_bar").is(":hidden")){
			$("#header_map_bar").slideDown(300);
		}
	});
	$("#header_map_bar").bind("mouseleave", function(){
		if (!$("#header_map_bar").is(":hidden")){
			$("#header_map_bar").slideUp(300);
		}
	});
	$("#header_map_bar").mousedown(function(e) {
		if (1 != e.which) { // 判断是否鼠标左键（1，左；2，中；3，右）
			return;
		}
		if (!$("#header_map_bar").is(":hidden")){
			$("#header_map_bar").slideUp(300);
		}
	});
});

/*******************
左侧导航栏定位
*******************/
window.onload = window.onresize = function(){
	var oHeight = document.documentElement.clientHeight || document.body.clientHeight;
	var oHeader = document.getElementById("page_header");
	var oCon = document.getElementById("container");
	var oFooter = document.getElementById("footer");
	oCon.style.height = oHeight - 81 + 'px';
}

$(document).ready(function() {
	/*******************
	 左侧导航栏中，导航项的“展开/隐藏”效果
	 *******************/
	$(".nav > li > a").click(function() {
		if($(this).next("ul").is(":hidden")){
			$(this).next("ul").slideDown(300);
		} else {
			$(this).next("ul").slideUp(300);
		}
	});
	
	/*******************
	 左侧导航栏的展开和隐藏效果
	 *******************/
	var isSidebarHidden = false;
	$("#sidebar_button").click(function(){
		if (isSidebarHidden){
			$(".left_sidebar").animate({width:180},"slow");
			$("#hidden_status").show();
			$("#show_status").hide();
			isSidebarHidden = false;
		} else {
			$(".left_sidebar").animate({width:0},"slow");
			$("#hidden_status").hide();
			$("#show_status").show();
			isSidebarHidden = true;
		}
	});
});

/****************************
   全局通用函数 ： 获取一个name的cookie值
 ****************************/
function getCookie(name)
{
	var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
	if(arr=document.cookie.match(reg))
		return unescape(arr[2]);
	else
		return null;
}
	
	