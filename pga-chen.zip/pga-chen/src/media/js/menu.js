$(document).ready(function() {
	$(".nav > li > a").click(function() {
		if($(this).next("ul").is(":hidden")){
			$(this).next("ul").slideDown(300);
		} else {
		//	$(this).next("ul").slideUp(300);
		}
	});
});