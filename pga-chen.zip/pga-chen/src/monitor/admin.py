from django.contrib import admin
from monitor.models import MonitorService

# Register your models here.
class MonitorServiceAdmin(admin.ModelAdmin):
    list_display = ('name','type','service_vars','comment','current_monitor','protected','sec_vars')
    
admin.site.register(MonitorService,MonitorServiceAdmin)