from django.core.management.base import BaseCommand, CommandError  
import re
from pga.utils.fileutils import create_dir, write_file_from_content
from pga.settings import TMP_DIR

class Command(BaseCommand):
    
    def add_arguments(self, parser):
        parser.add_argument('zbx_name', type=str)
        parser.add_argument('file_name',type=str)
    
    def handle(self, *args, **options):
        zbx_name = options['zbx_name']
        file_name = options['file_name']

        
            
                        
                    