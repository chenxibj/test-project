#coding:utf-8
from __future__ import unicode_literals

from django.db import models
from django.forms.models import ModelForm

# Create your models here.

class MonitorService(models.Model):
    name = models.CharField(max_length=50,  null=True)
    type = models.CharField(max_length=50,  null=True)
    service_vars = models.CharField(max_length=1500, blank=True, null=True)
    sec_vars = models.CharField(max_length=1500, blank=True, null=True)
    current_monitor = models.BooleanField(default=0)
    protected = models.BooleanField(default=0)
    comment = models.CharField(max_length=150, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)
    
    def __unicode__(self):
        return self.name
    
class MonitorServiceForm(ModelForm):
    class Meta:
        model = MonitorService
        fields = ('name','type','service_vars','comment','current_monitor')