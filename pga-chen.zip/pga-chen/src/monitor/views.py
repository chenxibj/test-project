# -*- coding: utf8 -*-
from django.shortcuts import render
from monitor.models import MonitorService, MonitorServiceForm
from django.http.response import HttpResponse
from pga.utils.zbxapiutils import zbxapi_get_token, getHostGroupId_by_groupname,\
    getHosts_by_groupid, createHost, getTemplateId_by_templatename
from cmdb.models import Server
import json

# Create your views here.

def monitor_config(request,nav):
    tree_mode = request.GET.get("tree_mode")
    if not tree_mode or tree_mode =='':
        tree_mode = 'bycluster'
    nodekey = request.GET.get("nodekey")
    if not nodekey or nodekey =='':
        nodekey = 'top'
   
    if tree_mode == 'bycluster':
        if nodekey == 'top':
            
            if MonitorService.objects.filter(current_monitor = True):
                monitorService = MonitorService.objects.get(current_monitor = True)
            else:
                return render(request, "monitor/monitor_config.html", locals())
            if not monitorService:
                return render(request, "monitor/monitor_config.html", locals())
            service_vars = json.loads(monitorService.service_vars)
            product_ids = service_vars["product_ids"]
            idc_ids = service_vars["idc_ids"]
            
            servers_nozbx = Server.objects.filter(zbx_hostid = 0,product_id__in = product_ids, idc_id__in = idc_ids)
            servers_inzbx = Server.objects.filter(product_id__in = product_ids, idc_id__in = idc_ids).exclude(zbx_hostid = 0)
            
            zbx_token = zbxapi_get_token()
            if not zbx_token:
                return render(request, "monitor/monitor_config.html", locals())
            group = getHostGroupId_by_groupname(zbx_token,groupname="Zabbix servers")
            hosts = getHosts_by_groupid(zbx_token,groupid=group['result'][0]['groupid'])
            
            all_zbxservers = MonitorService.objects.all()
            
            return render(request, "monitor/monitor_config.html", locals())

    return HttpResponse(u"此页面建设中，请后退重来")

def ajax_monitor_add(request):
    form_type = request.GET.get('form_type')
    if request.method == "POST" and request.is_ajax:
        if form_type == 'monitorservice':
            form = MonitorServiceForm(request.POST)
        else:
            return HttpResponse('noduang')
        if form.is_valid():
            form.save()
            return HttpResponse('duang')
    else:
        if form_type == 'monitorservice':
            form = MonitorServiceForm()
        else:
            return HttpResponse('noduang')
    
    return render(request,'monitor/ajax_monitor_add.html',{'form':form,'form_type':form_type})

def ajax_monitor_edit(request):
    form_type = request.GET.get('form_type')
    tr_id = request.GET.get('tr_id')
    if request.method == "POST" and request.is_ajax:
        if form_type == 'monitorservice':
            form = MonitorServiceForm(request.POST,instance = MonitorService.objects.get(id=tr_id))        
        else:
            return HttpResponse('noduang')
        if form.is_valid():
            form.save()
            return HttpResponse('duang')
    else:
        if form_type == 'monitorservice':
            form = MonitorServiceForm(instance = MonitorService.objects.get(id=tr_id))        
        else:
            return HttpResponse('noduang')
    
    return render(request,'monitor/ajax_monitor_edit.html',{'form':form,'form_type':form_type,'tr_id':tr_id})    

def ajax_monitor_del(request):
    form_type = request.POST.get('form_type')
    tr_id = request.POST.get('tr_id')    
    if form_type == 'monitorservice':
        if MonitorService.objects.filter(product_id = tr_id):
            return HttpResponse(u'删不了，这个产品线下还有服务关联着')
        monitorService = MonitorService.objects.get(id = tr_id, protected = False)
        if monitorService:
            monitorService.delete()
            return HttpResponse(u'succeed')
        else:
            return HttpResponse(form_type + u' id: '+tr_id+u' 不存在或只读')
    return HttpResponse(form_type+'del'+tr_id+': 未知情况，请截图给管理员')

def ajax_create_zbxhosts(request):
    
    response_data = {}
    server_ids = request.POST.get('server_ids')
    if not server_ids:
        response_data['status'] = 'failed'
        response_data['msg'] = "u select no servers"
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    serverids = server_ids.split("##")
    servers = Server.objects.filter(id__in = serverids)
    
    zbx_token = zbxapi_get_token()
    group = getHostGroupId_by_groupname(zbx_token,groupname="Linux servers")
    template = getTemplateId_by_templatename(zbx_token,templatename="Template OS Linux")
    groupid=group['result'][0]['groupid']
    templateid = template['result'][0]['templateid']
    
    servers_succeed = []
    servers_failed = []
    for server in servers:
        hostid = createHost(zbx_token,groupid,templateid,server)
        if hostid:
            servers_succeed.append(server.id)
            server = Server.objects.get(id=server.id)
            server.zbx_hostid = int(hostid)
            server.save()
        else:
            servers_failed.append(server.id)
    response_data['servers_succeed'] = servers_succeed
    response_data['server_failed'] = servers_failed
    
    return HttpResponse(json.dumps(response_data))
