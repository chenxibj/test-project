#!/bin/bash

# Replace these three settings.

PROJDIR=$(pwd)
PIDFILE="$PROJDIR/mysite.pid"

cd $PROJDIR

if [ -f $PIDFILE ]; then
    kill `cat -- $PIDFILE`
    rm -f -- $PIDFILE
fi
