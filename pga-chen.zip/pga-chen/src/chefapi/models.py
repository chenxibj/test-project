#coding:utf-8
from __future__ import unicode_literals

from django.db import models

# Create your models here.

class Connections(models.Model):
    ''' 服务器信息  隶属于server'''
    serverurl = models.CharField(max_length=150)
    pemfilename = models.CharField(max_length=150)
    chefuser = models.CharField(max_length=50)
    idc = models.ForeignKey('cmdb.Idc')
    env = models.ForeignKey('cmdb.Env')
    enabled = models.BooleanField(default=0)


