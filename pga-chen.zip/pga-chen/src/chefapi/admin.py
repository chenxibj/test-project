from django.contrib import admin
from chefapi.models import Connections

# Register your models here.

class ConnectionsAdmin(admin.ModelAdmin):
    list_display = ('id','serverurl','pemfilename','chefuser','idc','env', 'enabled')
    
admin.site.register(Connections, ConnectionsAdmin)