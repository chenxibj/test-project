from chefapi.utils.chefApiWrapper import ChefApiWrapper
from pga.settings import BASE_DIR

url = "https://chefserver.gz01.jcloud.com/organizations/jcloud"
pem_path = BASE_DIR + '/tmp/ca/pga_api.pem'
user = 'pga_api'

ca = ChefApiWrapper('prod', 'bj02', url, pem_path, user)
cv = ca.getChefVars()

print cv