#coding:utf-8

from django.http.response import HttpResponse
import json
from chefapi.utils.chefApiWrapper import ChefApiWrapper
from cmdb.models import Soft, Service


# Create your views here.

def getChefVars(request):
    
    idc = request.GET.get('idc')
    env = request.GET.get('env')

    chefConnections = ChefApiWrapper.getConnections(env, idc)
    if not chefConnections:
        return HttpResponse(("get chef connection failed, idc: %s, env: %s " % (idc, env)))
    
    d = ChefApiWrapper.convConnectionsObj(chefConnections)
    
    caw = ChefApiWrapper(**d)
    r = caw.getChefVars(env, idc)
    return HttpResponse(json.dumps(r, indent=4, sort_keys=True),content_type="application/json")

def getMonitor(request):
    
    soft = request.GET.get("soft")
    list_type = request.GET.get("t")
    chefConnections = ChefApiWrapper.getConnections()
    if not chefConnections:
        return HttpResponse("get chef connection failed, default prod_bj02")    
    d = ChefApiWrapper.convConnectionsObj(chefConnections)
    caw = ChefApiWrapper(**d)
    r = caw.getMonitorProcesses(soft)
    if list_type == 'process':
        r = ChefApiWrapper.getMonitorProcessList(r)
    return HttpResponse(json.dumps(r, indent=4, sort_keys=True),content_type="application/json")

def getAllMonitor(request):
    
    rr = {}
    service_name = request.GET.get("service")
    list_type = request.GET.get("t")
    chefConnections = ChefApiWrapper.getConnections()
    if not chefConnections:
        return HttpResponse("get chef connection failed, default prod_bj02")    
    d = ChefApiWrapper.convConnectionsObj(chefConnections)
    caw = ChefApiWrapper(**d)
    
    try:
        service = Service.objects.select_related().get(name=service_name)
    except:
        return HttpResponse("service not exist: %s" % service_name)
    
    siss = service.softinservice_set.select_related().all()
    for sis in siss:
        soft = sis.soft
        try:
            r = caw.getMonitorProcesses(soft.name)
        except Exception as e:
            r = {"error": ("%s" % e)}
        if list_type == 'process':
            rr[soft.name] = ChefApiWrapper.getMonitorProcessList(r)
        else:
            rr[soft.name] = r
    return HttpResponse(json.dumps(rr, indent=4, sort_keys=True),content_type="application/json")

def getServerModules(request):
    
    details = request.GET.get("details")
    chefConnections = ChefApiWrapper.getConnections()
    if not chefConnections:
        return HttpResponse("get chef connection failed, default prod_bj02")    
    d = ChefApiWrapper.convConnectionsObj(chefConnections)
    caw = ChefApiWrapper(**d)
    
    sms = caw.getServerModules()
    if not details:
        r = []
        for serverModule_name, __ in sms.items():
            r.append(serverModule_name)
        return HttpResponse(json.dumps(r, indent=4, sort_keys=True),content_type="application/json")
    
    return HttpResponse(json.dumps(sms, indent=4, sort_keys=True),content_type="application/json")

def getUnderlayNetworkingConf(request):
    
    un_name = request.GET.get("un_name")
    
    chefConnections = ChefApiWrapper.getConnections()
    if not chefConnections:
        return HttpResponse("get chef connection failed, default prod_bj02")    
    d = ChefApiWrapper.convConnectionsObj(chefConnections)
    caw = ChefApiWrapper(**d)
    
    networks = caw.getDatabagItem("underlayNetworking", "jcloud")
    try:
        nw = networks.get("networks")[un_name]
    except Exception as e:
        msg = ('failed to get underlayNetworking %s because of: %s' % (un_name, e))
        return HttpResponse(json.dumps(dict(code=1,msg=msg)),content_type="application/json")
    
    return HttpResponse(json.dumps(nw, indent=4, sort_keys=True),content_type="application/json")
    
def getDb(request):
    
    idc = request.GET.get('idc')
    env = request.GET.get('env')
    db_name = request.GET.get('db_name')

    print request.META

    chefConnections = ChefApiWrapper.getConnections()
    if not chefConnections:
        return HttpResponse("get chef connection failed, default prod_bj02")    
    d = ChefApiWrapper.convConnectionsObj(chefConnections)
    caw = ChefApiWrapper(**d)
    
    db_conf = caw.getDatabagItem("databases", env + "_" + idc + "_mysql")
    db = db_conf.get("usage_mapping")[db_name]
    cluster = db_conf.get("clusters")[db["cluster"]]
    db.update(cluster)
    
    return HttpResponse(json.dumps(db, indent=4, sort_keys=True),content_type="application/json")   

def getAllAssists(request):

    item = request.GET.get('item')
    sub_item = request.GET.get('sub_item')
    chefConnections = ChefApiWrapper.getConnections()
    if not chefConnections:
        return HttpResponse("get chef connection failed, default prod_bj02")    
    d = ChefApiWrapper.convConnectionsObj(chefConnections)
    caw = ChefApiWrapper(**d)
    
    assist = caw.getDatabagItem("assist", item)
    r = assist.get(sub_item)
    
    return HttpResponse(json.dumps(r, indent=4, sort_keys=True),content_type="application/json") 
    
    
    
    
    
    