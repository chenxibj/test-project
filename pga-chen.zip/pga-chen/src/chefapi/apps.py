from django.apps import AppConfig


class ChefapiConfig(AppConfig):
    name = 'chefapi'
