#encoding=utf8

#offline @20170203 by madongdong1@jd.com

from netaddr import IPAddress,  IPNetwork
import re
from cmdb.config import NEW_SDN_VDR, NEW_SDN_AS

def isIP(s):
    p = r'^([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])$'
    if not re.match(p, s):
        raise ValueError('string: %s is not an ipaddress ' % s)

def is_netmask(s):
    isIP(s)
    n = IPAddress(s)
    if not n.is_netmask():
        raise ValueError('string: %s is not a netmask ' % s)

def getIPrange(netmask):
    
    is_netmask(netmask)
    t = IPAddress('255.255.255.255')
    n = IPAddress(netmask)
    
    return t.value - n.value + 1   

def getFirstIP(ip, netmask):
    
    isIP(ip)
    is_netmask(netmask)
    
    return str(IPAddress(IPAddress(ip).value & IPAddress(netmask).value))

def getGatewayIP(ip, netmask, order = 'desc', count = 2 ):
    
    fIP = int(IPAddress(getFirstIP(ip, netmask)))
    IPrange = getIPrange(netmask)
    
    if order == 'desc':
        return str(IPAddress(fIP + IPrange - count))
    elif order == 'asc':
        return str(IPAddress(fIP + count))
    
def eth02VDR(eth0, eth0_cidr, target_cidr):
    
    isIP(eth0)
    eth0_start = IPNetwork(eth0_cidr)[0]
    target_start = IPNetwork(target_cidr)[0]
    
    target_int =IPAddress(eth0).value - eth0_start.value + target_start.value
    target = str(IPAddress(target_int))
    
    return target   

def getVDRips(eth0, rack, idc, env):   

    
    cidrs = NEW_SDN_VDR[env][idc]
    ASs = NEW_SDN_AS[env][idc]
    
    for cidr in cidrs:
        if IPAddress(eth0) in IPNetwork(cidr):
            eth0_gateway = getGatewayIP(eth0, cidrs[cidr]["netmask"])
            #print "eth0_gateway: %s" % eth0_gateway
            dv = eth02VDR(eth0, cidr, cidrs[cidr]["dv"]["cidr"])
            dv_gateway = getGatewayIP(dv, cidrs[cidr]["dv"]["netmask"])
            #print dv, dv_gateway
            vv = eth02VDR(eth0, cidr, cidrs[cidr]["vv"]["cidr"])
            vv_gateway = getGatewayIP(vv, cidrs[cidr]["vv"]["netmask"])
            #print vv, vv_gateway
            ds = eth02VDR(eth0, cidr, cidrs[cidr]["ds"]["cidr"])
            ds_gateway = getGatewayIP(ds, cidrs[cidr]["ds"]["netmask"])
            #print ds,ds_gateway
            dbgp = eth02VDR(eth0, cidr, cidrs[cidr]["dbgp"]["cidr"])
            dbgp_gateway = getGatewayIP(dbgp, cidrs[cidr]["dbgp"]["netmask"])
            #print dbgp, dbgp_gateway
            peer_as = ASs[rack][0]
            dr_as = ASs[rack][1]
            
            return dict(eth0_gateway=eth0_gateway, 
                        dv=dv, dv_gateway=dv_gateway, 
                        vv = vv,vv_gateway =vv_gateway, 
                        ds=ds,ds_gateway=ds_gateway, 
                        dbgp = dbgp,dbgp_gateway = dbgp_gateway,
                        peer_as = peer_as, dr_as = dr_as) 
    
    raise ValueError('eth0: %s is missing' % eth0)