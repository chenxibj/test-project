#encoding=utf8
'''
Created on 2017年2月10日

@author: madongdong1
'''
import chef
from pga.settings import BASE_DIR
from cmdb.models import Idc, Env
from chefapi.models import Connections

JCLOUD_ITEM_KEYS = ["jcloud", "openstack", "ebs"]
MIDDLEWARE_ITEM_KEYS = ["redis", "memcached", "rabbitmq", "kafka"]
DATABASE_ITEM_KEYS = ["mysql"]
MONITOR_ITEM_KEYS = ["processes"]

class ChefApiWrapper(object):
    '''
    classdocs
    '''

    def __init__(self, server_url, pem_file_path, user):
        '''
        Constructor
        '''
        self.apiObj = chef.ChefAPI(server_url, pem_file_path, user, version='12.9.38', headers={}, ssl_verify=False)

    @staticmethod
    def convConnectionsObj(chefConnectionsObj):
        server_url = chefConnectionsObj.serverurl
        pem_file_path = BASE_DIR + '/tmp/ca/' + chefConnectionsObj.pemfilename
        user = chefConnectionsObj.chefuser
        return dict(server_url=server_url,pem_file_path=pem_file_path,user=user)

    @staticmethod
    def getConnections(env = 'prod', idc = 'bj02'):
        try: 
            try:
                idcObj = Idc.objects.get(name=idc)
                envObj = Env.objects.get(name=env)
            except:
                idcObj = Idc.objects.get(name="bj02")
                envObj = Env.objects.get(name="prod")            
            return Connections.objects.select_related().get(env=envObj, idc=idcObj)
        except Exception as e:
            msg = ('env %s and idc %s chef connection not exist, or exception as : %s' % (env, idc, e))
            print msg
            return False

    def getDatabagItem(self, databag, item):
        
        return chef.DataBagItem(databag, item)
      
    def getJcloudDatabagItem(self, envidc):
        
        item = envidc + '_jcloud'
        return chef.DataBagItem("jcloud", item, self.apiObj)
    
    def getMiddlewareDatabagItem(self, item, envidc):
        
        item = envidc + '_' + item
        return chef.DataBagItem("middlewares", item, self.apiObj)
    
    def getDatabasesDatabagItem(self, item, envidc):
        
        item = envidc + '_' + item
        return chef.DataBagItem("databases", item, self.apiObj)

    def getAssistDatabagItem(self, item, sub_item):
        
        return chef.DataBagItem("databases", item, self.apiObj).get(sub_item)[self.env][self.idc]

    def getEnvironment(self, envidc):
        
        return chef.Environment(envidc, self.apiObj)

    def getServerModules(self):
        
        return chef.DataBagItem("serverModules", 'jcloud', self.apiObj).get('modules')

    def getChefVars(self, env, idc):
        
        r = {}
        envidc = env + '_' + idc
        jcloud_databag_item = self.getJcloudDatabagItem(envidc)
        for k in JCLOUD_ITEM_KEYS:
            r[k] = jcloud_databag_item.get(k, envidc)
        for mw in MIDDLEWARE_ITEM_KEYS:
            middleware_databag_item = self.getMiddlewareDatabagItem(mw, envidc)
            r[mw] = dict(clusters=middleware_databag_item.get("clusters"), usage_mapping = middleware_databag_item.get("usage_mapping"))
        for db in DATABASE_ITEM_KEYS:
            database_databag_item = self.getDatabasesDatabagItem(db, envidc)
            r[db] = dict(clusters=database_databag_item.get("clusters"), usage_mapping = database_databag_item.get("usage_mapping"))
        
        
        return r
         
    def getMonitorProcesses(self, soft):
        
        r = {}
        monitor_databag_item = chef.DataBagItem("monitor", soft, self.apiObj)
        for i in MONITOR_ITEM_KEYS:
            r[i] = monitor_databag_item.get(i)
        return r
    
    @staticmethod
    def getMonitorProcessList(r):
        l = []
        if not r or not r.has_key("processes"):
            return l
        if r["processes"]:
            for p in r["processes"]:
                if p["process"]:
                    l.append(p["process"])
            l = list(set(l))
        return l
    
    
    