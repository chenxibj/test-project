#coding:utf-8
from cmdb.models import Service, Env, Idc, Unit
from deploy.models import PlayBook, PlayLog
from pga.utils.fileutils import get_content_from_file, create_link
from pga.settings import PLAYBOOK_DIR, PLAYBOOK_TMP_DIR
import json
from django.http.response import HttpResponse
from deploy.utils.ansibleutils import create_ansible_inventory_content_from_cluster

def ajax_get_playbook_content(request):
    '''return code: 0. succeed; 1. file not exist; 2. io exception; 3. db error'''
    
    playbook_id = request.POST.get('playbook_id')
    response_data = {}
    
    if not PlayBook.objects.filter(id = playbook_id):
        response_data['code'] = '3'
        response_data['data'] = 'invalid playbook_id ' + playbook_id 
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    playbook_path = PlayBook.objects.get(id = playbook_id).path
    if playbook_path.startswith('/'):
        playbook_file = playbook_path
    else:
        playbook_file = PLAYBOOK_DIR + playbook_path
    json_data = get_content_from_file(playbook_file)
    response_data['code'] = json_data['code']
    response_data['data'] = json_data['data']
        
    return HttpResponse(json.dumps(response_data),content_type="application/json")

def ajax_get_components(request):
    
    cluster_id = request.POST.get('cluster_id')
    response_data = {}
    softs = []
    if not cluster_id:
        response_data['code'] = '1'
        response_data['data'] = 'cluster_id is empty ' 
        return HttpResponse(json.dumps(response_data),content_type="application/json")    

    tmp = cluster_id.split('-')
    env_id = int(tmp[0])
    service_id = int(tmp[1])
    idc_id = int(tmp[2])
    
    units = Unit.objects.select_related().filter(env_id = env_id,service_id = service_id,idc_id = idc_id)
    for unit in units:
        softs.append(dict(id=unit.soft.id, name=unit.soft.name))
    return HttpResponse(json.dumps(softs),content_type="application/json")
    
def ajax_cluster_get_inventory(request):
    
    cluster_id = request.POST.get('cluster_id')
    component_id = request.POST.get('component_id')
    
    response_data = {}
    if not cluster_id or not component_id:
        response_data['code'] = '1'
        response_data['data'] = 'cluster_id or component_id is empty ' 
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    tmp = cluster_id.split('-')
    env_id = int(tmp[0])
    service_id = int(tmp[1])
    idc_id = int(tmp[2])
    
    if not Env.objects.filter(id = env_id) or not Service.objects.filter(id=service_id) or not Idc.objects.filter(id=idc_id):
        response_data['code'] = '2'
        response_data['data'] = 'invalid env_id ' + env_id + " or service_id " + service_id + " or idc_id " + idc_id
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    if int(component_id) == -1:
        units = Unit.objects.select_related().filter(env_id = env_id,service_id = service_id,idc_id = idc_id)
    else:
        units = Unit.objects.select_related().filter(env_id = env_id,service_id = service_id,idc_id = idc_id,soft_id=component_id)
    
    content = create_ansible_inventory_content_from_cluster(units)
    response_data['code'] = '0'
    response_data['data'] = content
    return HttpResponse(json.dumps(response_data),content_type="application/json")
    


