#coding:utf-8
from django.shortcuts import render
from cmdb.models import Server, Service, Product, Env, Idc, Unit, Soft, Service
from deploy.models import PlayBook, PlayLog
import json
from django.http.response import HttpResponse
from cmdb.utils.clusterutils import get_clusters_by_productid
from deploy.utils.ansibleutils import write_ansible_job_from_invandpb,\
    create_ansible_inventory_content_from_cluster,\
    create_ansible_inventory_content_from_unit

import requests
from deploy.config import ConfigUrls
# Create your views here.
def deploy_init(request,nav):
    
    return render(request,'',locals())

def deploy_cluster(request,nav):
    
    return render(request,'',locals())

def common_init(request,template_name):
    
    products = Product.objects.all()
    
    playbooks = PlayBook.objects.all()
    
    playlogs = PlayLog.objects.select_related().all().order_by('-created_at')[:10]
    
    return render(request,template_name,locals())

def ajax_get_servers_inproduct(request):
    
    response_data = {}
    
    product_id = request.POST.get('product_id')
    
    if not product_id:
        response_data['code'] = '1'
        response_data['data'] = 'product id empty'
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    if not Product.objects.filter(id=product_id):
        response_data['code'] = '2'
        response_data['data'] = 'product id ' + product_id + 'not exist'
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    response_data['code'] = '0'
    response_data['data'] = []
    servers = Server.objects.filter(product_id = product_id)
    for server in servers:
        response_data['data'].append({'id':server.id,'eth0':server.eth0})
        
    return HttpResponse(json.dumps(response_data),content_type="application/json")


    
def ajax_common_init_receiver(request):
    ''' 1. get serverids playbook_id 
        2. make inventory_content
        3. write_ansible_job_from_invandpb(inventory_content, mirror_content, playbook,user_id)
    '''
    
    response_data = {}
    #1.
    server_ids = request.POST.get('server_ids')
    if not server_ids:
        response_data['status'] = 'failed'
        response_data['msg'] = "u select no servers"
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    playbook_id = request.POST.get('playbook_id')
    if not PlayBook.objects.filter(id = playbook_id):
        response_data['status'] = 'failed'
        response_data['msg'] = "invalid playbook_id"
        return HttpResponse(json.dumps(response_data),content_type="application/json")        
    playbook = PlayBook.objects.get(id = playbook_id)
    
    #2.
    serverids = server_ids.split("##")
    servers = Server.objects.select_related().filter(id__in = serverids)
    server_ips = []
    inventory_content = ''
    for server in servers:
        inventory_content += server.eth0 + ' idc=' + server.idc.name +'\n'
        server_ips.append(server.eth0)
    inventory_content = inventory_content.strip('\n')
    user_id = request.user.id
    
    #3.
    response_data = write_ansible_job_from_invandpb(inventory_content, '', playbook,user_id)

    return HttpResponse(json.dumps(response_data),content_type="application/json")

def cluster_predeploy(request,template_name):
    
    product_id = request.GET.get('product_id')
    clusters,empty_clusters = get_clusters_by_productid(product_id=product_id)
    
    
    playbooks = PlayBook.objects.all()   
    playlogs = PlayLog.objects.select_related().all().order_by('-created_at')[:10]
    
    
    return render(request,template_name,locals())

    
def ajax_cluster_prodeploy_receiver(request):
    
    cluster_id = request.POST.get('cluster_id')
    playbook_id = request.POST.get('playbook_id')
    component_id = request.POST.get('component_id')
    
    response_data ={}
        
    if not cluster_id:
        response_data['code'] = '1'
        response_data['data'] = 'cluster_id is empty ' 
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    tmp = cluster_id.split('-')
    env_id = int(tmp[0])
    service_id = int(tmp[1])
    idc_id = int(tmp[2])
    
    if not Env.objects.filter(id = env_id) or not Service.objects.filter(id=service_id) or not Idc.objects.filter(id=idc_id):
        response_data['code'] = '2'
        response_data['data'] = 'invalid env_id ' + env_id + " or service_id " + service_id + " or idc_id " + idc_id
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    if int(component_id) == -1:
        units = Unit.objects.select_related().filter(env_id = env_id,service_id = service_id,idc_id = idc_id)
    else:
        units = Unit.objects.select_related().filter(env_id = env_id,service_id = service_id,idc_id = idc_id,soft_id=component_id)
    
    content = create_ansible_inventory_content_from_cluster(units)
    if len(units) == 1:
        mirror_content = create_ansible_inventory_content_from_unit(units[0],'mirror')
        

    playbook = PlayBook.objects.get(id = playbook_id)
    user_id = request.user.id
    
    response_data = write_ansible_job_from_invandpb(content, mirror_content, playbook, user_id)
    
    return HttpResponse(json.dumps(response_data),content_type="application/json")


def InitPlaybook(request,template_name):
    if request.method == 'GET':
        envs = Env.objects.all()
        idcs = Idc.objects.all()
        apps = Service.objects.all()
        services = Soft.objects.all()

        return render(request,template_name,locals())
    elif request.method == 'POST':
        deep = request.POST.get('deep')
        envs = ','.join(request.POST.getlist('envs'))
        idcs = ','.join(request.POST.getlist('idcs'))
        apps = ','.join(request.POST.getlist('apps'))
        services = ','.join(request.POST.getlist('services'))
        viewType = 1

        payload = {'viewType':viewType,'deep':deep,'env':envs,'idc':idcs,'app':apps,'service':services,'viewType':viewType}
        response_data = requests.get(ConfigUrls['getAllEnableIP'],params=payload).json()
        #return HttpResponse(json.dumps(response_data))
        return render(request,'deploy/playbook/inventory.html',locals())