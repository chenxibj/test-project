#coding:utf-8
from pga.utils.fileutils import getDictFromYamlFile
import json
from django.http.response import HttpResponse
from deploy.utils.ansibleutils import getOsEnvFromPlaybook,\
    getOsEnvDictFromPlaybook, getOsEnvDictByItems, getIaasBaseEnvDictByItems
from cmdb.models import Env, Idc
from cmdb.utils.clusterutils import getEnvIdcDict
from deploy.utils.chefUtils import getChefEnv

def getOpenstackEnv(request):
    
    response_data = getOsEnvFromPlaybook()
    
    return HttpResponse(json.dumps(response_data, indent=4, sort_keys=False),content_type="application/json")
    
def getOpenstackEnvDict(request):
    
    items = request.GET.get("items")
    
    if not items or items == '':
        response_data = getOsEnvDictFromPlaybook()
    else:
        response_data = getOsEnvDictByItems(items)

    return HttpResponse(json.dumps(response_data, indent=4, sort_keys=False),content_type="application/json")


def getIaasBaseEnvDict(request):
    
    items = request.GET.get("items")
    response_data = getIaasBaseEnvDictByItems(items)

    return HttpResponse(json.dumps(response_data, indent=4, sort_keys=False),content_type="application/json")

def getChefEnvDict(request):
    
    r = {}
    d = getEnvIdcDict()
    for env,idcs in d.items():
        for idc in idcs:
            j = getChefEnv(env, idc)
            if j:
                if not r.has_key(env):
                    r[env] = {}
                r[env][idc] = j

    return HttpResponse(json.dumps(r, indent=4, sort_keys=False),content_type="application/json")        
           
        
    
    
    