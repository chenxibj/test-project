#coding:utf-8
from deploy.models import PlayLog
from pga.utils.fileutils import get_content_from_file, create_link,\
    write_file_from_content
from pga.settings import PLAYBOOK_TMP_DIR
import json
from django.http.response import HttpResponse

def ajax_get_playlog_byuuid(request):
    '''return code: 0. succeed; 1. file not exist; 2. io exception; 3. db error'''
    playlog_uuid = request.POST.get('playlog_uuid')
    response_data = {}
    
    if not PlayLog.objects.filter(uuid = playlog_uuid):
        response_data['code'] = '3'
        response_data['data'] = 'invalid playlog_uuid ' + playlog_uuid 
        return HttpResponse(json.dumps(response_data),content_type="application/json")
    
    dirname = playlog_uuid
    ansible_path = PLAYBOOK_TMP_DIR + dirname + '/'
    job_path = PLAYBOOK_TMP_DIR + 'run/'
    
    create_link(ansible_path,job_path)
    mirror_path = job_path + 'inventory-mirror'
    inventory_path = job_path + 'inventory'
    playbook_path = job_path + 'playbook.yaml'
    concurrent_path = job_path + 'concurrent'
    param_path = job_path + 'param'
    
    response_data['code'] = '0'
    response_data['mirror'] = get_content_from_file(mirror_path)
    response_data['inventory'] = get_content_from_file(inventory_path)
    response_data['playbook'] = get_content_from_file(playbook_path)
    response_data['concurrent'] = get_content_from_file(concurrent_path)
    response_data['param'] = get_content_from_file(param_path)
    
    return HttpResponse(json.dumps(response_data),content_type="application/json")
    
def ajax_deploy_setup_concurrent(request):
    concurrent = request.POST.get('concurrent')
    if not concurrent:
        concurrent = 5
    file_path = PLAYBOOK_TMP_DIR + 'run/concurrent'
    json_data = write_file_from_content(file_path,concurrent)
    return HttpResponse(json.dumps(json_data),content_type="application/json")


