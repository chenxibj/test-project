from django.contrib import admin
from deploy.models import PlayBook, PlayLog

# Register your models here.
class PlayBookAdmin(admin.ModelAdmin):
    list_display = ('name','description','path','param','created_at')
    
admin.site.register(PlayBook, PlayBookAdmin)

class PlayLogAdmin(admin.ModelAdmin):
    list_display = ('uuid','playbook','user','created_at')
    
admin.site.register(PlayLog, PlayLogAdmin)