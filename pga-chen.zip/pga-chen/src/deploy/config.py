#encoding=utf-8

default_internal_vars = ["idc","eth0","eth1","eth1gateway","domain","domain_status","rack","serverModule"]

ConfigUrls = {'getAllEnableIP':'http://pga.iaas.jd.com/getAllEnableIP/'}