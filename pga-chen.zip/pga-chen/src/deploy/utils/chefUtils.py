#encoding=utf8
import os
'''
Created on 2016年12月26日

@author: madongdong1
'''
from pga.utils.fileutils import getDictFromJsonFile

def getChefEnv(env,idc):
    
    chefEnvPath = '/export/Shell/chef/environments'
    filePath = ('%s/%s_%s.json' % (chefEnvPath, env, idc) )
    print filePath
    if os.path.exists(filePath) and os.path.isfile(filePath): 
        j = getDictFromJsonFile(filePath)
    else:
        j = {}
    return j