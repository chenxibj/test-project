import os
import shutil
from pga.settings import PLAYBOOK_TMP_DIR, PLAYBOOK_DIR
import datetime
import uuid
from deploy.models import PlayLog
from pga.utils.fileutils import write_file_from_content, getDictFromYamlFile
import json
from deploy.config import default_internal_vars
from pga.decorators.toogles import toogle_json

def write_ansible_job_from_invandpb(inventory_content, mirror_content, playbook,user_id):
    
    json_data = {}
    
    if not playbook.path or playbook.path == '' :
        json_data['code'] = '1'
        json_data['data'] = 'playbook.path is empty'
        return json_data
    
    write_file_from_content(PLAYBOOK_DIR + "param", playbook.param)
    
    #generate playlog_uuid
    dt = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    playlog_uuid = str(uuid.uuid5(uuid.NAMESPACE_DNS, (playbook.path + dt).encode('utf-8')))
        
    try:
        os.mkdir(PLAYBOOK_TMP_DIR + playlog_uuid)
        playbook_job_path = PLAYBOOK_TMP_DIR + playlog_uuid + '/'
        #generate playbook file
        if playbook.path.startswith('/'):
            playbook_file = playbook.path
        else:
            playbook_file = PLAYBOOK_DIR + playbook.path
        shutil.copyfile(playbook_file , playbook_job_path + "playbook.yaml")   
        shutil.copyfile(PLAYBOOK_DIR + "test.yaml" , playbook_job_path + "test.yaml")
        shutil.copyfile(PLAYBOOK_DIR + "testRole.yaml" , playbook_job_path + "testRole.yaml")
        #shutil.copyfile(PLAYBOOK_DIR + "inventory-mirror" , playbook_job_path + "inventory-mirror")
        shutil.copyfile(PLAYBOOK_DIR + "concurrent" , playbook_job_path + "concurrent")
        shutil.copyfile(PLAYBOOK_DIR + "param" , playbook_job_path + "param")
        #generate mirror file
        mirror_path = playbook_job_path + 'inventory-mirror'
        write_file_from_content(mirror_path, mirror_content) 
        #generate inventory file
        inventory_path = playbook_job_path + 'inventory'
        json_data = write_file_from_content(inventory_path, inventory_content)           

        #if write inventory succeed save playlog into db
        if json_data['code'] == '0':
            pl = PlayLog(uuid=playlog_uuid, playbook_id=playbook.id,user_id=user_id, created_at = dt)
            pl.save()
    except:
        json_data = {"code":"2","data":"open or write file failed"}
    finally:
        return json_data
 
 
def create_ansible_inventory_content_from_cluster(units):
    
    content = ''
    for unit in units:
        content += create_ansible_inventory_content_from_unit(unit)
        content += '\n'
    content = content.strip('\n')
    return content   
    
def create_ansible_inventory_content_from_unit(unit, mirror = False):
    
    divs = default_internal_vars
    
    content = '[' + unit.soft.name + ']\n'
    server_objs = unit.serverinunit_set.all()
    content += (('### softid: %s; server number: %s ###\n') % (unit.soft.id, len(server_objs)))
    
    unit_var_str = ''
    internal_vars = ''
    unit_var_str += " env=" + str(unit.env.name)
    if unit.vars:   
        try:
            unit_vars = json.loads(unit.vars)
            if isinstance(unit_vars,dict):
                for i, v in unit_vars.items():
                    if str(i) == 'internal_vars':
                        internal_vars = v
                    else:
                        unit_var_str += " "+ str(i) + "=" + str(v)
        except:
            pass
        
    for server_obj in server_objs:
        content += server_obj.server.eth0

        if server_obj.vars:
            try:
                server_vars = json.loads(server_obj.vars)
                if isinstance(server_vars,dict):
                    for i in server_vars:
                        content += " "+ str(i) + "=" + str(server_vars[i])                       
            except: 
                pass
            
        if internal_vars:
            for internal_var in internal_vars:
                if internal_var in divs:
                    continue
                if hasattr(server_obj.server,internal_var):
                    v = getattr(server_obj.server,internal_var)
                    content += " " + str(internal_var) +"=" + str(v)
        
        for div in divs:
            if hasattr(server_obj.server,div):
                v = getattr(server_obj.server,div)
                content += " " + str(div) +"=" + str(v)     
                       
        content += unit_var_str
        content += " service=" + unit.service.name
        content += '\n'
        if mirror:
            break
        
    content = content.strip('\n')
    return content       

@toogle_json('osenvapi')
def getOsEnvFromPlaybook(toogle=True):
    
    envFile = '/export/Shell/cloud-op/playbooks/openstack-deploy/environments/openstack.yml'
    j = getDictFromYamlFile(envFile)
    return j

def getIaasBaseEnvFromPlaybook():
    
    envFile = '/export/Shell/cloud-op/playbooks/roles/iaasBaseInit/defaults/main.yaml'
    j = getDictFromYamlFile(envFile)
    return j    

def getOsEnvDictFromPlaybook():
    
    j = getOsEnvFromPlaybook()
    k = {}
    for env, envObj in j["env_vars"].items():
        if not k.has_key(env):
            k[env] = []
        for idc, idcObj in envObj.items():
            k[env].append(idc)
    return k

def getOsEnvDictByItems(items):
    
    items = items.strip().split(',')
    
    j = getOsEnvFromPlaybook()
    k = {}
    for env, envObj in j["env_vars"].items():
        if not k.has_key(env):
            k[env] = {}
        for idc, idcObj in envObj.items():
            if not k[env].has_key(idc):
                k[env][idc] = {}
            for item in items:
                if idcObj.has_key(item):
                    k[env][idc][item] = idcObj[item]
            
    return k    
    
def getIaasBaseEnvDictByItems(items):
    
    items = items.strip().split(',')
    
    j = getIaasBaseEnvFromPlaybook()
    k = {}
    for env, envObj in j["env_vars"].items():
        if not k.has_key(env):
            k[env] = {}
        for idc, idcObj in envObj.items():
            if not k[env].has_key(idc):
                k[env][idc] = {}
            for item in items:
                if idcObj.has_key(item):
                    k[env][idc][item] = idcObj[item]
            
    return k     
    
    
    