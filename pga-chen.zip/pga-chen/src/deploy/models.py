#coding:utf-8
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class PlayBook(models.Model):
    ''' playbook  隶属于deploy '''
    name = models.CharField(unique=True, max_length=50)
    description = models.CharField(max_length=100)
    path = models.CharField(max_length=300)
    param = models.CharField(blank=True, null=True, max_length=300)
    created_at = models.DateTimeField(blank=True, null=True)
    remark1 = models.CharField(blank=True, null=True,max_length=100)
    remark2 = models.CharField(blank=True, null=True,max_length=100)
    remark3 = models.CharField(blank=True, null=True,max_length=100) 
    
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)
    
    def __unicode__(self):
        return self.name
    
class PlayLog(models.Model):
    uuid = models.CharField(unique=True, max_length=36)
    playbook = models.ForeignKey(PlayBook)
    user = models.ForeignKey(User)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    
    