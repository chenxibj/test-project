from django.apps import AppConfig


class Dj1Config(AppConfig):
    name = 'account'
