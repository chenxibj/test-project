#coding:utf-8
#from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.contrib.auth import authenticate
from django.contrib import auth
from django.http.response import HttpResponseRedirect

def login(request,template_name):
    
    return render(request,template_name)

def check_login(request):
    
    if request.method == 'GET':  
        return HttpResponseRedirect('/account/login')
    else:
        username = request.POST.get('username', '')  
        password = request.POST.get('password', '')  
        user = authenticate(username=username, password=password)  
        if user is not None :
            auth.login(request,user)
            return HttpResponseRedirect('/')
        else:
            return HttpResponseRedirect('/account/login')
        
def logout(request):    
    # auth.logout(request)
    # return HttpResponseRedirect('/account/login')
    logout_url = 'http://ssa.jd.com/sso/logout?ReturnUrl=http://pga.iaas.jd.com/'
    auth.logout(request)
    response = HttpResponseRedirect(logout_url)
    return response

@login_required      
def index(request,template_name):
    
    return render(request,template_name)

