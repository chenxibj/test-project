#!/bin/bash

if [ "x$1" = "x--help" ]
then
    echo "Usage: "
    echo "      ./start -p port to listen on"
    echo "      ./start    use default port 80"
fi

PORT=8080

x=$1
case $x in
  -p*) 
    temp=${x:2}
    if [ "" == "$temp" ]
    then
      echo "Please input your port number."
      exit 
    else
      PORT=$temp
    fi
  ;;
esac

isValid=`echo $PORT | grep "^[0-9]*$" | wc -l`

if [ $isValid == 0 ]
then
  echo "Please input valid port number."
  exit
fi

PROJDIR=$(pwd)
PIDFILE="$PROJDIR/mysite.pid"
MANAGEFILE="$PROJDIR/manage.py"

cd $PROJDIR
if [ -f $MANAGEFILE ]
then
    if [ -f $PIDFILE ]; then
       kill `cat -- $PIDFILE`
       rm -f -- $PIDFILE
    fi

    python manage.py runserver 0.0.0.0:$PORT

    echo "Program has been started."
else
  echo "Can't find manage.py."
  exit
fi



