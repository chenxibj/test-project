import keystoneclient.v2_0.client as ksclient
import novaclient.client as nvclient
from pga.settings import OPENSTACK_USER
from _mysql import NULL
from cmdb.models import Soft
import json

def testt():
    keystone = ksclient.Client(**OPENSTACK_USER['ks_hc_admin'])
    nova = nvclient.Client("2.0",**OPENSTACK_USER['nv_hc_admin'])
    
    print vars(nova)
    
    print "-----------------"
    return nova.hosts.list()

def get_all_servers_in_tenant(username):
    
    if not username or not OPENSTACK_USER[username]:
        return NULL
    nova = nvclient.Client("2.0",**OPENSTACK_USER[username])
    
    return nova.servers.list()


def print_server(server):
    print("-"*35)
    print("server id: %s" % server.id)
    print("server name: %s" % server.name)
    print("server image: %s" % server.image)
    print("server flavor: %s" % server.flavor)
    print("server key name: %s" % server.key_name)
    print("user_id: %s" % server.user_id)
    print("-"*35)
    
def get_logs_by_softid(soft_id):
    
    soft = Soft.objects.get(id=soft_id)
    if not soft:
        return []
    
    process_vars = soft.process_vars
    try:
        processes = json.loads(process_vars) 
        logs = []
        for process in processes:
            for log in process["logs"]:
                logs.append({"path":log,"name":process["name"]})
        return logs
    except:
        return []