# -*- coding: utf8 -*-

#@login_required
def menu(request) :
    ''' supermenu! '''
    # hehe
    
    superMenus = []
    
    if (request.user.has_perm('cmdb.show_cmdb')) :
        menus = []
        submenus = []
        # cmdb
        if (request.user.has_perm('cmdb.show_cmdb_servers')) :
            items = []
            if (request.user.has_perm('cmdb.show_cmdb_servers_show_project')) :
                items.append({'link' : '/cmdb/server/listall/', 'text' : '服务器列表'})
                items.append({'link' : '/cmdb/server/listall/?nullPoll=1', 'text' : '无归属服务器列表'})
            submenus.append({'title' : 'servers', 'categorylink' : '/cmdb/server/', 'items' : items})
        
        if (request.user.has_perm('cmdb.show_cmdb_service')) :
            items = []            
            if (request.user.has_perm('cmdb.show_cmdb_service_add_project')) :
                items.append({'link' : '/cmdb/service/service_tree/?product_id=2', 'text' : '服务树-IaaS'})
            if (request.user.has_perm('cmdb.show_cmdb_service_add_project')) :
                items.append({'link' : '/cmdb/service/service_tree/?product_id=4', 'text' : '服务树-PaaS'})
            if (request.user.has_perm('cmdb.show_cmdb_service_show_project')) :
                items.append({'link' : '/cmdb/service/service_listsofts/', 'text' : '软件归属'})
            submenus.append({'title' : 'services', 'categorylink' : '/cmdb/service/', 'items' : items})
        
        if (request.user.has_perm('cmdb.show_cmdb_QuickQuery')) :
            items = []
            if (request.user.has_perm('cmdb.show_cmdb_QuickQuery_show_project')) :
                items.append({'link' : '/cmdb/api/getServerInfoByEth0/?ip=', 'text' : 'ip查找'})
                items.append({'link' : '/cmdb/server/mGetServerInfoByEth0/', 'text' : 'ip批量查找'})
            submenus.append({'title' : '速查', 'categorylink' : '/openstack/components/', 'items' : items})
    
        menus.append({'title' : 'cmdb', 'category' : 'menu', 'categorylink' : '/cmdb', 'submenus' : submenus,})
        superMenus.append({'category' : 'cmdb', 'categorylink' : '/cmdb', 'menus' : menus})
        
    if (request.user.has_perm('cmdb.show_deploy')) :
        menus = []
        submenus = []
        #  
        if (request.user.has_perm('cmdb.show_deploy_common')) :
            items = []
            if (request.user.has_perm('cmdb.show_deploy_common_show_project')) :
                items.append({'link' : '/deploy/common/init/', 'text' : '初始化环境'})
            if (request.user.has_perm('cmdb.show_deploy_common_show_project')) :
                items.append({'link' : '/deploy/playbook/init/', 'text' : 'inventory'})
            submenus.append({'title' : 'common', 'categorylink' : '/openstack/overview/', 'items' : items})

        #  
        if (request.user.has_perm('cmdb.show_deploy_cluster')) :
            items = []
            if (request.user.has_perm('cmdb.show_deploy_cluster_show_project')) :
                items.append({'link' : '/deploy/cluster/predeploy/?product_id=2', 'text' : '集群部署-IaaS'})
            if (request.user.has_perm('cmdb.show_deploy_cluster_show_project')) :
                items.append({'link' : '/deploy/cluster/predeploy/?product_id=4', 'text' : '集群部署-PaaS'})
            submenus.append({'title' : 'cluster', 'categorylink' : '/openstack/components/', 'items' : items})
        
        menus.append({'title' : 'deploy-开发中','cateegory' : 'openstack', 'categorylink' : '/openstack/', 'submenus' : submenus,})
        superMenus.append({'category' : 'deploy', 'cdeploylink' : '/absible/', 'menus' : menus})
        
    if (request.user.has_perm('cmdb.show_dev')) :
        menus = []
        submenus = []
        #  
        if (request.user.has_perm('cmdb.show_dev_dev')) :
            items = []
            if (request.user.has_perm('cmdb.show_dev_dev_show_project')) :
                items.append({'link' : '/dev/', 'text' : 'dev'})
            submenus.append({'title' : 'dev', 'categorylink' : '/openstack/overview/', 'items' : items})
        
        menus.append({'title' : 'dev','cateegory' : 'openstack', 'categorylink' : '/openstack/', 'submenus' : submenus,})
        superMenus.append({'category' : 'dev', 'cdeploylink' : '/absible/', 'menus' : menus})   
            
    return {'superMenus' : superMenus}
