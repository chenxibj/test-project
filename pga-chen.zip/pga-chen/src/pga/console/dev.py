from cmdb.utils.clusterutils import get_clusters_by_productid
from pga.utils.fileutils import get_content_from_file
from django.http.response import HttpResponse
import json
from pga.settings import BASE_DIR
#from tmp.trush.openstackutils import testt, print_server, get_logs_by_softid
from cmdb.models import ProductForm, Soft
from django.shortcuts import render
from pga.utils.zbxapiutils import zbxapi_get_token, getHostGroupId_by_groupname,\
    getHosts_by_groupid



def dev(request):

    ''' some test code below to print result'''
    print 'result:\n'
    
    
    
    
    #token = zbxapi_get_token()
    #group = getHostGroupId_by_groupname(token,groupname="Zabbix servers")
    #hosts = getHosts_by_groupid(token,groupid=group['result'][0]['groupid'])
    #getHostGroups("IaaS_gz",token)
    
    #print hosts
    #return render(request,'dev/product.html')
    return HttpResponse("11")
def dev_form(request):
    
    if request.method == "POST" and request.is_ajax:
        form = ProductForm(request.POST)        
        print request.POST
        if form.is_valid():
            return HttpResponse('duang')
    else:
        form = ProductForm()
    
    return render(request,'dev/ajax_form.html',{'form':form})
    
    '''
    servers = testt()

    for server in servers:
        
        print vars(server)
    #    print_server(server)
    #    print server.addresses
    #    for subnets in server.addresses:
    #        print server.addresses[subnets]
    '''
    '''
    items = get_clusters_by_productid(by=['idc'],product_id=2)
    for item in items:
        print item.name+'------'
        for cluster in item.clusters:
            print '    '+cluster['name']
            for unit in cluster['units']:
                print '        '+unit.name
    
    print '--------------'
    '''
    
    ''' #test of create cluster
    clusters = get_clusters_by_productid()
    for cluster in clusters:
        if cluster['units'] != []:
            print cluster['name']+'----------'
            for unit in cluster['units']:
                print '    ' + unit.name
                for server in unit.servers:
                    print '        ' + server.eth0
    '''
    
    ''' #test of select_related
    services = Service.objects.select_related().all()
    for service in services:
        
        print service.softinservice_set.all().first().soft.name
        print service.unit_set.all().first().name
        print service.product.platform
    '''
    
    ''' some test code below to html '''
    '''
    json_data = get_content_from_file(BASE_DIR + '/tmp/test.txt')
    if json_data['code'] != '0':
        return HttpResponse(json.dumps(json_data))
    content_lines = json_data['data']
    print(content_lines)
    content =''
    for content_line in content_lines:
        content += content_line.replace('\n','<br>')
    

    
    return HttpResponse(content)
    '''