"""pga URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/dev/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Import the include() function: from django.conf.urls import url, include
    3. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf import settings
from django.conf.urls import   include,  url
from django.contrib import admin
from pga.console.dev import dev, dev_form
from cmdb.views.searchviews import ajax_search_servers
from logview.views import log_view, ajax_create_tty_log
from monitor.views import monitor_config, ajax_monitor_add, ajax_monitor_edit,\
    ajax_monitor_del, ajax_create_zbxhosts
from cmdb.views.api import listClusters, listSofts, getClusterServers,\
    getServerInfoByEth0, getRackInfoByEth0, getAllUnitServers, getAllUnits, getAllSofts,\
    getServerDictByServiceSoft, getProcessvars, listServices, listSoftsByService,\
    getClusterByService
from deploy.views.api import getOpenstackEnv, getOpenstackEnvDict,\
    getIaasBaseEnvDict, getChefEnvDict
from cmdb.views.api import GetAllEnableIP
from chefapi.views.api import getChefVars, getMonitor, getAllMonitor,\
    getServerModules, getUnderlayNetworkingConf, getDb, getAllAssists

admin.autodiscover()

from account.views import check_login, index, logout, login

from cmdb.views.serverviews import server_listallservers, MyView,ajaxMulitOperateUnitServers,\
    mGetServerInfo, ajaxMassUpdateServers

from cmdb.views.serverviews import ajax_service_addUnits, ajax_service_unitAddServers, service_listSofts, service_listProductServices  
from cmdb.views.serverviews import service_listClusterUnits 

from cmdb.views.tree_modifyviews import tree_modify, ajax_get_treenode,\
    ajax_update_vdr
from cmdb.views.tree_modifyviews import ajax_platform_add, ajax_platform_edit, ajax_platform_del

from deploy.views.deployviews import ajax_common_init_receiver, ajax_get_servers_inproduct,  ajax_cluster_prodeploy_receiver  
from deploy.views.deployviews import common_init, cluster_predeploy,deploy_init, deploy_cluster,InitPlaybook

from deploy.views.playbookviews import ajax_get_playbook_content, ajax_cluster_get_inventory,\
    ajax_get_components
from deploy.views.playlogviews import ajax_get_playlog_byuuid,\
    ajax_deploy_setup_concurrent

urlpatterns = [
    
    url(r'^admin/', include(admin.site.urls)),
    
    url(r'^account/login/$', login, {'template_name': 'login.html'},name='login'),    
    url(r'^account/check_login/$', check_login, name='check_login'),
    url(r'^$',index,{'template_name': 'base.html'},name='index'),
    url(r'^account/logout/$',logout,name='logout'),
    
    
    url(r'^cmdb/server/listall/$',server_listallservers,{'template_name': 'cmdb/server/server_list.html', 'nav':'cmdb'},name ='cmdb_serverlistall'),
    
    url(r'^cmdb/server/new_listall/$',server_listallservers,{'template_name': 'cmdb/server/new_server_list.html', 'nav':'new_serverlist' },name ='new_serverlist'),
    url(r'^cmdb/server/mGetServerInfoByEth0/$',mGetServerInfo,{'template_name': 'cmdb/server/mGetServerInfo.html', 'nav':'cmdb' },name ='mGetServerInfo'),
    

    url(r'^cmdb/service/ajax_gettreenode/$',ajax_get_treenode),
    url(r'^cmdb/api/listclusters/$',listClusters),
    url(r'^trustedapi/cmdb/api/listServices/$',listServices),
    url(r'^cmdb/api/listsofts/$',listSofts),
    url(r'^trustedapi/cmdb/api/listSoftsByService/$',listSoftsByService),
    url(r'^trustedapi/cmdb/api/getClusterByService/$',getClusterByService),
    url(r'^cmdb/api/getclusterservers/$',getClusterServers, name = 'getclusterservers'),
    url(r'^cmdb/api/getServerInfoByEth0/$', getServerInfoByEth0),
    url(r'^cmdb/api/getRackInfoByEth0/$', getRackInfoByEth0),
    url(r'^cmdb/api/getAllUnitServers/$', getAllUnitServers),
    url(r'^cmdb/api/getAllUnits/$', getAllUnits),
    url(r'^cmdb/api/getAllSofts/$', getAllSofts),
    url(r'^cmdb/api/getServerDictByServiceSoft/$', getServerDictByServiceSoft),
    
    url(r'^deploy/api/getosenv/$',getOpenstackEnv),
    url(r'^deploy/api/getosenvdict/$',getOpenstackEnvDict),
    url(r'^deploy/api/getiaasbaseenvdict/$',getIaasBaseEnvDict),
    url(r'^deploy/api/getChefEnvDict/$',getChefEnvDict),
     
    url(r'^cmdb/tree_modify/$',tree_modify,{'nav':'tree_modify' },name='tree_modify'),
    url(r'^cmdb/tree_modify/ajax_platform_add/$',ajax_platform_add,name="ajax_platform_add"),
    url(r'^cmdb/tree_modify/ajax_platform_edit/$',ajax_platform_edit,name="ajax_platform_edit"),
    url(r'^cmdb/tree_modify/ajax_platform_del/$',ajax_platform_del,name="ajax_platform_del"),
    
    url(r'^cmdb/search/ajax_search_servers/$',ajax_search_servers,name="ajax_search_servers"),
    
    url(r'^cmdb/service/ajax_addunit/$',ajax_service_addUnits),
    url(r'^cmdb/service/ajax_unitaddserver/$',ajax_service_unitAddServers),
    url(r'^cmdb/service/ajax_mulitoperate_serverinunit/$',ajaxMulitOperateUnitServers),
    url(r'^cmdb/service/ajax_update_vdr/$',ajax_update_vdr),
    url(r'^trustedapi/cmdb/service/ajaxMassupdateServers/$',ajaxMassUpdateServers),
    
    url(r'^deploy/deploy_init/$',deploy_init,{'nav':'deploy_init' },name='deploy_init'),
    url(r'^deploy/deploy_cluster/$',deploy_cluster,{'nav':'deploy_cluster' },name='deploy_cluster'),
    
    #url(r'^cmdb/server/cluster_details/$',server_cluster,{'template_name': 'cmdb/server/cluster_details.html' },name ='cmdb_clusterdetails'),
    #url(r'^cmdb/server/product_add_server/$',server_product_add_server,{'template_name': 'cmdb/server/product_add_server.html' },name ='cmdb_product_add_server'),
    #url(r'^cmdb/server/ajax_product_add_server/$',ajax_server_product_add_server),
    #url(r'^cmdb/server/ajax_cluster_del_server/$',ajax_server_cluster_del_server),
    #url(r'^cmdb/server/ajax_component_add_server/$',ajax_server_component_add_server),
    #url(r'^cmdb/server/ajax_component_del_server/$',ajax_server_component_del_server),
    
    url(r'^cmdb/service/service_tree/$',service_listProductServices,{'template_name': 'cmdb/service/service_tree.html' },name ='service_tree'),
    url(r'^cmdb/service/service_listsofts/$',service_listSofts,{'template_name': 'cmdb/service/soft_tree.html' },name ='soft_tree'),
    url(r'^cmdb/service/cluster_details/$',service_listClusterUnits,{'template_name': 'cmdb/service/cluster_details.html' },name ='cluster_details'),    
    url(r'^cmdb/service/new_service_tree/$',service_listProductServices,{'template_name': 'cmdb/service/new_service_tree.html' },name ='new_service_tree'),
    url(r'^trustedapi/cmdb/getProcessvars/$',getProcessvars), 
    
    url(r'^deploy/common/init/$',common_init,{'template_name': 'deploy/common/init.html' },name ='deploy_commoninit'),
    url(r'^deploy/common/ajax_servers_inproduct/$',ajax_get_servers_inproduct),
    url(r'^deploy/common/ajax_init_receiver/$',ajax_common_init_receiver),
    
    url(r'^deploy/common/ajax_get_playbook_content/$',ajax_get_playbook_content),
    url(r'^deploy/common/ajax_get_playlog_byuuid/$',ajax_get_playlog_byuuid),
    
    url(r'^deploy/cluster/predeploy/$',cluster_predeploy,{'template_name': 'deploy/cluster/predeploy.html' },name ='deploy_clusterpredeploy'),
    url(r'^deploy/cluster/ajax_get_components/$',ajax_get_components),
    url(r'^deploy/cluster/ajax_get_cluster_inventory/$',ajax_cluster_get_inventory),
    url(r'^deploy/cluster/ajax_predeploy_receiver/$',ajax_cluster_prodeploy_receiver),
    url(r'^deploy/playlog/ajax_setup_concurrent/$',ajax_deploy_setup_concurrent),
 
    url(r'^log/log_view/$',log_view,{'template_name': 'log/log_view.html','nav':'log_view' },name ='log_view'), 
    url(r'^log/ajax_create_tty_log/$',ajax_create_tty_log), 
    
    url(r'^monitor/monitor_config/$',monitor_config,{'nav':'monitor_config' },name='monitor_config'), 
    url(r'^monitor/monitor_config/ajax_monitor_add/$',ajax_monitor_add,name="ajax_monitor_add"),
    url(r'^monitor/monitor_config/ajax_monitor_edit/$',ajax_monitor_edit,name="ajax_monitor_edit"),
    url(r'^monitor/monitor_config/ajax_monitor_del/$',ajax_monitor_del,name="ajax_monitor_del"),
    
    url(r'^monitor/ajax_create_zbxhosts/$',ajax_create_zbxhosts,name="ajax_create_zbxhosts"),
 
    url(r'^openstack/components/one/$', MyView),
    url(r'^dev/$',dev,name ='dev'),
    url(r'^dev_form/$',dev_form,name ='dev_form'),
    url(r'^getAllEnableIP/$',GetAllEnableIP,name='GetAllEnableIP'),
    
    url(r'^chefapi/getChefVars/$',getChefVars), 
    url(r'^trustedapi/chefapi/getMonitor/$',getMonitor), 
    url(r'^trustedapi/chefapi/getAllMonitor/$',getAllMonitor), 
    url(r'^trustedapi/chefapi/getServerModules/$',getServerModules), 
    url(r'^trustedapi/chefapi/getUnderlayNetworkingConf/$',getUnderlayNetworkingConf), 
    url(r'^trustedapi/chefapi/getDb/$',getDb), 
    url(r'^trustedapi/chefapi/getAllAssists/$',getAllAssists),
    url(r'^deploy/playbook/init/$',InitPlaybook,{'template_name': 'deploy/playbook/init_inventory.html'})
]

# if settings.DEBUG:
#     import debug_toolbar
#     urlpatterns += [ url(r'^__debug__/', include(debug_toolbar.urls))]
