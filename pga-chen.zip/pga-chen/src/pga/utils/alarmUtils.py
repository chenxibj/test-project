#-*- coding:utf-8 -*-
import requests

def callSendmail(content, subject, tolist = 'iaas_ops@jd.com', f = 'iaas-info'):
    '''
    sometimes tolist will be added ",sqjiankong@jd.com"
    '''
    postdata = {'from': f, 'tolist':tolist,'subject':subject,'content':content}
    
    r = requests.post('http://mail.iaas.jcloud.com', data=postdata)
    print r.text
    
def sendAlarm(content):
    
    callSendmail(content, 'cmonitor Custom监控')