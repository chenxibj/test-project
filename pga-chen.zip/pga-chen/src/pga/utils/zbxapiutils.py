#coding=utf-8
import json
import urllib2
from urllib2 import URLError
from monitor.models import MonitorService

def zbxapi_handler_byname(zbx_name,data):
    
    if not MonitorService.objects.filter(type='zabbix',name=zbx_name):
        return False
    
    zbxapi = MonitorService.objects.get(type='zabbix',name=zbx_name)
    service_vars = zbxapi.service_vars
    try:
        svars = json.loads(service_vars)
        api_url = svars["api_url"]
    except:
        print u"service_vars : (" + service_vars + u") is not json format"
        return []
    header = {"Content-Type":"application/json"}
    
    request = urllib2.Request(api_url,data)
    for key in header:
        request.add_header(key,header[key])
    # auth and get authid
    try:
        result = urllib2.urlopen(request)
    except URLError as e:
        print "Auth Failed, Please Check Your Name AndPassword:",e
        return []
    finally:
        response = json.loads(result.read())
        result.close()
    return response

def zbxapi_handler(data):
    
    zbxapi = MonitorService.objects.get(type='zabbix',current_monitor=True)
    service_vars = zbxapi.service_vars
    try:
        svars = json.loads(service_vars)
        api_url = svars["api_url"]
    except:
        print u"service_vars : (" + service_vars + u") is not json format"
        return []
    header = {"Content-Type":"application/json"}
    
    request = urllib2.Request(api_url,data)
    for key in header:
        request.add_header(key,header[key])
    # auth and get authid
    try:
        result = urllib2.urlopen(request)
    except URLError as e:
        print "Auth Failed, Please Check Your Name AndPassword:",e
        return []
    finally:
        response = json.loads(result.read())
        result.close()
    return response

def zbxapi_get_token_byname(zbx_name,request_id=0):
    # based url and required header
    if not MonitorService.objects.filter(type='zabbix',name=zbx_name):
        return False 
    
    zbxapi = MonitorService.objects.get(type='zabbix',name=zbx_name)
    sec_vars = zbxapi.sec_vars
    try:
        secvars = json.loads(sec_vars)
        api_user = secvars['api_user']
        api_pass = secvars['api_pass']
        if not api_user or not api_pass:
            return []
    except:
        print u"sec_vars:  is not json format"
        return []
    data = json.dumps(
        {
       "jsonrpc": "2.0",
       "method": "user.login",
       "params": 
            {
            "user": api_user,
            "password": api_pass
            },
        "id": request_id
        }
    )
    
    response = zbxapi_handler(data)
    return response['result']

def zbxapi_get_token(request_id=0):
    # based url and required header
    zbxapi = MonitorService.objects.get(type='zabbix',current_monitor=True)
    sec_vars = zbxapi.sec_vars
    try:
        secvars = json.loads(sec_vars)
        api_user = secvars['api_user']
        api_pass = secvars['api_pass']
        if not api_user or not api_pass:
            return []
    except:
        print u"sec_vars:  is not json format"
        return []
    data = json.dumps(
        {
       "jsonrpc": "2.0",
       "method": "user.login",
       "params": 
            {
            "user": api_user,
            "password": api_pass
            },
        "id": request_id
        }
    )
    
    response = zbxapi_handler(data)
    return response['result']

def getHosts_by_groupid(token, groupid, request_id=0):
    data = json.dumps(
        {
       "jsonrpc": "2.0",
       "method": "host.get",
       "params": 
            {
            "groupids": [groupid],
            "output": ["hostid"],
            "selectInterfaces": ["ip",],
            },                      
       "auth": token,
       "id": request_id
        }
    )
    response = zbxapi_handler(data)
    hosts = []
    for host in response['result']:
        for interface in host['interfaces']:
            ip = interface['ip']
            break
        hostid = host['hostid']
        hosts.append({"ip":ip,"hostid":hostid})
    
    return hosts

def getHostGroupId_by_groupname(token,groupname = "Linux server",request_id=0):
    
    data = json.dumps(
        {
        "jsonrpc": "2.0",
        "method": "hostgroup.get",
        "params": 
            {
            "output": ["groupid"],
            "filter": 
                {
                "name": [groupname]
                }
            },
        "auth": token,
        "id": request_id
        }
    )
    response = zbxapi_handler(data)
    return response

def getHostId_by_hostname(token,hostname,request_id=0):
    
    data = json.dumps(
        {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": 
            {
            "output": ["hostid"],
            "filter": 
                {
                "host": [hostname]
                }
            },
        "auth": token,
        "id": request_id
        }
    )
    response = zbxapi_handler(data)
    if len(response['result']) > 0:
        return response['result'][0]['hostid']
    else:
        return ""

def getTemplateId_by_templatename(token,templatename="Template OS Linux",request_id=0):
    data = json.dumps(
    {
        "jsonrpc": "2.0",
        "method": "template.get",
        "params": {
            "output": ["templateid"],
            "filter": {
                "host": [templatename]
            }
        },
        "auth": token,
        "id": request_id
    }                      
                      
                      
    )
    response = zbxapi_handler(data)
    return response

def createHost(token,groupid,templateid,server,agentType=1,port=10050,request_id=0):    

    # host = server.hostname
    # ip = server.eth0
    host = '%s' % server.server.hostname
    ip = '%s' % server.server
    
    hostid = getHostId_by_hostname(token, host, request_id)

    if hostid:
        print u"hostid: " + hostid + u" already in zabbix, add zbx_hostid to cmdb"
        return hostid
    
    data = json.dumps(
        {
            "jsonrpc": "2.0",
            "method": "host.create",
            "params": {
                "host": host,
                "interfaces": [
                    {
                        "type": agentType,
                        "main": 1,
                        "useip": 1,
                        "ip": ip,
                        "dns": "",
                        "port": port
                    }
                ],
                "groups": [
                    {
                        "groupid": groupid
                    }
                ],
                "templates": [
                    {
                        "templateid": templateid
                    }
                ],
    
            },
            "auth": token,
            "id": request_id
        }
    )
    response = zbxapi_handler_byname('zabbix.bj02',data)
    #print response
    try:
        hostid = response['result']['hostids'][0]
    except:
        hostid = ""
    finally:
        return hostid
    