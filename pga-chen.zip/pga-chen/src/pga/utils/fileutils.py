import os
import yaml
import json

def get_content_from_file(filepath):
    '''
        succeed: return  {"code":"0", "data":[list, of, file, lines, with, \n]}
        failed:  return  {'code':"1|2|3", "msg":"error messages", "data":content  }
        return code: 0. succeed; 1. file not exist; 2. io exception; 3. db error
    '''
    json_data = {}
    if not os.path.isfile(filepath):
        json_data = {"code":"1","data":"file " + filepath + " not exist"}
        return json_data
    try:
        fp = open(filepath,"r")
        content_lines = fp.readlines()        
        content = ''
        for content_line in content_lines:
            content += content_line
        json_data = {"code":"0","data":content}
    except:
        json_data = {"code":"2","data":"open or read file failed"}
    finally:
        if fp:
            fp.close()
        return json_data
 
def write_file_from_content(filepath,content): 
    json_data = {}
    try:
        fp = open(filepath,"w")
        fp.writelines(content)
        json_data = {"code":"0","data":"succeed"}
    except:
        json_data = {"code":"2","data":"open or write file failed"}
    finally:
        if fp:
            fp.close()
        return json_data
   
def create_dir(directory):
    if not os.path.exists(directory):
        os.mkdir(directory)
    
def create_link(src,dst):
    #if os.path.isfile(dst):
    dst = dst.rstrip('/')
    try:
        os.unlink(dst)
    except:
        pass
    os.symlink(src,dst)

def getDictFromYamlFile(filepath):
    
    with open(filepath) as f:
        c = ''
        while True:
            a = f.readline()
            if not a:
                break
            c += a 
        d = yaml.load(c)
    return d

def getDictFromJsonFile(filepath):
    
    with open(filepath) as f:
        c = ''
        while True:
            a = f.readline()
            if not a:
                break
            c += a
        try:
            d = json.loads(c)
        except:
            print "the file is not json format"
            return {}
    return d    
    
          
    