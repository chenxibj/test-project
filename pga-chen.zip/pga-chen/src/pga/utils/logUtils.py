#encoding=utf-8
import logging
import json
from collections import OrderedDict
import socket
import datetime
from pga.settings import BASE_DIR

def createLogger():
    #info = '\n'.join(info)
    logger = logging.getLogger('')
    logger.setLevel(logging.DEBUG)
    loggerfile = BASE_DIR + '/tmp/logs/pga.log'
    fh = logging.FileHandler(loggerfile)
    fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter('[%(asctime)s] %(levelname)s [%(module)s] - %(message)s')
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger

def createUMPCustomLogger():
    
    logger = logging.getLogger('')
    logger.setLevel(logging.DEBUG)
    loggerfile = '/export/home/tomcat/UMP-Monitor/logs/pga.business.log'
    fh = logging.FileHandler(loggerfile)
    fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(message)s')
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger

def setUMPCustomLog(end_time_format, hostname , detail, key , t = '0', value ='0'):
    
    dict_result = json.dumps(
                             OrderedDict(
                                         [
                                          ("time", end_time_format), 
                                          ("key", key),
                                          ("hostname", hostname), 
                                          ("type", t), 
                                          ("value", value), 
                                          ("detail", detail)
                                          ]
                                         )
                             )
    return dict_result
    
def getHostname():
    try:
        hostname = socket.gethostname()
        return hostname
    except Exception:
        print("get hostname fail for the exception %s" % Exception)
        return False
        
 
def toUMP(detail = 'empty' , key = 'PGA.dnsapi.create'):
    tz = 8
    umpCustomLogger = createUMPCustomLogger()
    end_time_format = (datetime.datetime.utcnow() + datetime.timedelta(hours=tz)).strftime("%Y%m%d%H%M%S000")
    hn = getHostname()
    umpMsg = setUMPCustomLog(end_time_format, hn , detail, key)
    umpCustomLogger.error(umpMsg)

       
    