# -*- coding: utf-8 -*-
from django.shortcuts import  redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.hashers import make_password
import requests
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
from django.conf import settings
from pga.settings import SSO_TRUSTED_URLS_PREFIX

class  SsoMidware:
    def process_request(self, request):
#         print '#'*20
#         print request.path
#         print request.get_host()
#         print '#'*20
        return
        if request.get_host().startswith('127.0.0.1'):
            return
        if request.path not in settings.SSO_WHITELIST_URLS and not request.path.startswith(SSO_TRUSTED_URLS_PREFIX):
            if '/admin/login' not in request.get_raw_uri():
            
                login_url = 'http://ssa.jd.com/sso/login?ReturnUrl=http://pga.iaas.jd.com/'
                if not request.user.is_authenticated():
                    if request.COOKIES.get('sso.jd.com'):
                        ticket = request.COOKIES.get('sso.jd.com')
                        url = 'http://pga.iaas.jd.com/'
                        auth_url = 'http://ssa.iaas.jcloud.com/sso/ticket/verifyTicket'
                        '''
                        ip 不为空即可，并不会被判断
                        '''
                        ip = request.META['REMOTE_ADDR']
                        #ip = request.META['HTTP_X_FORWARDED_FOR']
                        
                        data = {'ticket': ticket,
                                'url': url,
                                'ip': ip}
                        r = requests.get(auth_url, data)
                        if not r.json()['REQ_FLAG']:
                            return redirect(login_url)
                        userinfo = r.json()["REQ_DATA"]
                        username = userinfo['username']
                        try:
                            user = User.objects.get(username=username)
                        except ObjectDoesNotExist:
                            username=userinfo['username']
                            user = User(username=username)
                            user.password = make_password('jd123456',salt=None, hasher='default')
                            user.save()
                            g = Group.objects.get(name='guest') 
                            g.user_set.add(user)
                        user.backend = None
                        auth_user = user
                        login(request, auth_user)
                    else:
                        return redirect(login_url)