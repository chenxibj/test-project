import getpass

def sysuser():
    
    return getpass.getuser()

