#encoding=utf-8
from cmdb.models import Toogles

def toogle_json(toogle_name):
    
    def _toogle(func):
        
        def __toogle(*args, **kwargs):
            
            if Toogles.objects.filter(name=toogle_name):
                t = Toogles.objects.get(name=toogle_name)
                if t.toogle:
                    return func(*args, **kwargs)
                else:
                    msg = ('toogle %s is OFF, PGA provide no data' % toogle_name)
                    print msg
                    return {'result': 'failed', "msg": msg}
            else:
                return func(*args, **kwargs)
    
        return __toogle
        
    return _toogle

def toogle_command(toogle_name):
    
    def _toogle(func):
        
        def __toogle(*args, **kwargs):
            
            if Toogles.objects.filter(name=toogle_name):
                t = Toogles.objects.get(name=toogle_name)
                if t.toogle:
                    return func(*args, **kwargs)
                else:
                    print 'command abort, because %s toogle is OFF' % toogle_name
                    return False
            else:
                return func(*args, **kwargs)
    
        return __toogle
        
    return _toogle