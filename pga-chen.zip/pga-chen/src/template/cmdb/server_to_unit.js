<script type="text/javascript">
$(document).ready(function(){
	
	unit_id = getCookie('unit_id');
	server_id = getCookie('server_id');
	cluster_id = getCookie('cluster_id');
	
	$('[cluster_id =  "'+ cluster_id+'"]').parent().parent().find('select').filter('.unit').find('option').filter('[value="'+unit_id+'"]').attr({"selected":"selected"});
	$('[cluster_id =  "'+ cluster_id+'"]').parent().parent().find('select').filter('.server').find('option').filter('[value="'+server_id+'"]').attr({"selected":"selected"});
	
	$('.unitAddServer').click(function(){
		
		$('.unitAddServer').attr({"disabled":"disabled"});
		unit_id = $(this).parent().find('select').filter('.unit').val();
		server_id = $(this).parent().find('select').filter('.server').val();
		
		cluster_id = $(this).parent().parent().find('span').filter("[cluster_id]").html();
		
		document.cookie = "unit_id="+ unit_id;
		document.cookie = "server_id="+server_id;
		document.cookie = "cluster_id="+ cluster_id;
		
		$.post('/cmdb/service/ajax_unitaddserver/',
			{
				unit_id : unit_id,
				server_id : server_id,
			},
			function(result){
				alert(result);
				location.replace(location.href);
			}
		);
		
	});
	
	

});
</script>