#!/bin/bash
WORKDIR="/export/App/pga/src/tmp/logshell/run"
ip=`cat ${WORKDIR}/ip`
log=`cat ${WORKDIR}/log`



ssh $ip "tail -f $log"

echo "if you see this, the script maybe gets an error"
read

