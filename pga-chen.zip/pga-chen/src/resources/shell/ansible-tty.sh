#!/bin/bash

PLAYPATH="/export/App/pga/src/tmp/playbook/run"
CONCURRENT=`cat ${PLAYPATH}/concurrent`
PARAM=`cat ${PLAYPATH}/param`

echo "[DEBUG]:ansible-playbook -i ${PLAYPATH}/inventory ${PLAYPATH}/test.yaml -f ${CONCURRENT} ${PARAM}"
echo -e "ready to run 'test mode',press Enter to continue or input 'p' to skip..."
read A
if [ ! "xP" = x"$A" ] && [ ! "xp" = x"$A" ]
then    
    ansible-playbook -i ${PLAYPATH}/inventory ${PLAYPATH}/test.yaml -f ${CONCURRENT} ${PARAM}
fi

echo "[DEBUG]:ansible-playbook -i ${PLAYPATH}/inventory-mirror ${PLAYPATH}/playbook.yaml -f ${CONCURRENT} ${PARAM}"
echo -e "ready to run 'mirror mode',press Enter to continue or input 'p' to skip..."
read A
if [ ! "xP" = x"$A" ] && [ ! "xp" = x"$A" ] 
then    
    ansible-playbook -i ${PLAYPATH}/inventory-mirror ${PLAYPATH}/playbook.yaml -f ${CONCURRENT} ${PARAM}
fi

echo "[DEBUG]:ansible-playbook -i ${PLAYPATH}/inventory ${PLAYPATH}/playbook.yaml --check -f ${CONCURRENT} ${PARAM}"
echo -e "ready to run 'dry-run mode',press Enter to continue or input 'p' to skip..."
read A
if [ ! "xP" = x"$A" ] && [ ! "xp" = x"$A" ]
then    
    ansible-playbook -i ${PLAYPATH}/inventory ${PLAYPATH}/playbook.yaml --check -f ${CONCURRENT} ${PARAM}
fi

echo "[DEBUG]:ansible-playbook -i ${PLAYPATH}/inventory ${PLAYPATH}/playbook.yaml -f ${CONCURRENT} ${PARAM}"
echo -e "ready to run 'REALLY',press Enter to continue or input 'p' to skip..."
read A
if [ ! "xP" = x"$A" ] && [ ! "xp" = x"$A" ]
then    
    ansible-playbook -i ${PLAYPATH}/inventory ${PLAYPATH}/playbook.yaml -f ${CONCURRENT} ${PARAM}
fi

echo "job done, press Enter to exit..."
read A

