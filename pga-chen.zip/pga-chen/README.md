pga
====
PanguAxe is a django project that will manage the work of OP with CMDB/Deploy/Release of JDcloud IaaS and SaaS.

##PGA 0.1 Beta notes:
* version: 0.1.1.20160115B
* date: 20160115
* author: madongdong1@jd.com

###Features:
#####Configuration Management
* server informations
* service informations
* idc,env,product,platform,unit informations

#####Service Deploy 
* init a list of servers in a product with generations of inventories and playbooks
* deploy a list of servers in a cluster with generations of inventories and playbooks

###How to use:

###Dependency:
* django
* mariadb
* git

```javascript
  var testjson = {
    today  : "2016-01-15",
    site : "http://pga.cloud.jd.com"
  }
```