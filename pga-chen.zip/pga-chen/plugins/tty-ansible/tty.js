
var tty = require('tty.js');

var app = tty.createServer({
  shell: 'bash',
  shellArgs: ["/export/App/pga/src/resources/shell/ansible-tty.sh"],
  //shell: 'bash "/tmp/a.sh"',
  //shell: '/usr/bin/tail -f /var/log/messages',
  //shell: 'screen',
  //shellArgs: ["-r", "key"],
  //shell: 'tail',
  //shellArgs: ["-f","/var/log/messages"],
  //shell: 'ssh',
  //shellArgs: ["172.27.33.11","tail -f /var/log/keystone/keystone.log"],
  //shell: 'ansible-playbook',
  //shellArgs: ["-i","/export/App/pga/src/tmp/playbook/test.keystone.gz/inventory","/export/App/pga/src/tmp/playbook/test.keystone.gz/test.yaml"],
  users: {
    foo: 'bar'
  },
  port: 8090
});

app.get('/foo', function(req, res, next) {
  res.send('bar');
});

app.listen();
